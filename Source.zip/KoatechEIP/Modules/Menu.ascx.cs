﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Authority;

public partial class Menu : System.Web.UI.UserControl
{
    private string SelectMenuNo = "";

    public DataTable dtMenu;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //取得已選擇的MenuNo
            if (Definition.SelectMenuNo != "")
                SelectMenuNo = Definition.SelectMenuNo;

            //取得全部的選單
            //dtMenu = BLL.GetMenuList(null, null, "True");
            dtMenu = Definition.MainMenu;

            //遞迴取得選單Html
            liMenu.Text = GetMenu("0");
        }
    }

    private string GetMenu(string ParentNo)
    {
        StringBuilder sbMenu = new StringBuilder();

        //判斷是階層
        if (ParentNo == "0") { sbMenu.Append("<ul id='side-menu' class='nav nav-list'>"); }
        else { sbMenu.Append("<ul class='submenu'>"); }

        //循序讀取選單
        DataRow[] rows = dtMenu.Select("ParentNo = '" + ParentNo + "' AND isMenu=1", "OrderID");
        foreach (DataRow row in rows)
        {
            string strMenuName = row["MenuName"].ToString();
            string strMenuNo = row["MenuNo"].ToString();
            string strMenuLink = row["MenuLink"].ToString();
            string strMenuIco = row["MenuIco"].ToString();

            if (string.IsNullOrEmpty(strMenuLink))
            {
                string strSubMenu = GetMenu(strMenuNo);

                if (strSubMenu.Contains("<li"))
                {
                    string liCss = (SelectMenuNo.StartsWith(strMenuNo) ? " class='active open' " : "");
                    string _item = string.Format("<li {3}><a href='#' class='dropdown-toggle'><i class='menu-icon fa {0}'></i><span class='menu-text'>{1}</span><b class='arrow fa fa-angle-down'></b></a><b class='arrow'></b>{2}</li>", strMenuIco, strMenuName, strSubMenu, liCss);
                    sbMenu.Append(_item);
                }
            }
            else
            {
                //是否有此項目權限
                bool bAuth = UHR.BasePage.BasePage.CheckUserAuthority(strMenuNo);

                if (bAuth)
                {
                    string liCss = (SelectMenuNo.StartsWith(strMenuNo) ? " class='active' " : "");
                    string _item = string.Format("<li {4}><a href='{0}'><i class='menu-icon fa {1}'></i>{2}</a><b class='arrow'></b></li>", ResolveClientUrl("~" + strMenuLink), strMenuIco, strMenuName, strMenuNo, liCss);
                    sbMenu.Append(_item);
                }
            }
        }

        sbMenu.Append("</ul>");
        return sbMenu.ToString();
    }
}