﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Authority;
using UHR.Util;

public partial class WorkList : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            UserInfo ui = UserInfo.SessionState;

            //取得待辦事項
            DataTable dt = BLL.GetWorkList("", ui.Account, "");

            //依序讀取待辦事項
            foreach (DataRow row in dt.Rows)
            {
                string strType = row["Type"].ToString();
                string strSubject = row["Subject"].ToString();
                string strParams = row["Params"].ToString();
                string strUrl = "";

                switch (strType)
                {
                    case "Forecast":
                        strUrl = ServerInfo.GetRootURI() + "/System/RF/RF01/Default.aspx?" + strParams;
                        break;
                }

                liItems.Text += "<li><i class='ace-icon fa fa-angle-right'></i> <a href='" + strUrl + "'>" + strSubject + "</a></li>";
            }

            //判斷有無待辦事項
            if (liItems.Text == "")
            {
                liItems.Text += "<li>您無任何待辦事項</li>";
            }
        }
    }
}