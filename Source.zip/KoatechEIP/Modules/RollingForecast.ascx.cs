﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;
using UHR.Authority;

public partial class RollingForecast : System.Web.UI.UserControl
{
    public UserInfo UI = null;

    protected void Page_Init(object sender, EventArgs e)
    {
        //檢查權限
        string MenuNo = "M0402";
        this.Visible = UHR.BasePage.BasePage.CheckUserAuthority(MenuNo);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        UI = UserInfo.SessionState;

        if (!IsPostBack && this.Visible)
        {
            //參數
            string strYear = DateTime.Now.Year.ToString();

            //組成業務人員清單
            string strPersonLis = "";
            DataTable dtGroup = BLL_RF.GetRF_Group(UI.Account, "業務","");
            foreach (DataRow row in dtGroup.Rows)
            {
                strPersonLis += string.Format("{0},", row["Account"]);
            }
            strPersonLis = strPersonLis.Trim(',');

            //載入公司別
            DataTable dtCompany = BLL.GetSystemConfig("Company", "");
            ddlCompany.DataSource = dtCompany;
            ddlCompany.DataBind();
            ddlCompany.Items.Insert(0, new ListItem("全部", ""));

            //帶入Hidden
            hiddenPersonList.Value = strPersonLis;
            hiddenYear.Value = strYear;
        }
    }
}