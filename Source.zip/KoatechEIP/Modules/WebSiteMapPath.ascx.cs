﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;

public partial class WebSiteMapPath : System.Web.UI.UserControl
{
    private string SelectMenuNo = "";
    public DataTable dtMenu;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //取得已選擇的MenuNo
            if (Definition.SelectMenuNo != "")
                SelectMenuNo = Definition.SelectMenuNo;

            //取得全部的選單
            //dtMenu = BLL.GetMenuList(null, null, "True");
            dtMenu = Definition.MainMenu;

            string strMenu = GetMenuPath(SelectMenuNo);
            string strHtml = "<ul class='breadcrumb'>{0}</ul>";
            liSiteMapPath.Text = string.Format(strHtml, strMenu);
        }
    }

    protected string GetMenuPath(string _MenuNo)
    {
        string returnVal = "";
        DataRow[] rowMenu = dtMenu.Select("MenuNo='" + _MenuNo + "'");

        if (rowMenu.Length > 0)
        {
            DataRow row = rowMenu[0];
            string ParentNo = row["ParentNo"].ToString();
            string HomeIcon = "";

            if (ParentNo == "0")
                HomeIcon = "<i class='ace-icon fa fa-home home-icon'></i>";

            returnVal = GetMenuPath(ParentNo) + string.Format("<li>{0}{1}</li>", HomeIcon, row["MenuName"]);
        }

        return returnVal;
    }
}
