﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;

public partial class Default : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0201";
        base.OnPreInit(e);
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            txtEmpCode.Text = Tool.CheckQueryString("id");

            //部門名稱選單
            listDEP.DataSource = BLL_PUBLIC.GetHR_DEP("", "", "", "N");
            listDEP.DataBind();
            listDEP.Items.Insert(0, new ListItem("全部", ""));

            gv_GridDataBind(new object(), new EventArgs());
        }
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        if (gv.SortExpression == "")
        {
            gv.SortExpression = "EMPID";
        }

        string strEmpCode = txtEmpCode.Text.Trim();
        string strCName = txtCName.Text.Trim();
        string strDEP = listDEP.SelectedValue;

        int recordCount;
        DataTable dt = BLL_PUBLIC.GetHR_UserData(strEmpCode, strDEP, strCName, gv.SortingCondition, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        gv.GridView.Columns.Clear();
        gv.AddColumn("公司別", "CPNYID", true, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("部門名稱", "DEP_NAME", true, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("工號", "EMPID", true, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("姓名", "HECNAME", true, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("性別", "SEX", true, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("分機", "EXT", true, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("Email", "EMAIL", true, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("職稱", "POS_NAME", true, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);

        gv.RowCount = recordCount;
        gv.GridView.DataSource = dt;
        gv.DataBind();
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        TableCell cellSex = gv.GetTableCell(e.Row, "性別", false);

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strSex = rowView["SEX"].ToString();

            cellSex.Text = (strSex == "M" ? "男" : "女");
        }
    }
}