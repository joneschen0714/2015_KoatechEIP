﻿using System;
using System.IO;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;


public partial class Default : UHR.BasePage.BasePage
{
    private DataTable DT;

    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0202";
        base.OnPreInit(e);
    }

    protected void Page_Init(object sender, EventArgs e)
    {

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //取得所有資料
            DT = BLL_PUBLIC.GetPUB02("", "1");

            //建立Tab
            int i = 0;
            foreach (DataRow row in DT.Select("Type='Tab'"))
            {
                i++;
                string strActive = (i == 1 ? " active " : "");
                string strTab = "tab" + i.ToString();
                string strID = Convert.ToString(row["ID"]);

                liTabs.Text += string.Format("<li class='{0}'><a data-toggle='tab' href='#{1}'>{2}</a></li>", strActive, strTab, row["Title"]);
                liTabContent.Text += string.Format("<div id='{0}' class='tab-pane {1}'>{2}</div>", strTab, strActive, FillTabContent(strID));
            }
        }
    }

    //遞迴建立節點
    private string FillTabContent(string _id)
    {
        string s = "<ul class='list-unstyled list-striped pricing-table-header'>";
        foreach (DataRow row in DT.Select("ParentID=" + _id))
        {
            string strID = Convert.ToString(row["ID"]);
            string strType = Convert.ToString(row["Type"]);
            string strTitle = Convert.ToString(row["Title"]);
            string strUrl = Convert.ToString(row["Url"]);
            string strPassword = Convert.ToString(row["Password"]);
            string strAllowUser = Convert.ToString(row["AllowUser"]);
            string strChild = "";

            if (strType == "Type")
            {
                DataRow[] rowsChild = DT.Select("ParentID=" + strID);
                if (rowsChild.Length > 0)
                {
                    strChild = FillTabContent(strID);
                }

                string strImg = "<i class='fa fa-folder-open-o fa-fw fa-lg'></i>";
                string strText = "<a data-folder style='cursor:pointer'>" + strTitle + "</a>";

                s += "<li>" + strImg + strText + strChild + "</li>";
            }
            else if (strType == "Item")
            {
                //判斷密碼
                string strLock = "";
                if (strPassword != "")
                    strLock = "<i class='fa fa-lock fa-fw fa-lg'></i>";

                //判斷用戶組
                if (strAllowUser != "")
                    strAllowUser = "<i class='fa fa-users fa-fw fa-lg'></i>";

                //檔案格式
                string strImg = "";
                FileInfo fi = new FileInfo(strUrl);
                switch (fi.Extension.ToLower())
                {
                    case ".pdf":
                        strImg = "<i class='fa fa-file-pdf-o fa-fw fa-lg'></i>";
                        break;
                    case ".mp4":
                    case ".webm":
                    case ".ogv":
                    case ".mkv":
                        strImg = "<i class='fa fa-file-video-o fa-fw fa-lg'></i>";
                        break;
                }

                s += "<li>" + strImg + "<a href='#' onclick=\"OpenDialog('" + strID + "')\">" + strTitle + strLock + strAllowUser + "</a></li>";
            }
        }

        s += "</ul>";
        return s;
    }
}