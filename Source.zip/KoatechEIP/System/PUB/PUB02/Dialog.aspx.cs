﻿using System;
using System.Data;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;
using UHR.Authority;

public partial class System_Pub_Pub02_Dialog : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0202";
        base.OnPreInit(e);
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<link href='" + ResolveClientUrl("~/configuration/css/bootstrap.min.css") + "' rel='stylesheet' />"));
        Page.Header.Controls.Add(new LiteralControl("<link href='" + ResolveClientUrl("~/configuration/css/font-awesome.min.css") + "' rel='stylesheet' />"));
        Page.Header.Controls.Add(new LiteralControl("<link href='" + ResolveClientUrl("~/configuration/css/fonts.css") + "' rel='stylesheet' />"));
        Page.Header.Controls.Add(new LiteralControl("<link href='" + ResolveClientUrl("~/configuration/css/ace.min.css") + "' rel='stylesheet' />"));

        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/jquery-2.1.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/bootstrap.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/ace-elements.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/ace.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/pdfobject.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //取網址參數
        ID = Tool.CheckQueryString("id");

        if (!IsPostBack)
        {
            //取得資料
            DataTable dt = BLL_PUBLIC.GetPUB02(ID, "");
            if (dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];
                Page.Title = Convert.ToString(row["Title"]);
                PWD = Convert.ToString(row["Password"]);
                AllowUser = Convert.ToString(row["AllowUser"]);

                //若有密碼
                if (PWD != "")
                {
                    palAudit.Visible = true;
                }
                else if (AllowUser != "")
                {
                    //判斷權限
                    if (CheckAllowUser(AllowUser) == false)
                        liMsg.Text = GetMessage("error", "您沒有權限查看此檔案!");
                    else
                        SetData(ID);
                }
                else
                {
                    SetData(ID);
                }
            }
            else
            {
                liMsg.Text = GetMessage("error", "作業發生錯誤，請確認是否操作正確!");
            }
        }
    }

    protected void btnCheck_Click(object sender, EventArgs e)
    {
        //驗証密碼
        string strPassword = txtPassword.Text;
        if (strPassword == PWD)
        {
            palAudit.Visible = false;
            SetData(ID);
        }
    }

    //檢查是否有權限
    private bool CheckAllowUser(string _users)
    {
        bool bResult = false;

        int iID = UserInfo.SessionState.ID;
        foreach (string s in _users.Split(','))
        {
            if (s == iID.ToString())
            {
                bResult = true;
                break;
            }
        }

        return bResult;
    }

    private void SetData(string _id)
    {
        //取得資料
        DataTable dt = BLL_PUBLIC.GetPUB02(_id, "");
        DataRow row = dt.Rows[0];

        string strFilePath = Convert.ToString(row["Url"]);
        hiddenFilePath.Value = ResolveClientUrl(strFilePath);

        //判斷檔案格式
        FileInfo fi = new FileInfo(strFilePath);
        switch (fi.Extension.ToLower())
        {
            case ".pdf":
                palPDF.Visible = true;
                break;
            case ".mp4":
            case ".webm":
            case ".ogv":
            case ".mkv":
                palVideo.Visible = true;
                liVideo.Text = "<source src=\"" + hiddenFilePath.Value + "\" type='video/mp4'>";
                liVideo.Text += "<source src=\"" + hiddenFilePath.Value + "\" type='video/webm'>";
                liVideo.Text += "<source src=\"" + hiddenFilePath.Value + "\" type='video/ogg'>";
                break;
        }
    }

    private new string ID
    {
        get { return ViewState["ID"].ToString(); }
        set { ViewState.Add("ID", value); }
    }

    private string PWD
    {
        get { return ViewState["PWD"].ToString(); }
        set { ViewState.Add("PWD", value); }
    }

    private string AllowUser
    {
        get { return ViewState["AllowUser"].ToString(); }
        set { ViewState.Add("AllowUser", value); }
    }
}