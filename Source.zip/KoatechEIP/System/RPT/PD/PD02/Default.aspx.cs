﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using UHR;
using UHR.Util;

public partial class Default : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M010202";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //預設帶入今年
            txtYear.Text = DateTime.Now.ToString("yyyy");

            //月份
            for (int i = 1; i <= 12; i++)
            {
                string strMonth = i.ToString().PadLeft(2, '0');
                ddlMonth.Items.Add(new ListItem(strMonth, strMonth));
            }
            ddlMonth.Items.Insert(0, new ListItem("全部", ""));

            //生產線別
            DataTable dtLine = DAL_WIP.GetMOCWB("");
            foreach (DataRow row in dtLine.Rows)
            {
                row["WB002"] = string.Format("{0} - {1}", row["WB001"], row["WB002"]);
            }
            ddlLine.DataSource = dtLine;
            ddlLine.DataBind();

            //載入製程項目
            ddlLine_SelectedIndexChanged(sender, e);
        }
    }

    protected void ddlLine_SelectedIndexChanged(object sender, EventArgs e)
    {
        string strLine = ddlLine.SelectedValue;

        //製程項目
        DataTable dtProcess = DAL_WIP.GetMOCWA(strLine);
        foreach (DataRow row in dtProcess.Rows)
        {
            row["WA002"] = string.Format("{0} - {1}", row["WA001"], row["WA002"]);
        }
        ddlProcess.DataSource = dtProcess;
        ddlProcess.DataBind();
        ddlProcess.Items.Insert(0, new ListItem("全部", ""));
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ClearMemory(); //清除記憶體

        //參數
        string strYear = txtYear.Text.Trim();
        string strMonth = ddlMonth.SelectedValue;
        string strLine = ddlLine.SelectedValue;
        string strProcess = ddlProcess.SelectedValue;
        string strLevel = ddlLevel.SelectedValue;

        DataTable dt = BLL_WIP.GetPD02(strYear, strMonth, strLine, strProcess, strLevel);

        ReportViewer1.LocalReport.ReportPath = Tool.GetPhysicalPath + "Report.rdlc";
        ReportViewer1.LocalReport.DataSources.Clear();
        ReportViewer1.LocalReport.DataSources.Add(new ReportDataSource("PD02", dt));
        ReportViewer1.LocalReport.Refresh();
        ReportViewer1.DataBind();
        ReportViewer1.Visible = true;
    }

    //ReportViewer連結事件
    protected void ReportViewer1_Drillthrough(object sender, DrillthroughEventArgs e)
    {
        LocalReport r = (LocalReport)e.Report;
        string strFormType = r.GetParameters()["FormType"].Values[0];
        string strFormNum = r.GetParameters()["FormNum"].Values[0];

        DataTable dt = BLL_WIP.GetPD02_Report2(strFormType, strFormNum, "");

        r.DataSources.Add(new ReportDataSource("PD02_Report2", dt));
    }

    private void ClearMemory()
    {
        //清除ReportViewer記憶體
        for (int i = 0; i < Session.Count; i++)
        {
            if (Session[i].GetType().ToString() == "Microsoft.Reporting.WebForms.ReportHierarchy")
            {
                Session.RemoveAt(i);
            }
        }
    }
}