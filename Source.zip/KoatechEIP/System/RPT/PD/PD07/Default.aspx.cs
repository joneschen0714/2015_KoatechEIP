﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using UHR;
using UHR.Util;

public partial class Default : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M010207";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataTable dt = BLL_ERP.GetCMSMD("");
            ddlLine.DataSource = dt;
            ddlLine.DataBind();
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ClearMemory(); //清除記憶體

        string strFormType = txtFormType.Text.Trim();
        string strFormNum = txtFormNum.Text.Trim();
        string strDate1 = txtDate1.Text.Trim();
        string strDate2 = txtDate2.Text.Trim();
        string strLine = ddlLine.SelectedValue;
        string strsProduct = txtsProdcut.Text.Trim();

        DataTable dt = BLL_WIP.GetPD07(strFormType, strFormNum, strDate1, strDate2, strLine, strsProduct);

        ReportViewer1.LocalReport.ReportPath = Tool.GetPhysicalPath + "Report.rdlc";
        ReportViewer1.LocalReport.DataSources.Clear();
        ReportViewer1.LocalReport.DataSources.Add(new ReportDataSource("PD07", dt));
        ReportViewer1.LocalReport.Refresh();
        ReportViewer1.Visible = true;
    }

    private void ClearMemory()
    {
        //清除ReportViewer記憶體
        for (int i = 0; i < Session.Count; i++)
        {
            if (Session[i].GetType().ToString() == "Microsoft.Reporting.WebForms.ReportHierarchy")
            {
                Session.RemoveAt(i);
            }
        }
    }
}