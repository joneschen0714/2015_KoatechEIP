﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using UHR;
using UHR.Util;

public partial class Default : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M010201";
        base.OnPreInit(e);
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ClearMemory(); //清除記憶體

        string strProduct = txtProduct.Text.Trim();
        string strProductName = txtProductName.Text.Trim();

        DataTable dt = BLL_ERP.GetPD01(strProduct, strProductName);

        ReportViewer1.LocalReport.ReportPath = Tool.GetPhysicalPath + "Report.rdlc";
        ReportViewer1.LocalReport.DataSources.Clear();
        ReportViewer1.LocalReport.DataSources.Add(new ReportDataSource("DataSet1", dt));
        ReportViewer1.LocalReport.Refresh();
        ReportViewer1.Visible = true;
    }

    private void ClearMemory()
    {
        //清除ReportViewer記憶體
        for (int i = 0; i < Session.Count; i++)
        {
            if (Session[i].GetType().ToString() == "Microsoft.Reporting.WebForms.ReportHierarchy")
            {
                Session.RemoveAt(i);
            }
        }
    }
}