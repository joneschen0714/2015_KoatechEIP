﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using UHR;
using UHR.Util;

public partial class Default : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M010101";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ddlINV_SelectedIndexChanged(sender, e);

            DataTable dt1 = BLL_ERP.GetINVMA("1", "");
            ddlClass.DataSource = dt1;
            ddlClass.DataBind();
            ddlClass.Items.Insert(0, new ListItem("All", ""));
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        string date, invType, invType1, invClass, PN1, PN2, day1, day2, day21, day3, day31, day4, day41, day5, day51, day6;

        date = txtDate.Text.Trim();
        invType = ddlINV.SelectedValue;
        invType1 = ddlINV1.SelectedValue;
        invClass = ddlClass.SelectedValue; ;
        day1 = txtDay1.Text;
        day2 = txtDay2.Text;
        day21 = txtDay21.Text;
        day3 = txtDay3.Text;
        day31 = txtDay31.Text;
        day4 = txtDay4.Text;
        day41 = txtDay41.Text;
        day5 = txtDay5.Text;
        day51 = txtDay51.Text;
        day6 = txtDay6.Text;

        DataTable dt = BLL_WIP.GetFIN01(date, invType, invType1, invClass.TrimEnd(','), "", "", day1, day2, day21, day3, day31, day4, day41, day5, day51, day6);

        List<int> NumberIndex = new List<int> { 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21 };
        var ms = NPOITools.RenderDataTableToExcel(dt, NumberIndex) as System.IO.MemoryStream;

        string strFileName = "庫齡報表.xls";
        Response.AddHeader("Content-Disposition", string.Format("attachment; filename={0}", Server.UrlPathEncode(strFileName)));
        Response.BinaryWrite(ms.ToArray());
    }

    protected void ddlINV_SelectedIndexChanged(object sender, EventArgs e)
    {
        string invType = ddlINV.SelectedValue;
        DataTable dt = BLL_ERP.GetCMSMC(invType);

        ddlINV1.DataSource = dt;
        ddlINV1.DataBind();
        ddlINV1.Items.Insert(0, new ListItem("All", ""));
    }

    protected void btnRange_Click(object sender, EventArgs e)
    {
        Control ctrl = (Control)sender;

        switch (ctrl.ID)
        {
            case "btnRange1":
                txtDay1.Text = "60";
                txtDay2.Text = "61";
                txtDay21.Text = "90";
                txtDay3.Text = "91";
                txtDay31.Text = "120";
                txtDay4.Text = "121";
                txtDay41.Text = "150";
                txtDay5.Text = "151";
                txtDay51.Text = "180";
                txtDay6.Text = "181";
                break;
            case "btnRange2":
                txtDay1.Text = "180";
                txtDay2.Text = "181";
                txtDay21.Text = "210";
                txtDay3.Text = "211";
                txtDay31.Text = "240";
                txtDay4.Text = "241";
                txtDay41.Text = "270";
                txtDay5.Text = "271";
                txtDay51.Text = "300";
                txtDay6.Text = "301";
                break;
            case "btnRange3":
                txtDay1.Text = "300";
                txtDay2.Text = "301";
                txtDay21.Text = "330";
                txtDay3.Text = "331";
                txtDay31.Text = "365";
                txtDay4.Text = "366";
                txtDay41.Text = "450";
                txtDay5.Text = "451";
                txtDay51.Text = "540";
                txtDay6.Text = "541";
                break;
            case "btnRange4":
                txtDay1.Text = "540";
                txtDay2.Text = "541";
                txtDay21.Text = "630";
                txtDay3.Text = "631";
                txtDay31.Text = "720";
                txtDay4.Text = "721";
                txtDay41.Text = "9999";
                txtDay5.Text = "9999";
                txtDay51.Text = "9999";
                txtDay6.Text = "9999";
                break;
        }
    }
}
