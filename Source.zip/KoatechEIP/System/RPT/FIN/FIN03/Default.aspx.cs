﻿using System;
using System.Data;
using System.Linq;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using Microsoft.Reporting.WebForms;
using UHR;
using UHR.Util;

public partial class Default : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M010103";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtYear.Text = DateTime.Today.ToString("yyyy");
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ClearMemory(); //清除記憶體

        //控制項值
        var Year = txtYear.Text.Trim();
        var Month = ddlMonth.SelectedValue;
        var Month1 = ddlMonth1.SelectedValue;
        var ReportType = ddlReportType.SelectedValue;
        var PriceType = Convert.ToInt32(ddlPriceType.SelectedValue);
        var ItemType = ddlItemType.SelectedValue;

        //資料來源
        var dv = GetData(Year, Month, Month1, ItemType, PriceType);

        //報表設定
        ReportViewer1.LocalReport.ReportPath = Tool.GetPhysicalPath + ReportType;
        ReportViewer1.LocalReport.DataSources.Clear();
        ReportViewer1.LocalReport.DataSources.Add(new ReportDataSource("DataSet1", dv));
        ReportViewer1.LocalReport.SetParameters(new ReportParameter("PriceType", ddlPriceType.SelectedItem.Text));
        ReportViewer1.LocalReport.Refresh();
        ReportViewer1.Visible = true;
    }

    protected void btnImportHistory_Click(object sender, EventArgs e)
    {
        var Year = txtYear.Text.Trim();
        var Month = ddlMonth.SelectedValue;
        var Month1 = ddlMonth1.SelectedValue;

        var dv = GetData(Year, Month, Month1,"明細", 1);
        BLL_PUBLIC.SetFIN03_HistoryData(dv);

        liMsg.Text = GetMessage("success", "作業成功!");
    }

    //取得現有分攤條件下的資料
    private DataView GetData(string Year, string Month, string Month1,string ItemType, int PriceType)
    {
        //取得分攤條件
        DataTable da = BLL_PUBLIC.GetFIN03();

        #region 建立BU資料格式
        var dt = new DataTable();
        var col_1 = new DataColumn("BU分類", Type.GetType("System.String"));
        var col_2 = new DataColumn("科目編號", Type.GetType("System.String"));
        var col_3 = new DataColumn("科目名稱", Type.GetType("System.String"));
        var col_4 = new DataColumn("科目類別", Type.GetType("System.Int32"));
        var col_5 = new DataColumn("金額", Type.GetType("System.Int32"));
        var col_6 = new DataColumn("月份", Type.GetType("System.String"));
        var col_7 = new DataColumn("年份", Type.GetType("System.String"));
        dt.Columns.AddRange(new DataColumn[] { col_1, col_2, col_3, col_4, col_5, col_6, col_7 });
        #endregion

        #region 建立所有BU的會計科目
        var BUList = da.AsEnumerable().Select(r => new { BU = r.Field<string>("BU分類") }).Distinct();
        var ItemList = da.AsEnumerable().Select(r => new { Code = r.Field<string>("科目代號").Substring(0, 1) }).Distinct();

        for (var m = Convert.ToInt32(Month); m <= Convert.ToInt32(Month1); m++)
        {
            foreach (var i in ItemList)
            {
                DataTable dtACTMA = BLL_ERP.GetACTMA(i.Code, "", "");
                foreach (DataRow row in dtACTMA.Rows)
                {
                    foreach (var t in BUList)
                    {
                        dt.Rows.Add(t.BU, row["MA001"], row["MA003"], row["MA008"], 0, m.ToString().PadLeft(2, '0'), Year);
                    }
                }
            }
        }

        dt.PrimaryKey = new DataColumn[] { dt.Columns["BU分類"], dt.Columns["科目編號"], dt.Columns["月份"] }; //設定主索引鍵
        #endregion

        #region 依分攤條件依序建立資料
        for (var m = Convert.ToInt32(Month); m <= Convert.ToInt32(Month1); m++)
        {
            foreach (DataRow r in da.Rows)
            {
                var BU分類 = Convert.ToString(r["BU分類"]);
                var 科目代號 = Convert.ToString(r["科目代號"]);
                var 歸屬部門 = Convert.ToString(r["歸屬部門"]);
                var 分攤比率 = Convert.ToDecimal(r["分攤比率"]);

                DataTable dtResult = BLL_ERP.GetACTMD(科目代號, 歸屬部門, Year, m.ToString().PadLeft(2, '0'));
                foreach (DataRow r1 in dtResult.Rows)
                {
                    var row = dt.Rows.Find(new object[] { BU分類, r1["MD001"], r1["MD004"] });
                    row["金額"] = Convert.ToInt32(row["金額"]) + Convert.ToInt32(Convert.ToInt32(r1["AMT"]) * 分攤比率);
                }
            }
        }
        #endregion

        #region 將金額加總至分類科目
        foreach (var r in dt.Select("科目類別=4"))
        {
            var BU分類 = Convert.ToString(r["BU分類"]).Trim();
            var 月份 = Convert.ToString(r["月份"]).Trim();
            var 科目編號 = Convert.ToString(r["科目編號"]).Trim();

            var 加總金額 = (from i in dt.AsEnumerable()
                        where i.Field<string>("BU分類") == BU分類 &&
                              i.Field<string>("科目編號").StartsWith(科目編號) &&
                              i.Field<int>("科目類別") > 1 && i.Field<int>("科目類別") < 4 &&
                              i.Field<string>("月份") == 月份 &&
                              i["金額"] != DBNull.Value
                        select i).Sum(x => x.Field<int>("金額"));

            r["金額"] = 加總金額;
        }
        #endregion

        #region 增加營業利益與營業毛利
        for (var m = Convert.ToInt32(Month); m <= Convert.ToInt32(Month1); m++)
        {
            foreach (var t in BUList)
            {
                var 科目4 = dt.Rows.Find(new object[] { t.BU, "4", m.ToString().PadLeft(2, '0') })["金額"].ToString();
                var 科目5 = dt.Rows.Find(new object[] { t.BU, "5", m.ToString().PadLeft(2, '0') })["金額"].ToString();
                var 科目6 = dt.Rows.Find(new object[] { t.BU, "6", m.ToString().PadLeft(2, '0') })["金額"].ToString();

                var 營業毛利 = Convert.ToInt32(科目4) - Convert.ToInt32(科目5);
                var 營業利益 = 營業毛利 - Convert.ToInt32(科目6);

                dt.Rows.Add(t.BU, "5A", "營業毛利", 0, 營業毛利, m.ToString().PadLeft(2, '0'), Year);
                dt.Rows.Add(t.BU, "6A", "營業利益", 0, 營業利益, m.ToString().PadLeft(2, '0'), Year);
            }
        }
        #endregion

        #region 運算金額單位
        foreach (DataRow row in dt.Rows)
        {
            var 金額 = Convert.ToInt32(row["金額"]) / PriceType;
            row["金額"] = Convert.ToInt32(金額);
        }
        #endregion

        #region 是否展至統制帳戶
        dt.DefaultView.RowFilter = "1=1";
        if (ItemType == "統制")
        {
            dt.DefaultView.RowFilter += " AND 科目類別 <> 2"; //濾掉明細帳戶
        }
        #endregion

        //只撈有金額的科目
        dt.DefaultView.RowFilter += " AND 金額 IS NOT NULL AND 金額 <> 0";

        return dt.DefaultView;
    }

    private void ClearMemory()
    {
        //清除ReportViewer記憶體
        for (int i = 0; i < Session.Count; i++)
        {
            if (Session[i].GetType().ToString() == "Microsoft.Reporting.WebForms.ReportHierarchy")
            {
                Session.RemoveAt(i);
            }
        }
    }
}