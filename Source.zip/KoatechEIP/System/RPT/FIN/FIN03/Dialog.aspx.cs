﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;
using Newtonsoft.Json;

public partial class FIN03_Dialog : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M010103";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        var dt = BLL_PUBLIC.GetFIN03();
        var list = new List<int>() { 4 };
        var ms = NPOITools.RenderDataTableToExcel(dt, list) as System.IO.MemoryStream;

        string strFileName = "BU分攤條件.xls";
        Response.AddHeader("Content-Disposition", string.Format("attachment; filename={0}", Server.UrlPathEncode(strFileName)));
        Response.BinaryWrite(ms.ToArray());
    }

    protected void btnImport_Click(object sender, EventArgs e)
    {
        if (file.HasFile)
        {
            //判斷副檔名是否為xls
            string fileExtension = System.IO.Path.GetExtension(file.FileName).ToLower(); //如果副檔名有大寫則將他轉為小寫
            if (fileExtension == ".xls")
            {
                var dt = NPOITools.RenderDataTableFromExcel(file.FileContent, 0, 0);
                BLL_PUBLIC.SetFIN03(dt);

                liMsg.Text = GetMessage("success", "作業成功!");
            }
            else
            {
                liMsg.Text = GetMessage("error", "副檔名需為Excel 2003/2007的xls格式!");
            }
        }
    }
}