﻿using System;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UHR;
using UHR.Util;
using UHR.Authority;

public partial class Default : UHR.BasePage.BasePage
{
    public UserInfo UI = null;

    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M010302";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        UI = UserInfo.SessionState;

        if (!Page.IsPostBack)
        {
            for (int i = 0; i >= -2; i--)
            {
                int iYear = DateTime.Now.AddYears(i).Year;
                ddlYear.Items.Add(new ListItem(iYear.ToString()));
            }

            ddlCompany.DataSource = BLL.GetSystemConfig("Company", "");
            ddlCompany.DataBind();
            ddlCompany.Items.Insert(0, new ListItem("全部", ""));

            listBU.DataSource = BLL_ERP.GetINVMA("2", "");
            listBU.DataBind();

            ddlClass.DataSource = BLL_ERP.GetINVMA("4", "");
            ddlClass.DataBind();
            ddlClass.Items.Insert(0, new ListItem("全部", ""));

            DataTable dt = BLL_RF.GetRF_Group(UI.Account, "業務", "");
            ddlSales.DataSource = dt;
            ddlSales.DataBind();
            ddlSales.Items.Insert(0, new ListItem("全部", ""));

            //記錄層級
            DataRow[] rows = dt.Select("人員代號='" + UI.Account + "'");
            if (rows.Length > 0)
            {
                string AuthCode = rows[0]["層級"].ToString();
                hiddenAuthCode.Value = AuthCode == "A" ? "" : AuthCode;
            }
        }
    }
}