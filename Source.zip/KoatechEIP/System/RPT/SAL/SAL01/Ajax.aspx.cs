﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Xml;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections;
using UHR;
using UHR.Util;

public partial class Ajax : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M010301";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        string Company = Tool.CheckQueryString("cm");
        string BU = Tool.CheckQueryString("b");
        string Class = Tool.CheckQueryString("cl");
        string Custom = Tool.CheckQueryString("c");
        string Product = Tool.CheckQueryString("p");
        string Sales = Tool.CheckQueryString("s");
        string Format = Tool.CheckQueryString("f");
        string AuthCode = Tool.CheckQueryString("au");

        //顯示圖表
        GetChart(Company, BU, Class, Product, Custom, Sales, Format, AuthCode);
    }

    //取得業務實際銷售資料
    private void GetChart(string Company, string BU, string Class, string Product, string Custom, string Sales, string Format, string AuthCode)
    {
        int iSYear = DateTime.Now.AddYears(-2).Year;
        int iEYear = DateTime.Now.Year;

        //資料來源
        DataTable dt = BLL_RF.GetSAL01(iSYear, Company, BU, Class, Product, Custom, Sales, AuthCode);
        dt.PrimaryKey = new DataColumn[] { dt.Columns["年度"], dt.Columns["月份"] }; //設定主索引鍵

        //Y軸顯示文字
        string strYAxisName = (Format == "Amount" ? "本幣金額" : "米平方單位");

        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("<chart caption='{0}年~{1}年 銷售趨勢圖' xAxisName='月份' yAxisName='{2}' setAdaptiveSYMin='1' showValues='0' formatNumberScale='1' numberScaleValue='10000' numberScaleUnit='萬' NumberPrefix='$' labelDisplay='WRAP'>", iSYear, iEYear, strYAxisName);

        //增加Category
        sb.Append("<categories>");
        for (int i = 1; i <= 12; i++)
        {
            string strMonth = i.ToString().PadLeft(2, '0');
            sb.AppendFormat("<category label='{0}' />", strMonth);
        }
        sb.Append("</categories>");

        //增加項目值
        for (int iYear = iSYear; iYear <= iEYear; iYear++)
        {
            sb.AppendFormat("<dataset seriesName='{0}年'>", iYear);

            for (int j = 1; j <= 12; j++)
            {
                string strMonth = j.ToString().PadLeft(2, '0');
                DataRow rowItem = dt.Rows.Find(new object[] { iYear, strMonth });
                if (rowItem != null)
                {
                    sb.AppendFormat("<set value='{0}'/>", (Format == "Amount" ? rowItem["本幣金額"] : rowItem["數量M2"]));
                }
                else
                {
                    sb.Append("<set value=''/>");
                }
            }
            sb.Append("</dataset>");
        }

        sb.Append("</chart>");
        Response.Write(sb.ToString());
    }
}