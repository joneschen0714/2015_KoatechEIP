﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Xml;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections;
using UHR;
using UHR.Util;

public partial class Ajax : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M010305";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        string sYM = Tool.CheckQueryString("sy");
        string eYM = Tool.CheckQueryString("ey");
        string Company = Tool.CheckQueryString("cm");
        string BU = Tool.CheckQueryString("b");
        string Class = Tool.CheckQueryString("cl");
        string Custom = Tool.CheckQueryString("c");
        string Product = Tool.CheckQueryString("p");
        string Sales = Tool.CheckQueryString("s");
        string StockType = Tool.CheckQueryString("t");
        string AuthCode = Tool.CheckQueryString("au");

        //顯示圖表
        GetChart(sYM, eYM, Company, BU, Class, Product, Custom, Sales, StockType, AuthCode);
    }

    //取得業務實際銷售資料
    private void GetChart(string sYM, string eYM, string Company, string BU, string Class, string Product, string Custom, string Sales, string StockType, string AuthCode)
    {
        //驗証起迄年月格式
        DateTime dd, dd1;
        bool bDD = Tool.ParseDateTime(sYM + "01", out dd);
        bool bDD1 = Tool.ParseDateTime(eYM + "01", out dd1);

        //累加起迄年月值
        ArrayList al = new ArrayList();
        if (bDD && bDD1)
        {
            while (dd <= dd1)
            {
                al.Add(dd.ToString("yyyyMM"));
                dd = dd.AddMonths(1); //累加1個月
            }
        }
        else
        {
            throw new Exception();
        }

        //資料來源
        DataTable dt = BLL_RF.GetSAL05(StockType, sYM, eYM, Company, BU, Class, Product, "", Custom, Sales, "N", AuthCode);
        dt.PrimaryKey = new DataColumn[] { dt.Columns["資料名稱"], dt.Columns["年月"] }; //設定主索引鍵

        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("<chart caption='{0}~{1} ASP趨勢比較圖' xAxisName='月份' yAxisName='單價' showValues='0' numberPrefix='$'>", sYM, eYM);

        //增加Category
        sb.Append("<categories>");
        int i = 1;
        foreach (string ym in al)
        {
            if (i == 1 || ym.Substring(4, 2) == "01") sb.AppendFormat("<vLine label='{0}年' />", ym.Substring(0, 4));

            sb.AppendFormat("<category label='{0}' />", ym.Substring(4, 2));
            i++;
        }
        sb.Append("</categories>");

        //增加項目值
        DataTable dtCategory = dt.DefaultView.ToTable(true, "資料名稱");
        foreach (DataRow row in dtCategory.Rows)
        {
            string strCategory = row["資料名稱"].ToString();
            sb.AppendFormat("<dataset seriesName='{0}'>", strCategory);

            foreach (string ym in al)
            {
                DataRow rowItem = dt.Rows.Find(new object[] { strCategory, ym });
                if (rowItem != null)
                {
                    sb.AppendFormat("<set value='{0}'/>", Math.Round(Convert.ToDecimal(rowItem["ASP"]), 2));
                }
                else
                {
                    sb.Append("<set value='' />");
                }
            }
            sb.Append("</dataset>");
        }

        sb.Append("</chart>");
        Response.Write(sb.ToString());
    }
}