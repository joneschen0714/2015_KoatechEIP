﻿using System;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Net.Mail;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Microsoft.Reporting.WebForms;
using UHR;
using UHR.Util;
using UHR.Authority;

public partial class Default : UHR.BasePage.BasePage
{
    public UserInfo UI = null;

    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M010304";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        UI = UserInfo.SessionState;

        if (!Page.IsPostBack)
        {
            ddlCompany.DataSource = BLL.GetSystemConfig("Company", "");
            ddlCompany.DataBind();
            ddlCompany.Items.Insert(0, new ListItem("全部", ""));

            listBU.DataSource = BLL_ERP.GetINVMA("2", "");
            listBU.DataBind();

            DataTable dt = BLL_RF.GetRF_Group(UI.Account, "業務", "");
            ddlSales.DataSource = dt;
            ddlSales.DataBind();
            ddlSales.Items.Insert(0, new ListItem("全部", ""));

            //記錄層級
            DataRow[] rows = dt.Select("人員代號='" + UI.Account + "'");
            if (rows.Length > 0)
            {
                string AuthCode = rows[0]["層級"].ToString();
                hiddenAuthCode.Value = AuthCode == "A" ? "" : AuthCode;
            }
        }
    }

    protected void btnQuery_Click(object sender, EventArgs e)
    {
        ClearMemory(); //清除記憶體

        //取控制項值
        string strYM = DateTime.Now.ToString("yyyyMM");
        string strCompany = ddlCompany.SelectedValue;
        string strBU = "";
        string strSales = ddlSales.SelectedValue;
        string strCustom = txtCustom.Text.Trim();
        string strProduct = txtProduct.Text.Trim();
        string strAuthCode = hiddenAuthCode.Value;

        foreach(ListItem item in listBU.Items)
        {
            if(item.Selected)
                strBU += item.Text + ",";
        }

        //資料來源
        DataTable dt = BLL_RF.GetSAL04(strYM, strCompany, strBU.TrimEnd(','), strSales, strCustom, strProduct, strAuthCode);

        //報表設定
        ReportViewer1.LocalReport.ReportPath = Tool.GetPhysicalPath + "Report.rdlc";
        ReportViewer1.LocalReport.DataSources.Clear();
        ReportViewer1.LocalReport.DataSources.Add(new ReportDataSource("DataSet1", dt));
        ReportViewer1.LocalReport.Refresh();
        ReportViewer1.Visible = true;
    }

    private void ClearMemory()
    {
        //清除ReportViewer記憶體
        for (int i = 0; i < Session.Count; i++)
        {
            if (Session[i].GetType().ToString() == "Microsoft.Reporting.WebForms.ReportHierarchy")
            {
                Session.RemoveAt(i);
            }
        }
    }
}