﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Xml;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections;
using UHR;
using UHR.Util;

public partial class Ajax : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M010303";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        string sYM = Tool.CheckQueryString("sy");
        string eYM = Tool.CheckQueryString("ey");
        string Company = Tool.CheckQueryString("cm");
        string BU = Tool.CheckQueryString("b");
        string Class = Tool.CheckQueryString("cl");
        string Custom = Tool.CheckQueryString("c");
        string Product = Tool.CheckQueryString("p");
        string Sales = Tool.CheckQueryString("s");
        string Format = Tool.CheckQueryString("f");
        string StockType = Tool.CheckQueryString("t");
        string AuthCode = Tool.CheckQueryString("au");

        //顯示圖表
        GetChart(sYM, eYM, Company, BU, Class, Product, Custom, Sales, Format, StockType, AuthCode);
    }

    //取得業務實際銷售資料
    private void GetChart(string sYM, string eYM, string Company, string BU, string Class, string Product, string Custom, string Sales, string Format, string StockType, string AuthCode)
    {
        //資料來源
        DataTable dt = BLL_RF.GetSAL03(StockType, sYM, eYM, Company, BU, Class, Product, Custom, Sales, AuthCode);

        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("<chart caption='{0}~{1} 圓餅銷售統計圖' showPercentValues='1'>", sYM, eYM);

        //增加項目值
        foreach (DataRow row in dt.Rows)
        {
            sb.AppendFormat("<set label='{0}' value='{1}' />", row["資料名稱"], (Format == "Amount" ? row["本幣金額"] : row["數量M2"]));
        }

        sb.Append("</chart>");
        Response.Write(sb.ToString());
    }
}