﻿using System;
using System.Text;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Net.Mail;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UHR;
using UHR.Util;
using UHR.Authority;

public partial class Default : UHR.BasePage.BasePage
{
    public UserInfo UI = null;

    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0701";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        UI = UserInfo.SessionState;

        //建立Token
        Form.Attributes.Add("token", base.CreateToken());

        //網址參數
        string strAction = Tool.CheckQueryString("a");
        string strAccount = Tool.CheckQueryString("ac");

        //判斷網頁Action
        if (strAction == "getlist")
        {
            int iRecordCount;
            DataTable dtUser = BLL.GetUserList(strAccount, "", "Account", 1, 10, out iRecordCount);

            string strJSON = "{\"list\":[{\"account\":\"aaa\",\"email\":\"aa-email\",\"name\":\"aa-name\"}]}";
            
            Response.Clear();
            Response.Write(strJSON);
            Response.End();
        }
    }
}