﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;
using Newtonsoft.Json;

public partial class Upload : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0601";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnUpload_Click(object sender, EventArgs e)
    {
        //若有選擇檔案
        if (file.HasFile)
        {
            string strMsg = "";

            //判斷副檔名是否為xls
            string fileExtension = System.IO.Path.GetExtension(file.FileName).ToLower(); //如果副檔名有大寫則將他轉為小寫
            if (fileExtension == ".xls")
            {
                //取得並寫入資料
                var dt = NPOITools.RenderDataTableFromExcel(file.FileContent, 0, 0);
                bool bResult = BLL.SetCurrencyRate(dt, ref strMsg);

                //處理結果
                if (bResult)
                {
                    liMsg.Text = GetMessage("success", "作業成功!");
                }
                else
                {
                    liMsg.Text = GetMessage("error", strMsg);
                }
            }
            else
            {
                liMsg.Text = GetMessage("error", "副檔名需為Excel 2003/2007的xls格式!");
            }
        }
        else
        {
            liMsg.Text = GetMessage("warning", "請選擇匯入檔案!");
        }
    }
}