﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using UHR;
using UHR.Util;
using UHR.Authority;

public partial class Default : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0601";
        base.OnPreInit(e);
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //載入匯率類別
            ddlType.DataSource = BLL.GetSystemConfig("CurrencyType", "");
            ddlType.DataBind();

            //載入幣別
            ddlCurrency.DataSource = BLL_ERP.GetCMSMF("");
            ddlCurrency.DataBind();
            ddlCurrency.Items.Insert(0, new ListItem("全部", ""));
        }
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //控制項值
        string strType = ddlType.SelectedValue;
        string strYM = txtYM.Text.Trim();
        string strCurrency = ddlCurrency.SelectedValue;

        //預設排序欄位
        if (gv.SortExpression == "")
        {
            gv.SortExpression = "年月";
        }

        //資料來源
        int iRecordCount;
        DataTable dt = BLL.GetCurrencyRate(strType, strYM, strCurrency, gv.SortingCondition, gv.PageIndex, gv.GridView.PageSize, out iRecordCount);

        if (dt.Rows.Count > 0)
        {
            //欄位設定
            gv.GridView.Columns.Clear();
            gv.AddColumn("類別", "類別", true, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
            gv.AddColumn("年月", "年月", true, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
            gv.AddColumn("幣別", "幣別", true, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
            gv.AddColumn("匯率", "匯率", true, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);

            //GridView相關設定
            gv.RowCount = iRecordCount;
            gv.GridView.DataSource = dt;
            gv.DataBind();
        }
        else
        {
            gv.DataBind();
            liMsg.Text = GetMessage("error", "無資料!");
        }
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        /*
        TableCell cellSex = gv.GetTableCell(e.Row, "性別", false);

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strSex = rowView["SEX"].ToString();

            cellSex.Text = (strSex == "M" ? "男" : "女");
        }
        */
    }

    protected void btnDownload_Click(object sender, EventArgs e)
    {
        //控制項值
        string strType = ddlType.SelectedValue;
        string strYM = txtYM.Text.Trim();
        string strCurrency = ddlCurrency.SelectedValue;

        //資料來源
        int iRecordCount;
        DataTable dt = BLL.GetCurrencyRate(strType, strYM, strCurrency, "年月 DESC, 幣別", 1, int.MaxValue, out iRecordCount);

        //移除欄位
        dt.Columns.Remove("RowNum");
        dt.Columns.Remove("建立者");
        dt.Columns.Remove("建立時間");

        var list = new List<int>();
        var ms = NPOITools.RenderDataTableToExcel(dt, list) as System.IO.MemoryStream;

        string strFileName = string.Format("幣別匯率資料.xls");
        Response.AddHeader("Content-Disposition", string.Format("attachment; filename={0}", Server.UrlPathEncode(strFileName)));
        Response.BinaryWrite(ms.ToArray());
    }
}