﻿using System;
using System.Data;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using UHR;
using UHR.Util;
using UHR.Authority;

public partial class Default : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0504";
        base.OnPreInit(e);
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        string css = "<style>" +
                        "#tbData input{width:100%;color:#000}#tbData td{padding:3px}input.selected{background-color:#99CC99}" +
                     "</style>";

        Page.Header.Controls.Add(new LiteralControl(css));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //建立Token
        Form.Attributes.Add("token", base.CreateToken());

        if (!Page.IsPostBack)
        {
            //載入版本清單
            DataTable dt = BLL_BG.GetBudgetVersion("", "");
            ddlVersion.DataSource = dt;
            ddlVersion.DataBind();
        }
    }

    protected void btnQuery_Click(object sender, EventArgs e)
    {
        //控制項值
        string strVersion = ddlVersion.SelectedValue;
        string strAcc = txtAcc.Text.Trim();

        if (strAcc != "")
        {
            //驗証是否有此部門代碼
            DataTable dtDept = BLL_ERP.GetCMSME(strAcc);
            if (dtDept.Rows.Count == 0)
            {
                liMsg.Text = GetMessage("error", "無此部門代碼!");
                return;
            }

            //資料來源
            DataTable dt = BLL_BG.GetBudgetData(strVersion, strAcc, "", "", "", "", "", "");
            DataTable dtAcct = dt.DefaultView.ToTable(true, "科目代碼", "科目名稱");

            if (dt.Rows.Count > 0)
            {
                //設定主索引鍵
                dt.PrimaryKey = new DataColumn[] { dt.Columns["科目代碼"], dt.Columns["月份"] };

                //設定控制項
                lblVersion.Text = strVersion;
                lblAcc.Text = strAcc;
                lblAccName.Text = "(" + dt.Rows[0]["部門名稱"].ToString() + ")";
                lblYear.Text = dt.Rows[0]["年度"].ToString();

                //依序增加預算項目
                StringBuilder sb = new StringBuilder();
                foreach (DataRow row in dtAcct.Rows)
                {
                    sb.AppendFormat("<tr data-acct='{0}'>", row["科目代碼"]);
                    sb.AppendFormat("<td><a class='copy' title='複製全部' href='#'><i class='ace-icon fa fa-lg fa-files-o'></i></a></td>", row["科目代碼"]);
                    sb.AppendFormat("<td>{0}</td>", row["科目代碼"]);
                    sb.AppendFormat("<td>{0}</td>", row["科目名稱"]);
                    sb.AppendFormat("<td><input type='text' class='input-sm' value='{0}' data-m='01' /></td>", TD(dt.Rows.Find(new object[] { row["科目代碼"], "01" })["金額"]));
                    sb.AppendFormat("<td><input type='text' class='input-sm' value='{0}' data-m='02' /></td>", TD(dt.Rows.Find(new object[] { row["科目代碼"], "02" })["金額"]));
                    sb.AppendFormat("<td><input type='text' class='input-sm' value='{0}' data-m='03' /></td>", TD(dt.Rows.Find(new object[] { row["科目代碼"], "03" })["金額"]));
                    sb.AppendFormat("<td><input type='text' class='input-sm' value='{0}' data-m='04' /></td>", TD(dt.Rows.Find(new object[] { row["科目代碼"], "04" })["金額"]));
                    sb.AppendFormat("<td><input type='text' class='input-sm' value='{0}' data-m='05' /></td>", TD(dt.Rows.Find(new object[] { row["科目代碼"], "05" })["金額"]));
                    sb.AppendFormat("<td><input type='text' class='input-sm' value='{0}' data-m='06' /></td>", TD(dt.Rows.Find(new object[] { row["科目代碼"], "06" })["金額"]));
                    sb.AppendFormat("<td><input type='text' class='input-sm' value='{0}' data-m='07' /></td>", TD(dt.Rows.Find(new object[] { row["科目代碼"], "07" })["金額"]));
                    sb.AppendFormat("<td><input type='text' class='input-sm' value='{0}' data-m='08' /></td>", TD(dt.Rows.Find(new object[] { row["科目代碼"], "08" })["金額"]));
                    sb.AppendFormat("<td><input type='text' class='input-sm' value='{0}' data-m='09' /></td>", TD(dt.Rows.Find(new object[] { row["科目代碼"], "09" })["金額"]));
                    sb.AppendFormat("<td><input type='text' class='input-sm' value='{0}' data-m='10' /></td>", TD(dt.Rows.Find(new object[] { row["科目代碼"], "10" })["金額"]));
                    sb.AppendFormat("<td><input type='text' class='input-sm' value='{0}' data-m='11' /></td>", TD(dt.Rows.Find(new object[] { row["科目代碼"], "11" })["金額"]));
                    sb.AppendFormat("<td><input type='text' class='input-sm' value='{0}' data-m='12' /></td>", TD(dt.Rows.Find(new object[] { row["科目代碼"], "12" })["金額"]));
                    sb.Append("</tr>");
                }

                liItems.Text = sb.ToString();
            }
            else
            {
                liMsg.Text = GetMessage("error", "無資料，請確認!");
            }
        }
        else
        {
            liMsg.Text = GetMessage("error", "預算部門不可空白");
        }
    }

    //轉換Decimal格式
    private string TD(object obj)
    {
        return Convert.ToDecimal(obj).ToString("#.##");
    }
}