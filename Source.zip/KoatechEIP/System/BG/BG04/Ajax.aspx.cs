﻿using System;
using System.Data;
using System.Linq;
using System.Xml;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections;
using UHR;
using UHR.Util;

public partial class Ajax : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0504";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        string strVersion = Request.Form["ver"];
        string strAcc = Request.Form["acc"];
        string strAcct = Request.Form["acct"];
        string strMonth = Request.Form["month"];
        string strAmount = Request.Form["amount"];
        string strToken = Request.Form["token"];

        //驗証Token
        if (!base.VeriftyToken(strToken)) throw new Exception("error");

        bool bResult = BLL_BG.UpdateBudgetValue(strVersion, strAcc, strAcct, strMonth, strAmount);
        Response.Write(bResult);
    }
}