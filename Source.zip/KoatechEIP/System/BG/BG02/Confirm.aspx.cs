﻿using System;
using System.Data;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;
using UHR.Authority;
using Newtonsoft.Json;

public partial class Confirm : UHR.BasePage.BasePage
{
    string VERSION;
    public UserInfo UI = null;

    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0502";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //設定登入者個人資料
        UI = UserInfo.SessionState;

        //取得參數
        VERSION = Tool.CheckQueryString("v");

        if (!Page.IsPostBack)
        {
            lblVersion.Text = VERSION;

            DataBind();
        }
    }

    public override void DataBind()
    {
        //組成業務人員清單
        string strSalesList = "";
        DataTable dtGroup = BLL_RF.GetRF_Group(UI.Account, "業務", "");
        foreach (DataRow row in dtGroup.Rows)
        {
            strSalesList += row["人員代號"].ToString() + ",";
        }

        //取得營收預算資料
        DataTable dtResult = BLL_BG.GetSaleBudgetData("", VERSION, "", "", "", "", strSalesList, "");
        DataTable dtSalesList = dtResult.DefaultView.ToTable(true, "業務員代號", "業務員姓名", "狀態碼");

        StringBuilder sb = new StringBuilder();
        foreach (DataRow rowSales in dtSalesList.Rows)
        {
            string strSalesCode = rowSales["業務員代號"].ToString();
            string strSalesName = rowSales["業務員姓名"].ToString();
            string strStatus = rowSales["狀態碼"].ToString();

            //狀態碼圖示
            switch (strStatus)
            {
                case "Y":
                    strStatus = "<a title='確認' href='#' onclick=\"ChangeStatus('" + strSalesCode + "', 'N')\"><i class='ace-icon fa fa-lg fa-check-square-o'></i></a>";
                    break;
                case "N":
                    strStatus = "<a title='未確認' href='#' onclick=\"ChangeStatus('" + strSalesCode + "', 'Y')\"><i class='ace-icon fa fa-lg fa-square-o'></i></a>";
                    break;
            }

            sb.Append("<tr>");
            sb.AppendFormat("<td>{0}</td>", strSalesCode);
            sb.AppendFormat("<td>{0}</td>", strSalesName);
            sb.AppendFormat("<td>{0}</td>", strStatus);
            sb.Append("</tr>");
        }

        liItems.Text = sb.ToString();
    }

    protected void btnConfirm_Click(object sender, EventArgs e)
    {
        //控制項值
        string strSalesCode = hiddenSales.Value;
        string strStatus = hiddenStatus.Value;

        //呼叫函式
        bool bResult = BLL_BG.SetSaleBudgetStatus(strSalesCode, VERSION, strStatus);

        if (bResult)
        {
            //重新整理頁面
            DataBind();
        }
        else
        {
            liMsg.Text = GetMessage("error", "作業失敗!");
        }
    }
}