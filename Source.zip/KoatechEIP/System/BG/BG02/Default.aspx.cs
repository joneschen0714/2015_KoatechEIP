﻿using System;
using System.Linq;
using System.Data;
using System.Web.UI;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using UHR;
using UHR.Util;
using UHR.Authority;

public partial class Default : UHR.BasePage.BasePage
{
    public UserInfo UI = null;

    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0502";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //設定登入者個人資料
        UI = UserInfo.SessionState;

        if (!Page.IsPostBack)
        {
            //按鈕權限
            menuUpload.Visible = PageAuthority.Import;
            menuDownload.Visible = PageAuthority.Export;
            menuConfirm.Visible = PageAuthority.Audit;
            btnQuery.Visible = PageAuthority.Query;

            //載入版本清單
            DataTable dt = BLL_BG.GetBudgetVersion("", "");
            ddlVersion.DataSource = dt;
            ddlVersion.DataBind();

            //預設負責的業務
            DataTable dtGroup = null;
            if (!UI.IsSuper && !PageAuthority.Admin)
                dtGroup = BLL_RF.GetRF_Group(UI.Account, "業務", "");
            else
                dtGroup = BLL_RF.GetRF_Group("", "業務", "");

            foreach (DataRow row in dtGroup.Rows)
            {
                string strName = Convert.ToString(row["FirstName"]) + Convert.ToString(row["LastName"]);
                string strCode = Convert.ToString(row["Account"]);
                ddlSales.Items.Add(new ListItem(strName, strCode));
            }
            ddlSales.Items.Insert(0, new ListItem("全部", ""));

        }
    }

    protected void btnQuery_Click(object sender, EventArgs e)
    {
        ClearMemory(); //清除記憶體

        //控制項值
        string strVersion = ddlVersion.SelectedValue;
        string strSales = ddlSales.SelectedValue;
        string strStatus = ddlStatus.SelectedValue;
        string strReport = ddlReport.SelectedValue;
        string strSalesList = "";

        //若為全部，則組成人員清單
        if (strSales == "")
            foreach (ListItem item in ddlSales.Items)
                strSalesList += item.Value + ",";

        //資料來源
        DataTable dt = BLL_BG.GetSaleBudgetData("", strVersion, "", strSales, "", "", strSalesList, strStatus);

        //處理資料
        if (dt.Rows.Count > 0)
        {
            //報表設定
            ReportViewer1.LocalReport.ReportPath = Tool.GetPhysicalPath + strReport;
            ReportViewer1.LocalReport.DataSources.Clear();
            ReportViewer1.LocalReport.DataSources.Add(new ReportDataSource("DataSet1", dt));
            ReportViewer1.LocalReport.Refresh();
            ReportViewer1.Visible = true;
        }
        else
        {
            ReportViewer1.Visible = false;
            liMsg.Text = GetMessage("error", "無資料，請確認!");
        }
    }

    protected void btnDownload_Click(object sender, EventArgs e)
    {
        //控制項值
        string strYear = DateTime.Now.Year.ToString();
        string strSales = ddlSales.SelectedValue;
        string strSalesName = ddlSales.SelectedItem.Text;

        if (strSales != "")
        {
            //取得實際營收資料
            DataTable dt = BLL_RF.GetRealityData("", strYear, "", strSales, "", "", "");
            dt.Columns["日期"].ColumnName = "年月";
            DataTable dtNew = dt.Clone();

            //欄位設定
            dtNew.Columns.Add("預算版本", Type.GetType("System.String"));
            dtNew.Columns.Add("預算部門", Type.GetType("System.String"));
            dtNew.Columns.Add("付款條件", Type.GetType("System.String"));
            dtNew.Columns.Add("銷貨類別", Type.GetType("System.String"));

            //彙總資料
            var result = from t in dt.AsEnumerable()
                         group t by new
                         {
                             公司別 = t.Field<string>("公司別"),
                             業務員代號 = t.Field<string>("業務員代號"),
                             年月 = t.Field<string>("年月").Substring(0, 6),
                             客戶簡稱 = t.Field<string>("客戶簡稱"),
                             品號 = t.Field<string>("品號"),
                             品名 = t.Field<string>("品名"),
                             規格 = t.Field<string>("規格"),
                             幣別 = t.Field<string>("幣別"),
                             單位 = t.Field<string>("單位")
                         } into g
                         select new
                         {
                             Key = g.Key,
                             單價 = g.Average(a => a.Field<decimal?>("單價")),
                             數量 = g.Sum(a => a.Field<decimal?>("數量")),
                         };

            //依序增加彙總資料
            foreach (var item in result)
            {
                DataRow row = dtNew.NewRow();
                row["公司別"] = item.Key.公司別;
                row["業務員代號"] = item.Key.業務員代號;
                row["年月"] = item.Key.年月;
                row["客戶簡稱"] = item.Key.客戶簡稱;
                row["品號"] = item.Key.品號;
                row["品名"] = item.Key.品名;
                row["規格"] = item.Key.規格;
                row["幣別"] = SetCurrency(item.Key.幣別);
                row["單價"] = Math.Round(item.單價.Value, 2);
                row["單位"] = item.Key.單位;
                row["數量"] = item.數量;

                //取得客戶資料
                DataTable dtCustom = BLL_ERP.GetCOPMA("", "", item.Key.客戶簡稱);
                if (dtCustom.Rows.Count > 0)
                {
                    row["付款條件"] = dtCustom.Rows[0]["MA031"].ToString();
                }



                dtNew.Rows.Add(row);
            }

            //轉成指定格式
            dtNew.DefaultView.Sort = "年月, 客戶簡稱";
            DataTable dtResult = dtNew.DefaultView.ToTable(false, "公司別", "預算版本", "預算部門", "業務員代號", "年月", "客戶簡稱", "付款條件", "銷貨類別", "品號", "品名", "規格", "幣別", "單價", "單位", "數量");

            var list = new List<int>();
            var ms = NPOITools.RenderDataTableToExcel(dtResult, list) as System.IO.MemoryStream;

            string strFileName = string.Format("{0} {1} 實際營收資料.xls", strSalesName, strYear);
            Response.AddHeader("Content-Disposition", string.Format("attachment; filename={0}", Server.UrlPathEncode(strFileName)));
            Response.BinaryWrite(ms.ToArray());
        }
        else
        {
            liMsg.Text = GetMessage("error", "請選擇業務人員!");
        }
    }

    //轉換幣別
    private string SetCurrency(string _currency)
    {
        switch (_currency)
        {
            case "RMB":
                _currency = "CNY";
                break;
        }

        return _currency;
    }

    private void ClearMemory()
    {
        //清除ReportViewer記憶體
        for (int i = 0; i < Session.Count; i++)
        {
            if (Session[i].GetType().ToString() == "Microsoft.Reporting.WebForms.ReportHierarchy")
            {
                Session.RemoveAt(i);
            }
        }
    }
}