﻿using System;
using System.Data;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;
using Newtonsoft.Json;

public partial class Confirm : UHR.BasePage.BasePage
{
    string VERSION;

    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0501";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //取得參數
        VERSION = Tool.CheckQueryString("v");

        if (!Page.IsPostBack)
        {
            lblVersion.Text = VERSION;

            DataBind();
        }
    }

    public override void DataBind()
    {
        //資料來源
        DataTable dt = BLL_BG.GetVersionList(VERSION, "", "");

        //依序增加項目
        StringBuilder sb = new StringBuilder();
        foreach (DataRow row in dt.Rows)
        {
            string strAcc = row["部門代碼"].ToString();
            string strAccName = row["部門名稱"].ToString();
            string strStatus = row["確認碼"].ToString();

            //狀態碼圖示
            switch (strStatus)
            {
                case "Y":
                    strStatus = "<a title='鎖定' href='#' onclick=\"ChangeStatus('" + strAcc + "', 'N')\"><i class='ace-icon fa fa-lg fa-check-square-o'></i></a>";
                    break;
                case "N":
                    strStatus = "<a title='未鎖定' href='#' onclick=\"ChangeStatus('" + strAcc + "', 'Y')\"><i class='ace-icon fa fa-lg fa-square-o'></i></a>";
                    break;
            }

            sb.Append("<tr>");
            sb.AppendFormat("<td>{0}</td>", strAcc);
            sb.AppendFormat("<td>{0}</td>", strAccName);
            sb.AppendFormat("<td>{0}</td>", strStatus);
            sb.Append("</tr>");
        }

        liItems.Text = sb.ToString();
    }

    protected void btnConfirm_Click(object sender, EventArgs e)
    {
        //控制項值
        string strVersion = VERSION;
        string strAcc = hiddenAcc.Value;
        string strStatus = hiddenStatus.Value;

        //呼叫函式
        string strMsg = "";
        bool bResult = BLL_BG.SetVersionStatus(strVersion, strAcc, strStatus, ref strMsg);

        if (bResult)
        {
            //重新整理頁面
            DataBind();
        }
        else
        {
            liMsg.Text = GetMessage("error", strMsg);
        }
    }
}