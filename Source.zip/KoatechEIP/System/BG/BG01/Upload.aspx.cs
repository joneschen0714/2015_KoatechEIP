﻿using System;
using System.Data;
using System.Net.Mail;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;
using UHR.Authority;
using Newtonsoft.Json;

public partial class Upload : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0501";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnUpload_Click(object sender, EventArgs e)
    {
        //若有選擇檔案
        if (file.HasFile)
        {
            string strMsg = "";
            bool bResult = false;

            //判斷副檔名是否為xls
            string fileExtension = System.IO.Path.GetExtension(file.FileName).ToLower(); //如果副檔名有大寫則將他轉為小寫
            if (fileExtension == ".xls")
            {
                //上傳檔案
                string strFileName = "BG01.xls";
                string strFilePath = Server.MapPath("~/Temp/");
                file.SaveAs(strFilePath + strFileName);

                //檔案轉成Stream
                var fi = File.Open(strFilePath + strFileName, FileMode.Open);
                DataTable dt = NPOITools.RenderDataTableFromExcel(fi, 0, 0);
                bResult = BLL_BG.SetBudgetData(dt, ref strMsg);

                //處理結果
                if (bResult)
                {
                    liMsg.Text = GetMessage("success", "作業成功!");

                    #region 建立Mail通知
                    //取得此頁面功能管理者名單
                    string strAdminEmail = "";
                    DataTable dtAdmin = BLL.GetUserAuthority("", base.MENU_NO, "", "Y", true);
                    foreach (DataRow row in dtAdmin.Rows)
                    {
                        DataRow rowAdmin = BLL.GetUserInfo("", Convert.ToString(row["Account"]), "").Rows[0]; //管理者資料

                        //組管理者Email清單
                        strAdminEmail += rowAdmin["Email"].ToString() + ",";
                    }

                    UserInfo ui = UserInfo.SessionState; //登入者物件

                    //設定變數
                    string strUserName = ui.FirstName + ui.LastName;
                    string strUploadTime = DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss");

                    //內容
                    TemplateMail _template = new TemplateMail("~/configuration/MailTemplate/BG/BG01.htm");
                    _template["{使用者名稱}"] = strUserName;
                    _template["{上傳時間}"] = strUploadTime;
                    _template["{版本}"] = dt.Rows[0]["版本"].ToString();
                    _template["{部門代碼}"] = dt.Rows[0]["部門代碼"].ToString();

                    //Mail物件設定
                    Mail _mail = new Mail();
                    _mail.From = new MailAddress(Definition.MailAccount);
                    _mail.To.Add(strAdminEmail.TrimEnd(','));
                    _mail.Subject = string.Format("{0} 於 {1} 上傳了費用預算資料!", strUserName, strUploadTime);
                    _mail.Attachments.Add(new Attachment(strFilePath + strFileName));
                    _mail.Body = _template.ToString();
                    _mail.IsBodyHtml = true;
                    _mail.SendMail();
                    _mail.Dispose();
                    #endregion
                }
                else
                {
                    liMsg.Text = GetMessage("error", strMsg);
                }
            }
            else
            {
                liMsg.Text = GetMessage("error", "副檔名需為Excel 2003/2007的xls格式!");
            }
        }
        else
        {
            liMsg.Text = GetMessage("warning", "請選擇匯入檔案!");
        }
    }
}