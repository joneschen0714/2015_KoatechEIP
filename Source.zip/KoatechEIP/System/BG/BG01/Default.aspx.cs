﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using UHR;
using UHR.Util;
using UHR.Authority;

public partial class Default : UHR.BasePage.BasePage
{
    UserInfo UI = null;

    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0501";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        UI = UserInfo.SessionState;

        if (!Page.IsPostBack)
        {
            //按鈕權限
            menuUpload.Visible = PageAuthority.Import;
            menuConfirm.Visible = PageAuthority.Audit;
            btnQuery.Visible = PageAuthority.Query;

            //載入版本清單
            DataTable dt = BLL_BG.GetBudgetVersion("", "");
            ddlVersion.DataSource = dt;
            ddlVersion.DataBind();

            //判斷是否為預算系統編輯人員
            if (!UI.IsSuper && !PageAuthority.Admin)
            {
                string strAcctDept = BLL_BG.GetAcctDept(UI.Account);
                if (strAcctDept == "")
                {
                    liMsg.Text = GetMessage("error", "您不是預算系統指定編輯人員!");
                    menuUpload.Visible = false;
                    menuConfirm.Visible = false;
                    btnQuery.Visible = false;
                }
                else
                {
                    hiddenAcctDept.Value = strAcctDept;
                }
            }
        }
    }

    protected void btnQuery_Click(object sender, EventArgs e)
    {
        ClearMemory(); //清除記憶體

        //控制項值
        string strVersion = ddlVersion.SelectedValue;
        string strAcc = txtAcc.Text.Trim();
        string strAcct = txtAcct.Text.Trim();
        string strSMonth = txtSMonth.Text.Trim();
        string strEMonth = txtEMonth.Text.Trim();
        string strStatus = ddlStatus.SelectedValue;
        string strReportType = ddlType.SelectedValue;

        //資料來源
        DataTable dt = BLL_BG.GetBudgetData(strVersion, strAcc, strAcct, "", strSMonth, strEMonth, strStatus, hiddenAcctDept.Value);

        //若無管理權限，則刪除敏感會計科目
        if (!UI.IsSuper && !PageAuthority.Admin)
        {
            dt.DefaultView.RowFilter = "科目名稱 NOT LIKE '%薪資%' AND 科目名稱 NOT LIKE '%伙食%'";
        }

        //處理資料
        if (dt.DefaultView.Count > 0)
        {
            //報表設定
            ReportViewer1.LocalReport.ReportPath = Tool.GetPhysicalPath + strReportType;
            ReportViewer1.LocalReport.DataSources.Clear();
            ReportViewer1.LocalReport.DataSources.Add(new ReportDataSource("DataSet1", dt.DefaultView));
            ReportViewer1.LocalReport.Refresh();
            ReportViewer1.Visible = true;
        }
        else
        {
            ReportViewer1.Visible = false;
            liMsg.Text = GetMessage("error", "無資料，請確認!");
        }
    }

    private void ClearMemory()
    {
        //清除ReportViewer記憶體
        for (int i = 0; i < Session.Count; i++)
        {
            if (Session[i].GetType().ToString() == "Microsoft.Reporting.WebForms.ReportHierarchy")
            {
                Session.RemoveAt(i);
            }
        }
    }
}