﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;
using Newtonsoft.Json;

public partial class UploadERP : UHR.BasePage.BasePage
{
    string VERSION = "";

    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0503";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        VERSION = Tool.CheckQueryString("v");

        if (!IsPostBack)
        {
            lblContent.Text = "您將要上傳" + VERSION + "的預算版本至ERP，是否確定上傳?";
        }
    }

    protected void btnSendToERP_Click(object sender, EventArgs e)
    {
        //控制項值
        string btnText = (sender as Button).Text;

        string strMsg = "";
        bool bResult = false;

        //寫入ERP
        if (btnText == "上傳正式區")
        {
            bResult = BLL_BG.SendToERP("正式", VERSION, ref strMsg);
        }
        else if (btnText == "上傳測試區")
        {
            bResult = BLL_BG.SendToERP("測試", VERSION, ref strMsg);
        }

        //處理結果
        if (bResult)
        {
            liMsg.Text = GetMessage("success", "作業成功!");
        }
        else
        {
            liMsg.Text = GetMessage("error", strMsg);
        }
    }
}