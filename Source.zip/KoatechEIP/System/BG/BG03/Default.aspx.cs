﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using UHR;
using UHR.Util;
using UHR.Authority;

public partial class Default : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0503";
        base.OnPreInit(e);
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            gv_GridDataBind(new object(), new EventArgs());
        }
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //參數
        string strVersion = txtVersion.Text.Trim();
        string strLock = ddlLock.SelectedValue;

        //資料來源
        DataTable dt = BLL_BG.GetBudgetVersion(strVersion, strLock);

        gv.GridView.Columns.Clear();
        gv.AddColumn("預算版本", "預算版本", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("說明", "說明", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("鎖定碼", "鎖定碼", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("預算上傳", "", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("管理", "", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);

        gv.GridView.PageSize = int.MaxValue;
        gv.RowCount = dt.Rows.Count;
        gv.GridView.DataSource = dt;
        gv.DataBind();
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        TableCell cellLock = gv.GetTableCell(e.Row, "鎖定碼", false);
        TableCell cellUpload = gv.GetTableCell(e.Row, "預算上傳", false);
        TableCell cellManage = gv.GetTableCell(e.Row, "管理", false);

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strLock = rowView["鎖定碼"].ToString();
            string strVersion = rowView["預算版本"].ToString();

            if (strLock == "Y")
            {
                cellLock.Text = "<a title='鎖定' href='#' onclick=\"ChangeStatus('" + strVersion + "', 'N')\"><i class='ace-icon fa fa-lg fa-check-square-o'></i></a>";
            }
            else if (strLock == "N")
            {
                cellLock.Text = "<a title='未鎖定' href='#' onclick=\"ChangeStatus('" + strVersion + "', 'Y')\"><i class='ace-icon fa fa-lg fa-square-o'></i></a>";
            }

            cellUpload.Text = "<a title='預算資料上傳' href='#' onclick=\"ShowDialog('upload', '')\"><i class='ace-icon fa fa-lg fa-cloud-upload'></i></a>";
            cellManage.Text = "<a title='複製版本' href='#' onclick=\"ShowDialog('copy', '" + strVersion + "')\"><i class='ace-icon fa fa-lg fa-files-o'></i></a>　" +
                              "<a title='上傳ERP' href='#' onclick=\"ShowDialog('uploaderp', '" + strVersion + "')\"><i class='ace-icon fa fa-lg fa-upload'></i></a>";
        }
    }

    protected void btnLock_Click(object sender, EventArgs e)
    {
        string strVersion = hiddenVersion.Value;
        string strStatus = hiddenStatus.Value;

        bool bResult = BLL_BG.SetBudgetVersionLock(strVersion, strStatus);

        if (bResult)
        {
            gv_GridDataBind(sender, e);
        }
        else
        {
            liMsg.Text = GetMessage("error", "作業失敗!");
        }
    }
}