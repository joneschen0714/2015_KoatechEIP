﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;
using Newtonsoft.Json;

public partial class CopyVersion : UHR.BasePage.BasePage
{
    string VERSION = "";

    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0503";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        VERSION = Tool.CheckQueryString("v");

        if (!IsPostBack)
        {
            lblContent.Text = "您是否要複製" + VERSION + "的預算版本?";
        }
    }

    protected void btnCopy_Click(object sender, EventArgs e)
    {
        //控制項值
        string strNewVersion = txtNewVersion.Text.Trim();

        string strMsg = "";
        bool bResult = BLL_BG.CopyVersion(VERSION, strNewVersion, ref strMsg);

        //處理結果
        if (bResult)
        {
            liMsg.Text = GetMessage("success", "作業成功!");
        }
        else
        {
            liMsg.Text = GetMessage("error", strMsg);
        }
    }
}