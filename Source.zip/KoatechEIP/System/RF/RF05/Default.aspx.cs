﻿using System;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UHR;
using UHR.Util;
using UHR.Authority;

public partial class Default : UHR.BasePage.BasePage
{
    public UserInfo UI = null;

    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0403";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        UI = UserInfo.SessionState;

        if (!Page.IsPostBack)
        {
            //預設負責的業務
            DataTable dtGroup = BLL_RF.GetRF_Group(UI.Account, "業務","");
            foreach (DataRow row in dtGroup.Rows)
            {
                string strName = Convert.ToString(row["FirstName"]) + Convert.ToString(row["LastName"]);
                string strCode = Convert.ToString(row["Account"]);
                q_ddlSales.Items.Add(new ListItem(strName, strCode));
            }
            q_ddlSales.Items.Insert(0, new ListItem("全部", ""));

            //預設載入上下3個月
            for (int i = -3; i <= 3; i++)
            {
                string strYM = DateTime.Now.AddMonths(i).ToString("yyyyMM");
                q_ddlYM.Items.Add(new ListItem(strYM));
            }
            q_ddlYM.SelectedValue = DateTime.Now.ToString("yyyyMM");
        }
    }
}