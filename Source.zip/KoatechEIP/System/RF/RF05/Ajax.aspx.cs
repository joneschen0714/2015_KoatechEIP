﻿using System;
using System.Data;
using System.Linq;
using System.Xml;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections;
using UHR;
using UHR.Util;

public partial class Ajax : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0402";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        string type = Tool.CheckQueryString("t");
        string 公司別 = Tool.CheckQueryString("c");
        string 年月 = Tool.CheckQueryString("ym");
        string 銷售分類 = Tool.CheckQueryString("cl");
        string 業務人員代號 = Tool.CheckQueryString("s");
        string 業務人員清單 = Tool.CheckQueryString("sl");
        string 客戶簡稱 = Tool.CheckQueryString("cn");
        string 品名 = Tool.CheckQueryString("pn");
        string 顯示格式 = Tool.CheckQueryString("f");

        switch (type)
        {
            case "GetChartByCustom":
                GetChartByCustom(公司別, 年月, 業務人員代號, 顯示格式);
                break;
        }
    }

    //取得歷史版本與實際資料(BY 客戶)
    private void GetChartByCustom(string 公司別, string 年月, string 業務員代號, string 顯示格式)
    {
        DataTable dt = GetData(公司別, 年月, 業務員代號);
        DataTable dtVersion = dt.DefaultView.ToTable(true, "版本");

        //彙總資料
        var result = from t in dt.AsEnumerable()
                     group t by new { 客戶簡稱 = t["客戶簡稱"] } into g
                     select new
                     {
                         客戶簡稱 = g.Key.客戶簡稱,
                         資料 = g
                     };

        string strChart = string.Format("<chart caption='{0} {1} 版本比較表' xAxisName='客戶' SYAxisMaxValue='100' SYAxisMinValue='0' setAdaptiveSYMin='1' showValues='0' formatNumberScale='1' numberScaleValue='10000' numberScaleUnit='萬' sNumberSuffix='%' labelDisplay='WRAP' bgColor='FFFFFF,EEEEEE' showBorder='1' borderColor='#CCCCCC'>", 年月, 業務員代號);
        string strCategories = "<categories>";
        Hashtable htDataset = new Hashtable();

        //讀取客戶的資料
        foreach (var item in result)
        {
            strCategories += string.Format("<category label='{0}' />", item.客戶簡稱); //(X軸)

            //讀取版本別
            foreach (DataRow rowVersion in dtVersion.Rows)
            {
                string strVersion = rowVersion["版本"].ToString(); //版本
                if (htDataset[strVersion] == null)
                {
                    htDataset.Add(strVersion, "<dataset seriesname='" + strVersion + "金額'>");
                }

                var Amount = item.資料.Where(x => x.Field<string>("版本") == strVersion).Select(x => x.Field<decimal?>("本幣金額")).Sum();
                htDataset[strVersion] += "<set value='" + Amount + "' />";
            }
        }

        strCategories += "</categories>";
        foreach (DictionaryEntry item in htDataset)
        {
            strCategories += htDataset[item.Key] + "</dataset>";
        }

        strChart += strCategories + "</chart>";
        Response.Write(strChart);
    }

    //資料來源
    private DataTable GetData(string 公司別, string 年月, string 業務員代號)
    {
        //資料來源
        DataTable dtSale = BLL_RF.GetRealityData(公司別, 年月, "", 業務員代號, "", "", "");
        DataTable dt1 = BLL_RF.GetForecastHistoryData(公司別, 年月, "", 業務員代號, "", "", "","");

        //增加虛擬欄位
        dtSale.Columns.Add("版本", Type.GetType("System.String"));
        foreach (DataRow row in dtSale.Rows)
        {
            row["版本"] = "實際";
        }

        //合併預測與實際的DataTable
        foreach (DataRow row in dt1.Rows)
        {
            DataRow newRow = dtSale.NewRow();
            newRow["公司別"] = Convert.ToString(row["公司別"]);
            newRow["日期"] = Convert.ToString(row["預測年月"]);
            newRow["業務員代號"] = Convert.ToString(row["業務員代號"]);
            newRow["業務員姓名"] = Convert.ToString(row["業務員姓名"]);
            newRow["客戶簡稱"] = Convert.ToString(row["客戶簡稱"]);
            newRow["數量M2"] = Convert.ToDecimal(row["數量M2"]);
            newRow["本幣金額"] = Convert.ToDecimal(row["本幣金額"]);
            newRow["版本"] = Convert.ToString(row["版本"]);
            dtSale.Rows.Add(newRow);
        }

        return dtSale;
    }
}