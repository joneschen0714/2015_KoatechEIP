﻿using System;
using System.Data;
using System.Linq;
using System.Xml;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections;
using UHR;
using UHR.Util;

public partial class Ajax : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0402";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        string type = Tool.CheckQueryString("t");
        string 公司別 = Tool.CheckQueryString("c");
        string 年月 = Tool.CheckQueryString("ym");
        string 銷售分類 = Tool.CheckQueryString("cl");
        string 業務人員代號 = Tool.CheckQueryString("s");
        string 業務人員清單 = Tool.CheckQueryString("sl");
        string 客戶簡稱 = Tool.CheckQueryString("cn");
        string 品名 = Tool.CheckQueryString("pn");
        string 顯示格式 = Tool.CheckQueryString("f");
        string 版本 = Tool.CheckQueryString("v");

        switch (type)
        {
            case "GetChartBySales":
                GetChartBySales(年月, 版本, 業務人員清單, 顯示格式);
                break;
            case "GetChartByCustom":
                GetChartByCustom(年月, 版本, 業務人員代號, 顯示格式);
                break;
            case "GetChartByProductName":
                GetChartByProductName(年月, 版本, 客戶簡稱, 業務人員代號, 顯示格式);
                break;
            case "GetChartByProductNum":
                GetChartByProductNum(年月, 版本, 客戶簡稱, 業務人員代號, 品名, 顯示格式);
                break;
            case "GetChartByMonth":
                GetChartByMonth(公司別, 年月, 業務人員清單, 顯示格式);
                break;
            case "GetChartByBU":
                GetChartByBU(公司別, 年月, 業務人員清單, 顯示格式);
                break;
        }
    }

    //取得業務實際銷售資料(BY 業務員)
    private void GetChartBySales(string 年月, string 版本, string 業務人員清單, string 顯示格式)
    {
        //資料來源
        DataTable dt = BLL_RF.GetAllForecastData("", 年月, 版本, "", "", "", "", 業務人員清單);

        //彙總資料
        var result = from t in dt.AsEnumerable()
                     group t by new { 業務員代號 = t.Field<string>("業務員代號"), 業務員姓名 = t.Field<string>("業務員姓名") } into g
                     select new
                     {
                         業務員代號 = g.Key.業務員代號,
                         業務員姓名 = g.Key.業務員姓名,
                         實際金額 = g.Sum(a => a.Field<decimal?>("本幣金額")),
                         預測金額 = g.Sum(a => a.Field<decimal?>("本幣預測金額")),
                         數量M2 = g.Sum(a => a.Field<decimal?>("數量M2")),
                         預測數量M2 = g.Sum(a => a.Field<decimal?>("預測數量M2"))
                     };

        string strChart = string.Format("<chart caption='{0} {1}實際銷售資料' xAxisName='業務員' sYAxisMaxValue='100' sYAxisMinValue='0' setAdaptiveSYMin='1' showValues='0' formatNumberScale='1' numberScaleValue='10000' numberScaleUnit='萬' sNumberSuffix='%' labelDisplay='WRAP' bgColor='FFFFFF,EEEEEE' showBorder='1' borderColor='#CCCCCC'>", 年月, 版本);
        string strCategories = "<categories>";
        string strDataset1 = "<dataset seriesname='實際金額'>";
        string strDataset2 = "<dataset seriesname='預測金額'>";
        string strDataset3 = "<dataset seriesname='達成率' parentyaxis='S'>";

        switch (顯示格式)
        {
            case "米平方單位":
                strDataset1 = "<dataset seriesname='實際M2'>";
                strDataset2 = "<dataset seriesname='預測M2'>";
                break;
        }

        foreach (var i in result)
        {
            strCategories += string.Format("<category label='{0}' />", i.業務員姓名); //業務員(X軸)

            switch (顯示格式)
            {
                case "本幣金額":
                    strDataset1 += string.Format("<set value='{0}' link='j-LoadChartByCustom-{1},{2}' />", i.實際金額, 年月, i.業務員代號);
                    strDataset2 += string.Format("<set value='{0}' link='j-LoadChartByCustom-{1},{2}' />", i.預測金額, 年月, i.業務員代號);
                    strDataset3 += string.Format("<set value='{0}' />", (i.預測金額 != 0 ? (i.實際金額 / i.預測金額) * 100 : 0));
                    break;
                case "米平方單位":
                    strDataset1 += string.Format("<set value='{0}' link='j-LoadChartByCustom-{1},{2}' />", i.數量M2, 年月, i.業務員代號);
                    strDataset2 += string.Format("<set value='{0}' link='j-LoadChartByCustom-{1},{2}' />", i.預測數量M2, 年月, i.業務員代號);
                    strDataset3 += string.Format("<set value='{0}' />", (i.預測數量M2 != 0 ? (i.數量M2 / i.預測數量M2) * 100 : 0));
                    break;
            }
        }

        strCategories += "</categories>";
        strDataset1 += "</dataset>";
        strDataset2 += "</dataset>";
        strDataset3 += "</dataset>";

        strChart += strCategories + strDataset1 + strDataset2 + strDataset3 + "</chart>";
        Response.Write(strChart);
    }

    //取得業務實際銷售資料(BY 客戶)
    private void GetChartByCustom(string 年月, string 版本, string 業務員代號, string 顯示格式)
    {
        //資料來源
        DataTable dt = BLL_RF.GetAllForecastData("", 年月, 版本, "", 業務員代號, "", "", "");

        //彙總資料
        var result = from t in dt.AsEnumerable()
                     group t by new { 客戶簡稱 = t["客戶簡稱"] } into g
                     select new
                     {
                         客戶簡稱 = g.Key.客戶簡稱,
                         實際金額 = g.Sum(a => a.Field<decimal?>("本幣金額")),
                         預測金額 = g.Sum(a => a.Field<decimal?>("本幣預測金額")),
                         數量M2 = g.Sum(a => a.Field<decimal?>("數量M2")),
                         預測數量M2 = g.Sum(a => a.Field<decimal?>("預測數量M2"))
                     };

        string strName = dt.Rows.Count > 0 ? dt.Rows[0]["業務員姓名"].ToString() : ""; //業務員姓名
        string strChart = string.Format("<chart caption='{0} {1} {2}實際銷售資料' xAxisName='客戶' SYAxisMaxValue='100' SYAxisMinValue='0' setAdaptiveSYMin='1' showValues='0' formatNumberScale='1' numberScaleValue='10000' numberScaleUnit='萬' sNumberSuffix='%' labelDisplay='WRAP' bgColor='FFFFFF,EEEEEE' showBorder='1' borderColor='#CCCCCC'>", 年月, strName, 版本);
        string strCategories = "<categories>";
        string strDataset1 = "<dataset seriesname='實際金額'>";
        string strDataset2 = "<dataset seriesname='預測金額'>";
        string strDataset3 = "<dataset seriesname='達成率' parentyaxis='S'>";

        switch (顯示格式)
        {
            case "米平方單位":
                strDataset1 = "<dataset seriesname='實際M2'>";
                strDataset2 = "<dataset seriesname='預測M2'>";
                break;
        }

        foreach (var i in result)
        {
            strCategories += string.Format("<category label='{0}' />", i.客戶簡稱); //客戶簡稱(X軸)

            switch (顯示格式)
            {
                case "本幣金額":
                    strDataset1 += string.Format("<set value='{0}' link='j-LoadChartByProductName-{1},{2},{3}' />", i.實際金額, 年月, i.客戶簡稱, 業務員代號);
                    strDataset2 += string.Format("<set value='{0}' link='j-LoadChartByProductName-{1},{2},{3}' />", i.預測金額, 年月, i.客戶簡稱, 業務員代號);
                    strDataset3 += string.Format("<set value='{0}' />", (i.預測金額 != 0 ? (i.實際金額 / i.預測金額) * 100 : 0));
                    break;
                case "米平方單位":
                    strDataset1 += string.Format("<set value='{0}' link='j-LoadChartByProductName-{1},{2},{3}' />", i.數量M2, 年月, i.客戶簡稱, 業務員代號);
                    strDataset2 += string.Format("<set value='{0}' link='j-LoadChartByProductName-{1},{2},{3}' />", i.預測數量M2, 年月, i.客戶簡稱, 業務員代號);
                    strDataset3 += string.Format("<set value='{0}' />", (i.預測數量M2 != 0 ? (i.數量M2 / i.預測數量M2) * 100 : 0));
                    break;
            }
        }

        strCategories += "</categories>";
        strDataset1 += "</dataset>";
        strDataset2 += "</dataset>";
        strDataset3 += "</dataset>";

        strChart += strCategories + strDataset1 + strDataset2 + strDataset3 + "</chart>";
        Response.Write(strChart);
    }

    //取得業務實際銷售的品項資料(BY 客戶 > 品名)
    private void GetChartByProductName(string 年月, string 版本, string 客戶簡稱, string 業務員代號, string 顯示格式)
    {
        //資料來源
        DataTable dt = BLL_RF.GetAllForecastData("", 年月, 版本, "", 業務員代號, 客戶簡稱, "", "");

        //彙總資料
        var result = from t in dt.AsEnumerable()
                     group t by new { 客戶簡稱 = t["客戶簡稱"], 品名 = t["品名"] } into g
                     select new
                     {
                         客戶簡稱 = g.Key.客戶簡稱,
                         品名 = g.Key.品名,
                         實際金額 = g.Sum(a => a.Field<decimal?>("本幣金額")),
                         預測金額 = g.Sum(a => a.Field<decimal?>("本幣預測金額")),
                         數量M2 = g.Sum(a => a.Field<decimal?>("數量M2")),
                         預測數量M2 = g.Sum(a => a.Field<decimal?>("預測數量M2"))
                     };

        string strChart = string.Format("<chart caption='{0} {1} {2}銷售預測比較' xAxisName='品名' SYAxisMaxValue='100' SYAxisMinValue='0' setAdaptiveSYMin='1' showValues='0' formatNumberScale='1' numberScaleValue='10000' numberScaleUnit='萬' sNumberSuffix='%' labelDisplay='WRAP' bgColor='FFFFFF,EEEEEE' showBorder='1' borderColor='#CCCCCC'>", 年月, 客戶簡稱, 版本);
        string strCategories = "<categories>";
        string strDataset1 = "<dataset seriesname='實際金額'>";
        string strDataset2 = "<dataset seriesname='預測金額'>";
        string strDataset3 = "<dataset seriesname='達成率' parentyaxis='S'>";

        switch (顯示格式)
        {
            case "米平方單位":
                strDataset1 = "<dataset seriesname='實際M2'>";
                strDataset2 = "<dataset seriesname='預測M2'>";
                break;
        }

        foreach (var i in result)
        {
            strCategories += string.Format("<category label='{0}' />", i.品名); //客戶簡稱(X軸)

            switch (顯示格式)
            {
                case "本幣金額":
                    strDataset1 += string.Format("<set value='{0}' link='j-LoadChartByProductNum-{1},{2},{3},{4}' />", i.實際金額, 年月, i.客戶簡稱, 業務員代號, i.品名);
                    strDataset2 += string.Format("<set value='{0}' link='j-LoadChartByProductNum-{1},{2},{3},{4}' />", i.預測金額, 年月, i.客戶簡稱, 業務員代號, i.品名);
                    strDataset3 += string.Format("<set value='{0}' />", (i.預測金額 != 0 ? (i.實際金額 / i.預測金額) * 100 : 0));
                    break;
                case "米平方單位":
                    strDataset1 += string.Format("<set value='{0}' link='j-LoadChartByProductNum-{1},{2},{3},{4}' />", i.數量M2, 年月, i.客戶簡稱, 業務員代號, i.品名);
                    strDataset2 += string.Format("<set value='{0}' link='j-LoadChartByProductNum-{1},{2},{3},{4}' />", i.預測數量M2, 年月, i.客戶簡稱, 業務員代號, i.品名);
                    strDataset3 += string.Format("<set value='{0}' />", (i.預測數量M2 != 0 ? (i.數量M2 / i.預測數量M2) * 100 : 0));
                    break;
            }
        }

        strCategories += "</categories>";
        strDataset1 += "</dataset>";
        strDataset2 += "</dataset>";
        strDataset3 += "</dataset>";

        strChart += strCategories + strDataset1 + strDataset2 + strDataset3 + "</chart>";
        Response.Write(strChart);
    }

    //取得業務實際銷售的品項資料 (BY 品名 > 品號)
    private void GetChartByProductNum(string 年月, string 版本, string 客戶簡稱, string 業務員代號, string 品名, string 顯示格式)
    {
        //資料來源
        DataTable dt = BLL_RF.GetAllForecastData("", 年月, 版本, "", 業務員代號, 客戶簡稱, 品名, "");

        //彙總資料
        var result = from t in dt.AsEnumerable()
                     group t by new { 規格 = t["規格"] } into g
                     select new
                     {
                         規格 = g.Key.規格,
                         實際金額 = g.Sum(a => a.Field<decimal?>("本幣金額")),
                         預測金額 = g.Sum(a => a.Field<decimal?>("本幣預測金額")),
                         數量M2 = g.Sum(a => a.Field<decimal?>("數量M2")),
                         預測數量M2 = g.Sum(a => a.Field<decimal?>("預測數量M2"))
                     };

        string strChart = string.Format("<chart caption='{0} {1} {2} {3}銷售預測比較' xAxisName='規格' SYAxisMaxValue='100' SYAxisMinValue='0' setAdaptiveSYMin='1' showValues='0' formatNumberScale='1' numberScaleValue='10000' numberScaleUnit='萬' sNumberSuffix='%' labelDisplay='WRAP' bgColor='FFFFFF,EEEEEE' showBorder='1' borderColor='#CCCCCC'>", 年月, 客戶簡稱, 品名, 版本);
        string strCategories = "<categories>";
        string strDataset1 = "<dataset seriesname='實際金額'>";
        string strDataset2 = "<dataset seriesname='預測金額'>";
        string strDataset3 = "<dataset seriesname='達成率' parentyaxis='S'>";

        switch (顯示格式)
        {
            case "米平方單位":
                strDataset1 = "<dataset seriesname='實際M2'>";
                strDataset2 = "<dataset seriesname='預測M2'>";
                break;
        }

        foreach (var i in result)
        {
            strCategories += string.Format("<category label='{0}' />", i.規格); //客戶簡稱(X軸)

            switch (顯示格式)
            {
                case "本幣金額":
                    strDataset1 += string.Format("<set value='{0}' />", i.實際金額);
                    strDataset2 += string.Format("<set value='{0}' />", i.預測金額);
                    strDataset3 += string.Format("<set value='{0}' />", (i.預測金額 != 0 ? (i.實際金額 / i.預測金額) * 100 : 0));
                    break;
                case "米平方單位":
                    strDataset1 += string.Format("<set value='{0}' />", i.數量M2);
                    strDataset2 += string.Format("<set value='{0}' />", i.預測數量M2);
                    strDataset3 += string.Format("<set value='{0}' />", (i.預測數量M2 != 0 ? (i.數量M2 / i.預測數量M2) * 100 : 0));
                    break;
            }
        }

        strCategories += "</categories>";
        strDataset1 += "</dataset>";
        strDataset2 += "</dataset>";
        strDataset3 += "</dataset>";

        strChart += strCategories + strDataset1 + strDataset2 + strDataset3 + "</chart>";
        Response.Write(strChart);
    }

    //取得業務實際銷售資料 (BY 月份)
    private void GetChartByMonth(string 公司別, string 年份, string 業務人員清單, string 顯示格式)
    {
        //資料來源
        DataTable dt = BLL_RF.GetAllForecastData(公司別, 年份, "", "", "", "", "", 業務人員清單);

        //彙總資料
        var result = from t in dt.AsEnumerable()
                     group t by new { 月份 = t.Field<string>("日期").Substring(4, 2) } into g
                     orderby g.Key.月份
                     select new
                     {
                         Key = g.Key,
                         實際金額 = g.Sum(a => a.Field<decimal?>("本幣金額")),
                         預測金額 = g.Sum(a => a.Field<decimal?>("本幣預測金額")),
                         數量M2 = g.Sum(a => a.Field<decimal?>("數量M2")),
                         預測數量M2 = g.Sum(a => a.Field<decimal?>("預測數量M2"))
                     };

        string strChart = string.Format("<chart caption='{0} {1} 實際銷售資料' xAxisName='月份' SYAxisMaxValue='100' SYAxisMinValue='0' setAdaptiveSYMin='1' showValues='0' formatNumberScale='1' numberScaleValue='10000' numberScaleUnit='萬' sNumberSuffix='%' labelDisplay='WRAP' bgColor='FFFFFF,EEEEEE' showBorder='1' borderColor='#CCCCCC'>", 公司別, 年份);
        string strCategories = "<categories>";
        string strDataset1 = "<dataset seriesname='實際金額'>";
        string strDataset2 = "<dataset seriesname='預測金額'>";
        string strDataset3 = "<dataset seriesname='達成率' parentyaxis='S'>";

        switch (顯示格式)
        {
            case "米平方單位":
                strDataset1 = "<dataset seriesname='實際M2'>";
                strDataset2 = "<dataset seriesname='預測M2'>";
                break;
        }

        foreach (var i in result)
        {
            strCategories += string.Format("<category label='{0}月' />", i.Key.月份.TrimStart('0')); //月份(X軸)

            switch (顯示格式)
            {
                case "本幣金額":
                    strDataset1 += string.Format("<set value='{0}' link='j-LoadChartByBU-{1}' />", i.實際金額, 年份 + i.Key.月份);
                    strDataset2 += string.Format("<set value='{0}' link='j-LoadChartByBU-{1}' />", i.預測金額, 年份 + i.Key.月份);
                    strDataset3 += string.Format("<set value='{0}' />", (i.預測金額 != 0 ? (i.實際金額 / i.預測金額) * 100 : 0));
                    break;
                case "米平方單位":
                    strDataset1 += string.Format("<set value='{0}' link='j-LoadChartByBU-{1}' />", i.數量M2, 年份 + i.Key.月份);
                    strDataset2 += string.Format("<set value='{0}' link='j-LoadChartByBU-{1}' />", i.預測數量M2, 年份 + i.Key.月份);
                    strDataset3 += string.Format("<set value='{0}' />", (i.預測數量M2 != 0 ? (i.數量M2 / i.預測數量M2) * 100 : 0));
                    break;
            }
        }

        strCategories += "</categories>";
        strDataset1 += "</dataset>";
        strDataset2 += "</dataset>";
        strDataset3 += "</dataset>";

        strChart += strCategories + strDataset1 + strDataset2 + strDataset3 + "</chart>";
        Response.Write(strChart);
    }

    //取得業務實際銷售資料 (BY BU分類)
    private void GetChartByBU(string 公司別, string 年月, string 業務人員清單, string 顯示格式)
    {
        //資料來源
        DataTable dt = BLL_RF.GetAllForecastData(公司別, 年月, "", "", "", "", "", 業務人員清單);

        //彙總資料
        var result = from t in dt.AsEnumerable()
                     group t by new { 銷售分類 = t.Field<string>("銷售分類") } into g
                     orderby g.Key.銷售分類
                     select new
                     {
                         Key = g.Key,
                         實際金額 = g.Sum(a => a.Field<decimal?>("本幣金額")),
                         預測金額 = g.Sum(a => a.Field<decimal?>("本幣預測金額")),
                         數量M2 = g.Sum(a => a.Field<decimal?>("數量M2")),
                         預測數量M2 = g.Sum(a => a.Field<decimal?>("預測數量M2"))
                     };

        string strChart = string.Format("<chart caption='{0} {1} 實際銷售資料' xAxisName='銷售分類' SYAxisMaxValue='100' SYAxisMinValue='0' setAdaptiveSYMin='1' showValues='0' formatNumberScale='1' numberScaleValue='10000' numberScaleUnit='萬' sNumberSuffix='%' labelDisplay='WRAP' bgColor='FFFFFF,EEEEEE' showBorder='1' borderColor='#CCCCCC'>", 公司別, 年月);
        string strCategories = "<categories>";
        string strDataset1 = "<dataset seriesname='實際金額'>";
        string strDataset2 = "<dataset seriesname='預測金額'>";
        string strDataset3 = "<dataset seriesname='達成率' parentyaxis='S'>";

        switch (顯示格式)
        {
            case "米平方單位":
                strDataset1 = "<dataset seriesname='實際M2'>";
                strDataset2 = "<dataset seriesname='預測M2'>";
                break;
        }

        foreach (var i in result)
        {
            strCategories += string.Format("<category label='{0}' />", i.Key.銷售分類); //(X軸)

            switch (顯示格式)
            {
                case "本幣金額":
                    strDataset1 += string.Format("<set value='{0}' />", i.實際金額);
                    strDataset2 += string.Format("<set value='{0}' />", i.預測金額);
                    strDataset3 += string.Format("<set value='{0}' />", (i.預測金額 != 0 ? (i.實際金額 / i.預測金額) * 100 : 0));
                    break;
                case "米平方單位":
                    strDataset1 += string.Format("<set value='{0}' />", i.數量M2);
                    strDataset2 += string.Format("<set value='{0}' />", i.預測數量M2);
                    strDataset3 += string.Format("<set value='{0}' />", (i.預測數量M2 != 0 ? (i.數量M2 / i.預測數量M2) * 100 : 0));
                    break;
            }
        }

        strCategories += "</categories>";
        strDataset1 += "</dataset>";
        strDataset2 += "</dataset>";
        strDataset3 += "</dataset>";

        strChart += strCategories + strDataset1 + strDataset2 + strDataset3 + "</chart>";
        Response.Write(strChart);
    }
}