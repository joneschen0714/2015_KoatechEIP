﻿using System;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UHR;
using UHR.Util;
using UHR.Authority;

public partial class Default : UHR.BasePage.BasePage
{
    public UserInfo UI = null;

    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0402";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        UI = UserInfo.SessionState;

        //網址參數
        string strYM = Tool.CheckQueryString("ym");
        string strVersion = Tool.CheckQueryString("ver");

        if (!Page.IsPostBack)
        {
            //預設負責的業務
            DataTable dtGroup = BLL_RF.GetRF_Group(UI.Account, "業務", "");
            foreach (DataRow row in dtGroup.Rows)
            {
                string strName = Convert.ToString(row["FirstName"]) + Convert.ToString(row["LastName"]);
                string strCode = Convert.ToString(row["Account"]);
                q_ddlSales.Items.Add(new ListItem(strName, strCode));
            }
            q_ddlSales.Items.Insert(0, new ListItem("全部", ""));

            //預設載入上下3個月
            for (int i = -3; i <= 3; i++)
            {
                string sYM = DateTime.Now.AddMonths(i).ToString("yyyyMM");
                q_ddlYM.Items.Add(new ListItem(sYM));
            }

            //設定值
            q_ddlYM.SelectedValue = (strYM != "" ? strYM : DateTime.Now.ToString("yyyyMM"));
            q_ddlVersion.SelectedValue = (strVersion != "" ? strVersion : "");

            //判斷是否有網址參數，若有則執行查詢
            if ((strYM + strVersion) != "")
            {
                liScript.Text = "<script>btnQuery_Click();</script>";
            }
        }
    }
}