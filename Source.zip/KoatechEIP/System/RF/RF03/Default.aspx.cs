﻿using System;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Net.Mail;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Microsoft.Reporting.WebForms;
using UHR;
using UHR.Util;
using UHR.Authority;

public partial class Default : UHR.BasePage.BasePage
{
    public UserInfo UI = null;

    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0403";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        UI = UserInfo.SessionState;

        if (!Page.IsPostBack)
        {
            //預設負責的業務
            DataTable dtGroup = BLL_RF.GetRF_Group(UI.Account, "業務", "");
            foreach (DataRow row in dtGroup.Rows)
            {
                string strName = Convert.ToString(row["FirstName"]) + Convert.ToString(row["LastName"]);
                string strCode = Convert.ToString(row["Account"]);
                q_ddlSales.Items.Add(new ListItem(strName, strCode));
            }
            if (q_ddlSales.Items.Count > 1)
            {
                q_ddlSales.Items.Insert(0, new ListItem("全部", ""));
            }

            //預設載入上下3個月
            for (int i = -3; i <= 3; i++)
            {
                string strYM = DateTime.Now.AddMonths(i).ToString("yyyyMM");
                q_ddlYM.Items.Add(new ListItem(strYM));
            }
            q_ddlYM.SelectedValue = DateTime.Now.ToString("yyyyMM");
        }
    }

    protected void btnQuery_Click(object sender, EventArgs e)
    {
        ClearMemory(); //清除記憶體

        //查詢值
        string strSalesList = "";
        string strSales = q_ddlSales.SelectedValue;
        string strYM = q_ddlYM.SelectedValue;

        //若選全部，則組成業務員清單
        if (strSales == "")
        {
            foreach (ListItem li in q_ddlSales.Items)
            {
                strSalesList += li.Value + ",";
            }
        }

        //資料來源
        DataTable dt = BLL_RF.GetForecastHistoryData("", strYM, "", strSales, "", "", "", strSalesList);
        DataTable dtSale = BLL_RF.GetRealityData("", strYM, "", strSales, "", "", strSalesList);

        //增加虛擬欄位
        dtSale.Columns.Add("版本", Type.GetType("System.String"));

        //整批給予欄位預設值
        foreach (DataRow row in dtSale.Rows)
        {
            row["版本"] = "實際銷售";
        }

        //合併預測與實際的DataTable
        foreach (DataRow row in dt.Rows)
        {
            decimal dQty = Convert.ToDecimal(row["數量M2"]);
            decimal dAmount = Convert.ToDecimal(row["本幣金額"]);

            //若有預測數量或金額
            if (dQty + dAmount > 0)
            {
                DataRow newRow = dtSale.NewRow();
                newRow["公司別"] = row["公司別"];
                newRow["日期"] = row["預測年月"];
                newRow["業務員姓名"] = row["業務員姓名"];
                newRow["客戶簡稱"] = row["客戶簡稱"];
                newRow["品名"] = row["品名"];
                newRow["規格"] = row["規格"];
                newRow["數量M2"] = row["數量M2"];
                newRow["本幣金額"] = row["本幣金額"];
                newRow["版本"] = row["版本"];
                dtSale.Rows.Add(newRow);
            }
        }

        //報表設定
        ReportViewer1.LocalReport.ReportPath = Tool.GetPhysicalPath + "Report.rdlc";
        ReportViewer1.LocalReport.DataSources.Clear();
        ReportViewer1.LocalReport.DataSources.Add(new ReportDataSource("DataSet1", dtSale));
        ReportViewer1.LocalReport.SetParameters(new ReportParameter("YM", strYM));
        ReportViewer1.LocalReport.Refresh();
        ReportViewer1.Visible = true;
    }

    private void ClearMemory()
    {
        //清除ReportViewer記憶體
        for (int i = 0; i < Session.Count; i++)
        {
            if (Session[i].GetType().ToString() == "Microsoft.Reporting.WebForms.ReportHierarchy")
            {
                Session.RemoveAt(i);
            }
        }
    }
}