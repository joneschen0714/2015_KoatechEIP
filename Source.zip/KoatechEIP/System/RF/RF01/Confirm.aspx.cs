﻿using System;
using System.Data;
using System.Net.Mail;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;
using UHR.Authority;
using Newtonsoft.Json;

public partial class Confirm : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0401";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //取得參數
            string type = Tool.CheckQueryString("t");
            string sales = Tool.CheckQueryString("s");
            string ym = Tool.CheckQueryString("ym");

            hiddenSales.Value = sales;
            hiddenYM.Value = ym;

            DataRow ui = BLL.GetUserInfo("", sales, "").Rows[0];
            hiddenSalesName.Value = string.Format("{0}{1}", ui["FirstName"], ui["LastName"]);
            hiddenSalesEmail.Value = ui["Email"].ToString();

            DataBind();
        }
    }

    protected new void DataBind()
    {
        //判斷狀態碼
        DataTable dtResult = DAL_RF.GetForecastData("", "", hiddenYM.Value, "", hiddenSales.Value, "", "", "");
        if (dtResult.Rows.Count > 0)
        {
            string strStatus = dtResult.Rows[0]["狀態碼"].ToString();
            string strStatus1 = "";
            switch (strStatus)
            {
                case "Y":
                    strStatus1 = "已審核";
                    btnAllow.Enabled = false;
                    btnReject.Enabled = false;
                    break;
                case "S":
                    //取得待辦事項的審核者
                    string strParams = string.Format("sl={0}&ym={1}", hiddenSales.Value, hiddenYM.Value);
                    DataRow rowWork = BLL.GetWorkList("Forecast", "", strParams).Rows[0];
                    DataRow rowUser = BLL.GetUserInfo("", rowWork["Account"].ToString(), "").Rows[0];

                    strStatus1 = string.Format("{0}{1}審核中", rowUser["FirstName"], rowUser["LastName"]);
                    btnAllow.Enabled = true;
                    btnReject.Enabled = true;
                    break;
                case "N":
                    strStatus1 = "未審核";
                    btnAllow.Enabled = false;
                    btnReject.Enabled = false;
                    break;
                case "V":
                    strStatus1 = "退件";
                    btnAllow.Enabled = false;
                    btnReject.Enabled = false;
                    break;
            }

            lblContent.Text = "您是否要審閱" + hiddenSalesName.Value + hiddenYM.Value + "的銷售預測資料?<br/>狀態碼：" + strStatus1;
        }
        else
        {
            lblContent.Text = "無資料";
            btnAllow.Enabled = false;
            btnReject.Enabled = false;
        }
    }

    protected void btnAudit_Click(object sender, EventArgs e)
    {
        UserInfo ui = UserInfo.SessionState;

        string strSales = hiddenSales.Value;
        string strYM = hiddenYM.Value;
        string strStatus = (sender as Button).CommandArgument;
        string strMessageg = txtMsg.Text.Trim().Replace(Environment.NewLine, "<br/>");
        string strParams = string.Format("sl={0}&ym={1}", strSales, strYM);

        TemplateMail _template = null;
        string strSubject = "";
        string strToEmail = "";

        bool bResult = false;
        string msg = "";

        //判斷通過或退件
        if (strStatus == "V")
        {
            bResult = BLL_RF.AuditRF_Version(strYM, strSales, strStatus, ref msg); //審核函式
            msg = "已退件給業務員，作業成功!";

            #region Mail內容設定
            //主旨與通知Mail
            strSubject = "您的" + strYM + "本週銷售預測版本已被退件";
            strToEmail = hiddenSalesEmail.Value;

            //通知業務退件內容
            _template = new TemplateMail("~/configuration/MailTemplate/RF/Confirm.htm");
            _template["{業務員姓名}"] = hiddenSalesName.Value;
            _template["{預測年月}"] = strYM;
            _template["{業務員代號}"] = strSales;
            _template["{審核訊息}"] = strMessageg;
            _template["{內文}"] = string.Format("您的 {0} 本週銷售預測版本已被退件!<br/>請點擊以下連結至EIP平台查閱與修改後再次送簽<br/>", strYM);
            #endregion

            //刪除待辦事項
            BLL.DelWorkList("Forecast", ui.Account, strParams);
        }
        else if (strStatus == "Y")
        {
            //判斷上層是否需審核
            DataTable dtManage = BLL_RF.GetGroupManage(ui.Account, "Y");
            if (dtManage.Rows.Count > 0)
            {
                DataRow rowManage = dtManage.Rows[0];
                bResult = true;
                msg = "已Mail通知" + rowManage["姓名"].ToString() + "請求審核!";

                #region Mail內容設定
                //主旨與通知Mail
                strSubject = hiddenSalesName.Value + strYM + "本週銷售預測版本審核通知";
                strToEmail = rowManage["Email"].ToString();

                //通知上層請求審核內容
                _template = new TemplateMail("~/configuration/MailTemplate/RF/Audit.htm");
                _template["{主管名稱}"] = Convert.ToString(rowManage["姓名"]);
                _template["{預測年月}"] = strYM;
                _template["{業務員代號}"] = strSales;
                _template["{業務員姓名}"] = hiddenSalesName.Value;
                #endregion

                //建立主管待辦事項
                string strWorkSubject = string.Format("{0}{1}銷售預測資料審核", hiddenSalesName.Value, strYM);
                BLL.SetWorkList("Forecast", rowManage["Account"].ToString(), strParams, strWorkSubject);
                BLL.DelWorkList("Forecast", ui.Account, strParams);
            }
            else
            {
                bResult = BLL_RF.AuditRF_Version(strYM, strSales, strStatus, ref msg); //審核函式
                msg = "已審核通過，作業成功!";

                #region Mail內容設定
                //主旨與通知Mail
                strSubject = "您的" + strYM + "本週銷售預測版本已審核通過";
                strToEmail = hiddenSalesEmail.Value;

                //通知業務退件內容
                _template = new TemplateMail("~/configuration/MailTemplate/RF/Confirm.htm");
                _template["{業務員姓名}"] = hiddenSalesName.Value;
                _template["{預測年月}"] = strYM;
                _template["{業務員代號}"] = strSales;
                _template["{審核訊息}"] = strMessageg;
                _template["{內文}"] = string.Format("您的 {0} 本週銷售預測版本已審核通過!", strYM);
                #endregion

                //刪除待辦事項
                BLL.DelWorkList("Forecast", ui.Account, strParams);
            }
        }

        //結果判斷
        if (bResult)
        {
            #region 建立Mail通知
            Mail _mail = new Mail();
            _mail.From = new MailAddress(Definition.MailAccount);
            //_mail.To.Add("jones_chen@koatech.com.tw");
            _mail.To.Add(strToEmail);
            _mail.Subject = strSubject;
            _mail.Body = _template.ToString();
            _mail.IsBodyHtml = true;
            _mail.SendMail();
            _mail.Dispose();
            #endregion

            //重新整理頁面
            DataBind();

            liMsg.Text = GetMessage("success", msg);
        }
        else
        {
            liMsg.Text = GetMessage("error", msg);
        }
    }
}