﻿using System;
using System.Data;
using System.Net.Mail;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;
using UHR.Authority;
using Newtonsoft.Json;

public partial class Chart : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0401";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //取得參數
            string Type = Request["t"].Trim();
            string Company = Request["m"].Trim();
            string Custom = Request["c"].Trim();
            string Currency = Request["n"].Trim();
            string ProductNum = Request["p"].Trim();
            string YM = Request["ym"].Trim();
            string strToken = Request["token"].Trim();

            //驗証Token
            if (!base.VeriftyToken(strToken)) throw new Exception("error");

            switch (Type)
            {
                case "price":
                    Chart1(Company, Custom, ProductNum, Currency, YM);
                    break;
                case "qty":
                    Chart2(Company, Custom, ProductNum, Currency, YM);
                    break;
            }
        }
    }

    private void Chart1(string Company, string Custom, string ProductNum, string Currency, string YM)
    {
        DataTable dtResult = BLL_RF.GetAvgSaleData(Company, Custom, ProductNum, Currency, YM);

        string strJSON = "<chart caption='近三月實際銷售單價趨勢圖' xAxisName='月份' yAxisName='單價' numberPrefix='$' animation='0' placeValuesInside='1'>{Items}</chart>";

        string strItems = "";
        foreach (DataRow row in dtResult.Rows)
        {
            strItems += string.Format("<set label='{0}' value='{1}' />", row["年月"], Math.Round((decimal)row["單價"], 2));
        }

        strJSON = strJSON.Replace("{Items}", strItems);

        Response.Clear();
        Response.Write(strJSON);
        Response.End();
    }

    private void Chart2(string Company, string Custom, string ProductNum, string Currency, string YM)
    {
        DataTable dtResult = BLL_RF.GetAvgSaleData(Company, Custom, ProductNum, Currency, YM);

        string strJSON = "<chart caption='近三月實際銷售數量趨勢圖' xAxisName='月份' yAxisName='數量' numberScaleValue='10000' numberScaleUnit='萬' numberPrefix='$' animation='0' placeValuesInside='1'>{Items}</chart>";

        string strItems = "";
        foreach (DataRow row in dtResult.Rows)
        {
            strItems += string.Format("<set label='{0}' value='{1}' />", row["年月"], Math.Round((decimal)row["數量"]));
        }

        strJSON = strJSON.Replace("{Items}", strItems);

        Response.Clear();
        Response.Write(strJSON);
        Response.End();
    }
}