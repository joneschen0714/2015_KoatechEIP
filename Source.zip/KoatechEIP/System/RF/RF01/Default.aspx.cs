﻿using System;
using System.Text;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Net.Mail;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UHR;
using UHR.Util;
using UHR.Authority;

public partial class Default : UHR.BasePage.BasePage
{
    public UserInfo UI = null;

    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0401";
        base.OnPreInit(e);
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        repList.ItemDataBound += new RepeaterItemEventHandler(repList_ItemDataBound);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        UI = UserInfo.SessionState;

        //建立Token
        Form.Attributes.Add("token", base.CreateToken());

        //網址參數
        string strSales = Tool.CheckQueryString("sl");
        string strYM = Tool.CheckQueryString("ym");

        if (!Page.IsPostBack)
        {
            //設定頁面權限
            menuUpload.Visible = PageAuthority.Import;
            menuDownload.Visible = PageAuthority.Export;
            menuConfirm.Visible = PageAuthority.Audit;
            menuRequest.Visible = PageAuthority.Edit || PageAuthority.Add;
            btnQuery.Visible = PageAuthority.Query;
            btnSave.Visible = PageAuthority.Edit;

            //預設負責的業務
            DataTable dtGroup = BLL_RF.GetRF_Group(UI.Account, "業務", "");
            foreach (DataRow row in dtGroup.Rows)
            {
                string strName = Convert.ToString(row["FirstName"]) + Convert.ToString(row["LastName"]);
                string strCode = Convert.ToString(row["Account"]);
                q_ddlSales.Items.Add(new ListItem(strName, strCode));
            }

            //預設載入上下3個月
            for (int i = -3; i <= 3; i++)
            {
                string sYM = DateTime.Now.AddMonths(i).ToString("yyyyMM");
                q_ddlYM.Items.Add(new ListItem(sYM));
            }

            //設定值
            q_ddlSales.SelectedValue = (strSales != "" ? strSales : "");
            q_ddlYM.SelectedValue = (strYM != "" ? strYM : DateTime.Now.ToString("yyyyMM"));

            //判斷是否有網址參數，若有則執行查詢
            if ((strSales + strYM) != "")
            {
                btnQuery_Click(sender, e);
            }
        }
    }

    protected void btnQuery_Click(object sender, EventArgs e)
    {
        //查詢值
        string strSales = q_ddlSales.SelectedValue;
        string strYM = q_ddlYM.SelectedValue;

        //資料來源
        DataTable dt = BLL_RF.GetForecastData("", "", strYM, "", strSales, "", "", "");

        //處理資料
        if (dt.Rows.Count > 0)
        {
            repList.DataSource = dt;
            repList.DataBind();
        }
        else
        {
            repList.DataBind();
            liMsg.Text = GetMessage("error", "無資料，請確認!");
        }
    }

    protected void repList_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Header)
        {
            //資料來源
            DataTable dt = (DataTable)repList.DataSource;
            DataRow r = dt.Rows[0];

            //取得控制項
            Label lblYM = (Label)e.Item.FindControl("lblYM");
            Label lblStatus = (Label)e.Item.FindControl("lblStatus");

            switch (r["狀態碼"].ToString())
            {
                case "Y":
                    lblStatus.Text = "已審核";
                    break;
                case "S":
                    //取得待辦事項的審核者
                    string strParams = string.Format("sl={0}&ym={1}", q_ddlSales.SelectedValue, q_ddlYM.SelectedValue);
                    DataRow rowWork = BLL.GetWorkList("Forecast", "", strParams).Rows[0];
                    DataRow rowUser = BLL.GetUserInfo("", rowWork["Account"].ToString(), "").Rows[0];

                    lblStatus.Text = string.Format("{0}{1}審核中", rowUser["FirstName"], rowUser["LastName"]);
                    break;
                case "N":
                    lblStatus.Text = "未審核";
                    break;
                case "V":
                    lblStatus.Text = "退件";
                    break;
            }

            lblYM.Text = r["預測年月"].ToString();
        }
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            DataRowView rowView = (DataRowView)e.Item.DataItem; //資料來源
            string strCompany = rowView["公司別"].ToString();
            string strCustom = rowView["客戶簡稱"].ToString();
            string strProduct = rowView["品號"].ToString();
            string strCurrency = rowView["幣別"].ToString();
            decimal dUnitPrice = Convert.ToDecimal(rowView["單價"]);
            decimal dAvgUnitPrice = 0;
            decimal dAvgQty = 0;

            //取平均單價與數量
            DataTable dtAVG = BLL_RF.GetAvgSaleData(strCompany, strCustom, strProduct, strCurrency, q_ddlYM.SelectedValue);
            dAvgUnitPrice = dtAVG.Rows.Count == 0 ? 0 : (decimal)dtAVG.Compute("Avg(單價)", string.Empty);
            dAvgQty = dtAVG.Rows.Count == 0 ? 0 : (decimal)dtAVG.Compute("Avg(數量)", string.Empty);

            //取得控制項
            HiddenField hiddenID = (HiddenField)e.Item.FindControl("hiddenID");
            Literal liAvgUnitPrice = (Literal)e.Item.FindControl("liAvgUnitPrice");
            TextBox txtQty = (TextBox)e.Item.FindControl("txtQty");
            TextBox txtDesc = (TextBox)e.Item.FindControl("txtDesc");

            hiddenID.Value = Convert.ToString(rowView["ID"]);
            txtQty.Text = Convert.ToString(rowView["數量"]);
            txtQty.Attributes.Add("data-value", txtQty.Text);
            txtDesc.Attributes.Add("placeholder", Convert.ToString(rowView["說明"]));

            //判斷單價高低
            if (dAvgUnitPrice != 0)
            {
                decimal dd1 = (dAvgUnitPrice - dUnitPrice) / dAvgUnitPrice;
                if (dd1 >= Convert.ToDecimal(0.05))
                {
                    liAvgUnitPrice.Text = "<div class='badge badge-danger'>" + Math.Round(dd1 * 100) + "%</div>";
                }
                else if (dd1 <= Convert.ToDecimal(-0.05))
                {
                    liAvgUnitPrice.Text = "<div class='badge badge-success'>" + Math.Round(dd1 * -100) + "%</div>";
                }
            }

            txtQty.Attributes.Add("data-avg", dAvgQty.ToString());
        }
    }

    protected void btnDownload_Click(object sender, EventArgs e)
    {
        //控制項值
        string strSales = q_ddlSales.SelectedValue;
        string strName = q_ddlSales.SelectedItem.Text;
        string strYM = q_ddlYM.SelectedValue;

        //資料來源
        DataTable dtWEB = BLL_RF.GetForecastData("", "", strYM, "", strSales, "", "", "");

        //排序欄位
        dtWEB.DefaultView.Sort = "客戶簡稱, 品號";
        DataTable dtNew = dtWEB.DefaultView.ToTable(false, "公司別", "預測年月", "業務員代號", "客戶簡稱", "品號", "幣別", "單價", "數量", "說明");

        var list = new List<int>();
        var ms = NPOITools.RenderDataTableToExcel(dtNew, list) as System.IO.MemoryStream;

        string strFileName = string.Format("{0} {1} 銷售預測資料.xls", strName, strYM);
        Response.AddHeader("Content-Disposition", string.Format("attachment; filename={0}", Server.UrlPathEncode(strFileName)));
        Response.BinaryWrite(ms.ToArray());
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        var list = new List<dynamic>();
        foreach (RepeaterItem item in repList.Items)
        {
            //取得控制項
            HiddenField hiddenID = (HiddenField)item.FindControl("hiddenID");
            TextBox txtQty = (TextBox)item.FindControl("txtQty");
            TextBox txtDesc = (TextBox)item.FindControl("txtDesc");

            //濾出有輸入說明的資料
            if (txtDesc.Text.Trim() != "")
            {
                //取值加入集合
                dynamic ii = new JObject();
                ii.ID = hiddenID.Value;
                ii.Qty = txtQty.Text.Trim() == "" ? "0" : txtQty.Text.Trim();
                ii.Desc = txtDesc.Text.Trim();
                list.Add(ii);
            }
        }

        //批次更新
        string msg = "";
        bool bResult = BLL_RF.UpdateRFItem(list, ref msg);

        //結果判斷
        if (bResult)
        {
            liMsg.Text = GetMessage("success", "作業成功!");
            btnQuery_Click(sender, e);
        }
        else
        {
            liMsg.Text = GetMessage("error", msg);
        }
    }

    protected void btnSend_Click(object sender, EventArgs e)
    {
        string strSales = q_ddlSales.SelectedValue;
        string strName = q_ddlSales.SelectedItem.Text;
        string strYM = q_ddlYM.SelectedValue;

        string msg = "";
        bool bResult = BLL_RF.AuditRF_Version(strYM, strSales, "S", ref msg); //審核函式

        //結果判斷
        if (bResult)
        {
            #region 建立Mail通知
            //上層主管資料
            DataRow rowManage = BLL_RF.GetGroupManage(strSales, "Y").Rows[0];
            string strMAccount = rowManage["Account"].ToString();
            string strEmail = Convert.ToString(rowManage["Email"]);

            //內容
            TemplateMail _template = new TemplateMail("~/configuration/MailTemplate/RF/Audit.htm");
            _template["{主管名稱}"] = Convert.ToString(rowManage["姓名"]);
            _template["{預測年月}"] = strYM;
            _template["{業務員代號}"] = strSales;
            _template["{業務員姓名}"] = strName;

            //Mail物件設定
            Mail _mail = new Mail();
            _mail.From = new MailAddress(Definition.MailAccount);
            //_mail.To.Add("jones_chen@koatech.com.tw");
            _mail.To.Add(strEmail);
            _mail.Subject = strName + strYM + "本週銷售預測版本審核通知";
            _mail.Body = _template.ToString();
            _mail.IsBodyHtml = true;
            _mail.SendMail();
            _mail.Dispose();
            #endregion

            //建立主管待辦事項
            string strParams = string.Format("sl={0}&ym={1}", strSales, strYM);
            string strSubject = string.Format("{0}{1}銷售預測資料審核", strName, strYM);
            BLL.SetWorkList("Forecast", strMAccount, strParams, strSubject);

            liMsg.Text = GetMessage("success", "已通知您的主管來進行審核!");
            btnQuery_Click(sender, e);
        }
        else
        {
            liMsg.Text = GetMessage("error", msg);
        }
    }
}