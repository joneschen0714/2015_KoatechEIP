﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;

public partial class System_Erp_ERP01_Dialog : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0301";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //取網址參數
        string strCode = Tool.CheckQueryString("code");

        if (!IsPostBack)
        {
            //找供應商資料
            int recordCount;
            DataTable dtResult = BLL_ERP.GetPURMA(strCode, "", "", "MA001", 1, 1, out recordCount);

            //若有資料
            if (dtResult.Rows.Count > 0)
            {
                //廠商分類
                DataTable dtType = BLL_ERP.GetCMSMR("9", "");
                data_ddl_MA004.DataSource = dtType;
                data_ddl_MA004.DataBind();
                data_ddl_MA004.Items.Insert(0, new ListItem("無", ""));

                //地區
                DataTable dtArea = BLL_ERP.GetCMSMR("3", "");
                data_ddl_MA007.DataSource = dtArea;
                data_ddl_MA007.DataBind();
                data_ddl_MA007.Items.Insert(0, new ListItem("無", ""));

                //國家
                DataTable dtCountry = BLL_ERP.GetCMSMR("4", "");
                data_ddl_MA006.DataSource = dtCountry;
                data_ddl_MA006.DataBind();
                data_ddl_MA006.Items.Insert(0, new ListItem("無", ""));

                DataRow row = dtResult.Rows[0];
                base.FillControlData(this.Master.FindControl("Content"), row);

                //核准狀況
                string strMA016 = row["MA016"].ToString().Trim();
                switch (strMA016)
                {
                    case "1":
                        lblAudit.Text = "已核准";
                        break;
                    case "2":
                        lblAudit.Text = "尚待核准";
                        break;
                    case "3":
                        lblAudit.Text = "不准交易";
                        break;
                }
            }
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string strMA001 = data_lbl_MA001.Text.Trim();

        //找供應商資料
        int recordCount;
        DataTable dtResult = BLL_ERP.GetPURMA(strMA001, "", "", "MA001", 1, 1, out recordCount);

        UpdateContentData(this.Master.FindControl("Content"), dtResult.Rows[0]);

        BLL_ERP.UpdatePURMA(dtResult);

        liMsg.Text = GetMessage("success", "作業成功!");
    }
}