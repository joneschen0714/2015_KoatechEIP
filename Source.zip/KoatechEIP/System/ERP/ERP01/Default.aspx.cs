﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;

public partial class Default : UHR.BasePage.BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0301";
        base.OnPreInit(e);
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //廠商分類
            DataTable dtType = BLL_ERP.GetCMSMR("9", "");
            ddlType.DataSource = dtType;
            ddlType.DataBind();
            ddlType.Items.Insert(0, new ListItem("全部", ""));

            gv_GridDataBind(new object(), new EventArgs());
        }
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        if (gv.SortExpression == "")
        {
            gv.SortExpression = "MA001";
        }

        string strCode = txtCode.Text.Trim();
        string strName = txtName.Text.Trim();
        string strType = ddlType.SelectedValue;

        int recordCount;
        DataTable dt = BLL_ERP.GetPURMA(strCode, strName, strType, gv.SortingCondition, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        gv.GridView.Columns.Clear();
        gv.AddColumn("廠商代號", "MA001", true, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("簡稱", "MA002", true, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("全名", "MA003", true, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);

        gv.RowCount = recordCount;
        gv.GridView.DataSource = dt;
        gv.DataBind();
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        TableCell cell001 = gv.GetTableCell(e.Row, "MA001", true);

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strCode = rowView["MA001"].ToString();

            cell001.Text = "<a href='#' onclick=\"return OpenDialog('" + strCode + "')\">" + strCode + "</a>";
        }
    }
}