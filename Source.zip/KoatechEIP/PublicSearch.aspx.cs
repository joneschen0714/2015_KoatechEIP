﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR.BasePage;
using UHR;
using UHR.DataBase;
using UHR.Util;
using Newtonsoft.Json;
using UHR.Authority;


public partial class PublicSearch : BasePage
{
    private string KEYWORD = "";

    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0002";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            KEYWORD = Tool.CheckQueryString("keyword");

            DataPage1_RreRender(sender, e);
        }
    }

    protected void DataPage1_RreRender(object sender, EventArgs e)
    {
        DataTable dt = BLL_PUBLIC.GetPublicSearch(KEYWORD);

        ListView1.DataSource = dt;
        ListView1.DataBind();
    }

    protected void ListView1_ItemDataBound(object sender, ListViewItemEventArgs e)
    {
        if (e.Item.ItemType == ListViewItemType.DataItem)
        {
            DataRowView rowView = (DataRowView)e.Item.DataItem;

            HyperLink linkTitle = (HyperLink)e.Item.FindControl("linkTitle");
            Label lblDesc = (Label)e.Item.FindControl("lblDesc");

            linkTitle.Text = string.Format("{0}", rowView["Display"]);
            lblDesc.Text = string.Format("關鍵字:{0}", rowView["Keyword"]);

            string strType = rowView["Type"].ToString();
            switch (strType)
            {
                case "Tel":
                    linkTitle.NavigateUrl = string.Format("~/System/Pub/Pub01/Default.aspx?{0}", rowView["Params"]);
                    break;
            }
        }
    }
}