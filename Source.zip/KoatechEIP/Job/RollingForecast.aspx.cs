﻿using System;
using System.Text;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Net.Mail;
using System.Data.OracleClient;
using UHR;
using UHR.Util;

public partial class RollingForecast : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string type = Tool.CheckQueryString("t");

        switch (type)
        {
            case "reality":
                SetRealitySaleData();
                break;
            case "version":
                SetVersion();
                break;
        }
    }

    //寫入公司的實際營收資料
    private void SetRealitySaleData()
    {
        #region 博威 - 上月及本月
        for (int i = -1; i <= 0; i++)
        {
            //年月
            string strYM = DateTime.Now.AddMonths(i).ToString("yyyyMM");

            //資料來源
            DataTable dtSale = BLL_ERP.GetRealitySaleData(strYM, "", ""); //銷售
            DataTable dtSaleReturn = BLL_ERP.GetRealitySaleReturnData(strYM, "", ""); //銷退

            //合併實際銷售與實際銷退的資料
            foreach (DataRow row in dtSaleReturn.Rows)
            {
                dtSale.Rows.Add(row.ItemArray);
            }

            //執行寫入
            string msg = "";
            bool bResult = BLL_RF.SetRealityData(strYM, dtSale, ref msg);
        }
        #endregion

        #region 凱特西 - 上月及本月
        for (int i = -1; i <= 0; i++)
        {
            //參數
            string strYM = DateTime.Now.AddMonths(i).ToString("yyyyMM");

            #region SQL
            string OracleConn = "Data Source=PROD_ERP_topprod;User Id=KSKTC;Password=KSKTC;";
            DataTable dtReturn = new DataTable();
            string strQuery = @"SELECT * FROM ( 
                                    SELECT '凱特西' AS 公司別,
                                        TO_CHAR (oga02, 'yyyymmdd') AS 日期,
                                        '1' AS 類別,       
                                        oga14 AS 業務員代號,
                                        gen02 as 業務員姓名, 
                                        occ01 AS 客戶代號,
                                        occ02 AS 客戶簡稱,
                                        ima01 AS 品號,
                                        ima02 AS 品名,
                                        ima021 AS 規格,
                                        ogc092 AS 批號,
                                        ogc12 AS 數量,
                                        ogb05 AS 單位,
                                        decode(ogb05,'M2',ogc12,ogc12 * nvl(smd06,0)) AS 數量M2,
                                        ROUND ((ogb14/ogb12) *ogc12*get_azk051(oga23,to_char(oga02,'yyyymmdd'),ogb01,ogb03) )*taiflex.get_wrrate('RMB','TWD','M','C',to_char(oga02,'yyyymmdd')) AS 本幣金額,
                                        ROUND(ogb14/ogb12,4) *ogc12 AS 原幣金額,
                                        'CNY' AS 幣別,
                                        ROUND(ogb14/ogb12,4) AS 單價,
                                        taiflex.get_wrrate('RMB','TWD','M','C',to_char(oga02,'yyyymmdd')) AS 匯率
                                    FROM oga_file,
                                        ogb_file,
                                        ogc_file,
                                        oay_file,
                                        ima_file,
                                        occ_file,
                                        age_file,
                                        gen_file,
                                        (select * from smd_file where smd03='M2')
                                    WHERE oga01 = ogb01
                                        AND oga00 <> '2'
                                        AND ogb04 = ima01
                                        AND oga03 = occ01
                                        and ogb01 = ogc01
                                        and ogb03 = ogc03
                                        AND SUBSTRB (oga01, 1, 3) = oayslip
                                        AND age01 = ta_ima912
                                        AND ageacti = 'Y'
                                        AND TO_CHAR (oga02, 'yyyymmdd') >= '20130101'
                                        AND oga09 <> '1'
                                        AND oga09 <> '5'
                                        AND SUBSTRB (ogb04, 1, 4) <> 'MISC'
                                        AND oga00 <> '3'
                                        AND ta_oay003 <> 'Y'
                                        AND ogaconf = 'Y'
                                        AND ogapost = 'Y'
                                        AND oayar = 'Y'
                                        AND occ02 <> '博威'
                                        AND ogb05 = smd02(+)
                                        AND ogb04 = smd01(+)
                                        AND oga14 = gen01(+) 
                                    UNION ALL
                                    SELECT '凱特西' AS 公司別,
                                        TO_CHAR (oha02, 'yyyymmdd') AS 日期,
                                        '2' AS 類別,       
                                        occ04 AS 業務員代號,
                                        gen02 as 業務員姓名, 
                                        occ01 AS 客戶代號,
                                        occ02 AS 客戶簡稱,
                                        ima01 AS 品號,
                                        ima02 AS 品名,
                                        ima021 AS 規格,
                                        ohb092 AS 批號,
                                        (ohb12 * -1) AS 數量,
                                        ohb05 AS 單位,
                                        decode(ohb05,'M2', (ohb12 * -1), (ohb12 * -1) * nvl(smd06,0)) AS 數量M2,
                                        ROUND (ohb14*get_azk051(oha23,to_char(oha02,'yyyymmdd'),ohb01,ohb03)* -1)*taiflex.get_wrrate('RMB','TWD','M','C',to_char(oha02,'yyyymmdd')) AS 本幣金額,
                                        ohb14 AS 原幣金額,
                                        'CNY' AS 幣別,
                                        ohb13 AS 單價,
                                        taiflex.get_wrrate('RMB','TWD','M','C',to_char(oha02,'yyyymmdd')) AS 匯率
                                    FROM oha_file,
                                        ohb_file,
                                        oay_file,
                                        ima_file,
                                        occ_file,
                                        age_file,
                                        geo_file,
                                        gen_file,
                                        (select * from smd_file where smd03='M2')
                                    WHERE oha01 = ohb01
                                        AND oha09 IN ('1', '5')
                                        AND ohb04 = ima01
                                        AND oha03 = occ01
                                        AND SUBSTRB (oha01, 1, 3) = oayslip
                                        AND age01 = ta_ima912
                                        AND  ageacti = 'Y'
                                        AND occ22 = geo01(+)
                                        AND ta_ima912 = age01(+)
                                        AND TO_CHAR (oha02, 'yyyymmdd') >= '20130101'
                                        AND ta_oay003 <> 'Y'
                                        AND SUBSTRB (ohb04, 1, 4) <> 'MISC'
                                        AND ohaconf = 'Y'
                                        AND ohapost = 'Y'
                                        AND oayar = 'Y'     
                                        AND occ02 <> '博威'
                                        AND ohb05 = smd02(+)
                                        AND ohb04 = smd01(+)
                                        AND occ04 = gen01(+) 
                                )
                                WHERE substrb(日期,1,6) = '" + strYM + "'";
            #endregion

            //取得資料來源
            OracleConnection conn = new OracleConnection(OracleConn);
            OracleDataAdapter sda = new OracleDataAdapter(strQuery, conn);
            sda.Fill(dtReturn);

            //執行寫入
            string msg = "";
            bool bResult = BLL_RF.SetRealityData(strYM, dtReturn, ref msg);
        }
        #endregion
    }

    //建立版本
    private void SetVersion()
    {
        int iMonthWeek = Tool.GetWeekOfYear(new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1)); //本月週數
        int iWeek = Tool.GetWeekOfYear(DateTime.Now); //目前週數
        int iCurrectWeek = iWeek - iMonthWeek + 1; //本月第幾週

        string strYM = DateTime.Now.ToString("yyyyMM"); //當月
        string strNextYM = DateTime.Now.AddDays(7).ToString("yyyyMM"); //7天後的月份

        //資料來源
        DataTable dt = BLL_RF.GetForecastData("", "", strYM, "", "", "", "", "");
        DataTable dtSales = dt.DefaultView.ToTable(true, "業務員代號", "業務員姓名", "狀態碼");

        //每個業務員都強制變更為已審核
        string strNoConfirmList = "";
        foreach (DataRow row in dtSales.Rows)
        {
            string msg = "";
            string strSalesCode = row["業務員代號"].ToString();
            string strSalesName = row["業務員姓名"].ToString();
            string strStatus = row["狀態碼"].ToString();

            //判斷下週四是否為本月
            if (strNextYM != strYM)
            {
                //若為下月，則此版為最後一版，不可修改
                BLL_RF.AuditRF_Version(strYM, strSalesCode, "Y", ref msg);
            }
            else
            {
                //若為同月，則還可修改下週版本
                BLL_RF.AuditRF_Version(strYM, strSalesCode, "N", ref msg);
            }

            //當週資料未審核名單
            if (strStatus != "Y")
            {
                strNoConfirmList += "<br/>" + strSalesName;
            }
        }

        //建立版本
        BLL_RF.SetRF_Version(strYM, "W" + iCurrectWeek);

        //刪除所有Forecast待辦事項
        BLL.DelWorkList("Forecast", "", "");

        //有無未審核名單
        strNoConfirmList = strNoConfirmList == "" ? "無" : strNoConfirmList;

        #region 建立Mail通知
        //內容
        TemplateMail _template = new TemplateMail("~/configuration/MailTemplate/RF/AutoWeekVersion.htm");
        _template["{預測年月}"] = strYM;
        _template["{週別}"] = iCurrectWeek.ToString();
        _template["{未審核名單}"] = strNoConfirmList;

        //Mail物件設定
        Mail _mail = new Mail();
        _mail.From = new MailAddress(Definition.MailAccount);
        //_mail.To.Add("jones_chen@koatech.com.tw,wowo112@yahoo.com.tw,joneschen0714@gmai.com");
        _mail.To.Add("frank@koatech.com.tw,joseph_jaw@koatech.com.tw,meggy_peng@koatech.com.tw");
        _mail.Subject = string.Format("{0} W{1} 銷售預測定版通知", strYM, iCurrectWeek);
        _mail.Body = _template.ToString();
        _mail.IsBodyHtml = true;
        _mail.SendMail();
        _mail.Dispose();
        #endregion
    }
}