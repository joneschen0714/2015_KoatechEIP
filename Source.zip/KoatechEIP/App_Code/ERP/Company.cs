﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;

namespace UHR
{
    public enum PackingUnit { Kgs, LB }; //包裝單位

    /// <summary>公司別</summary>
    public class Company
    {
        private string _Name = "", _Value = "", _ConnectionString = "", _DBName = "", _RmaInHouse = "", _RmaOutHouse = "";
        private PackingUnit _pUnit = PackingUnit.Kgs;

        public Company() { }

        public Company(string Name, string Value, string ConnectionString, string DBName, string RmaInHouse, string RmaOutHouse, PackingUnit pUnit)
        {
            this.Name = Name;
            this.Value = Value;
            this.ConnectionString = ConnectionString;
            this.DBName = DBName;
            this.RmaInHouse = RmaInHouse;
            this.RmaOutHouse = RmaOutHouse;
            this.PackingUnit = pUnit;
        }

        public string Name
        {
            set { _Name = value; }
            get { return _Name; }
        }
        public string Value
        {
            set { _Value = value; }
            get { return _Value; }
        }
        public string ConnectionString
        {
            set { _ConnectionString = value; }
            get { return _ConnectionString; }
        }
        public string DBName
        {
            set { _DBName = value; }
            get { return _DBName; }
        }
        public string RmaInHouse
        {
            set { _RmaInHouse = value; }
            get { return _RmaInHouse; }
        }
        public string RmaOutHouse
        {
            set { _RmaOutHouse = value; }
            get { return _RmaOutHouse; }
        }
        public PackingUnit PackingUnit
        {
            set { _pUnit = value; }
            get { return _pUnit; }
        }
    }

    /// <summary>公司別集合</summary>
    public class CompanyCollection : List<Company>
    {
        public CompanyCollection()
        {
            //預設公司別
            this.Add(new Company("--請選擇公司別--", "", "", "", "", "", PackingUnit.Kgs));
            //this.Add(new Company("華燈光電", "Arclite", Definition.ERPConnStr, Definition.ERPDBName, "5106", "5107", PackingUnit.Kgs));
            //this.Add(new Company("UHRlamps", "UHRlamps", Definition.UhrlampsConnStr, Definition.UHRlampsDBName, "5A03", "5A02", PackingUnit.LB));
        }

        public static Company Get(string Value)
        {
            CompanyCollection cl = new CompanyCollection();
            var obj = from r in cl where r.Value == Value select r;

            Company c = null;
            foreach (var a in obj) { c = (Company)a; }

            return c;
        }
    }
}