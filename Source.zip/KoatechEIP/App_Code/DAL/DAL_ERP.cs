﻿using System;
using System.Data;

namespace UHR
{
    public class DAL_ERP
    {
        public DAL_ERP()
        {

        }

        /// <summary>取得供應商資料</summary>
        public static DataTable GetPURMA(string _code, string _name, string _type, string _sort, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Code", _code);
            param.Add("Name", "%" + _name + "%");
            param.Add("Type", _type);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (_code != "") { strWhere += " AND MA001=@Code "; }
            if (_name != "") { strWhere += " AND MA002 LIKE @Name "; }
            if (_type != "") { strWhere += " AND MA004=@Type "; }

            string strSQL = "SELECT * FROM PURMA WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable(strSQL, _sort, _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>取得交易對象分類檔</summary>
        public static DataTable GetCMSMR(string _mr001, string _mr002)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MR001", _mr001);
            param.Add("MR002", _mr002);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (_mr001 != "") { strWhere += " AND MR001=@MR001 "; }
            if (_mr002 != "") { strWhere += " AND MR002=@MR002 "; }

            db.StrSQL = "SELECT RTRIM(MR001) MR001, RTRIM(MR002) MR002, RTRIM(MR003) MR003, RTRIM(MR004) MR004, RTRIM(MR005) MR005 FROM CMSMR WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得庫別檔</summary>
        public static DataTable GetCMSMC(string MC004)
        {
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MC004", MC004);
            db.SqlParams = param;

            string strWhere = "";
            if (MC004 != "") { strWhere += " AND MC004=@MC004 "; }

            db.StrSQL = "SELECT DISTINCT MC001, MC002 FROM CMSMC WHERE 1=1" + strWhere;
            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>更新供應商資料</summary>
        public static void UpdatePURMA(DataTable dt)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            string strSQL = "SELECT * FROM PURMA WHERE 1=0";
            db.Update(dt, strSQL);
        }

        /// <summary>品號資料表</summary>
        public static DataTable GetPD01(string _product, string _pname)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Product", "%" + _product + "%");
            param.Add("Name", "%" + _pname + "%");
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (_product != "") { strWhere += " AND MB001 LIKE @Product "; }
            if (_pname != "") { strWhere += " AND MB002 LIKE @Name "; }

            db.StrSQL = "SELECT b.MB001, b.MB002, b.MB003, b.MB004, b.MB064, b.MB089 " +
                        "FROM INVMB b " +
                        "WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得部門科目各期金額檔</summary>
        public static DataTable GetACTMD(string 科目編號, string 部門代號, string 會計年度, string 期別)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("科目編號", 科目編號 + "%");
            param.Add("部門代號", 部門代號);
            param.Add("會計年度", 會計年度);
            param.Add("期別", 期別);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (科目編號 != "") { strWhere += " AND MD001 LIKE @科目編號 "; }
            if (部門代號 != "") { strWhere += " AND MD002 = @部門代號 "; }
            if (會計年度 != "") { strWhere += " AND MD003 = @會計年度 "; }
            if (期別 != "") { strWhere += " AND MD004 = @期別 "; }

            db.StrSQL = @"SELECT MD001, MD002, MD003, MD004, ((MD005 - MD006) * MA007) AMT
                          FROM ACTMD
                          INNER JOIN ACTMA ON MA001=MD001
                          WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得會計科目檔</summary>
        public static DataTable GetACTMA(string 前置科目編號, string 科目編號, string 科目類別)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("前置科目編號", 前置科目編號 + "%");
            param.Add("科目編號", 科目編號);
            param.Add("科目類別", 科目類別);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (前置科目編號 != "") { strWhere += " AND MA001 LIKE @前置科目編號 "; }
            if (科目編號 != "") { strWhere += " AND MA001 = @科目編號 "; }
            if (科目類別 != "") { strWhere += " AND MA008 = @科目類別 "; }

            db.StrSQL = @"SELECT * FROM ACTMA WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得員工基本資料</summary>
        public static DataTable GetCMSMV(string 工號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("工號", 工號);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (工號 != "") { strWhere += " AND MV001 = @工號 "; }

            db.StrSQL = @"SELECT * FROM CMSMV WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得客戶基本資料</summary>
        public static DataTable GetCOPMA(string 業務員代號, string 客戶代號, string 客戶簡稱)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("業務員代號", 業務員代號);
            param.Add("客戶代號", 客戶代號);
            param.Add("客戶簡稱", 客戶簡稱);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (業務員代號 != "") { strWhere += " AND MA016 = @業務員代號 "; }
            if (客戶代號 != "") { strWhere += " AND MA001 = @客戶代號 "; }
            if (客戶簡稱 != "") { strWhere += " AND MA002 = @客戶簡稱 "; }

            db.StrSQL = @"SELECT * FROM COPMA WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>線別資料檔</summary>
        public static DataTable GetCMSMD(string Code)
        {
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MD001", Code);
            db.SqlParams = param;

            string strWhere = "";
            if (Code != "") { strWhere += " AND MD001=@MD001 "; }

            db.StrSQL = "SELECT MD001, MD002 FROM CMSMD WHERE 1=1" + strWhere;
            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得部門資料</summary>
        public static DataTable GetCMSME(string 部門代號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("部門代號", 部門代號);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (部門代號 != "") { strWhere += " AND ME001 = @部門代號 "; }

            db.StrSQL = @"SELECT * FROM CMSME WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得品號基本資料</summary>
        public static DataTable GetINVMB(string 品號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("品號", 品號);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (品號 != "") { strWhere += " AND MB001 = @品號 "; }

            db.StrSQL = "SELECT * FROM INVMB WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得品號類別檔</summary>
        public static DataTable GetINVMA(string 分類方式, string 類別代號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("分類方式", 分類方式);
            param.Add("類別代號", 類別代號);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (分類方式 != "") { strWhere += " AND MA001 = @分類方式 "; }
            if (類別代號 != "") { strWhere += " AND MA002 = @類別代號 "; }

            db.StrSQL = "SELECT * FROM INVMA WHERE 1=1" + strWhere + " ORDER BY MA002";

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得品號換算單位檔</summary>
        public static DataTable GetINVMD(string 品號, string 單位)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("品號", 品號);
            param.Add("單位", 單位);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (品號 != "") { strWhere += " AND MB001 = @品號 "; }
            if (單位 != "") { strWhere += " AND (MB004=@單位 OR MD002=@單位) "; }

            db.StrSQL = @"SELECT MB001, MB002, MB003, MB004, MB156, MD002, MD003, MD004 FROM INVMB 
                          LEFT OUTER JOIN INVMD ON MD001=MB001
                          WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得幣別匯率檔單頭</summary>
        public static DataTable GetCMSMF(string 幣別)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("幣別", 幣別);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (幣別 != "") { strWhere += " AND MF001 = @幣別 "; }

            db.StrSQL = "SELECT * FROM CMSMF WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得實際銷貨資料</summary>
        public static DataTable GetRealitySaleData(string 銷售年月, string 業務員代號, string 客戶簡稱)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("銷售年月", 銷售年月 + "%");
            param.Add("業務員代號", 業務員代號);
            param.Add("客戶簡稱", 客戶簡稱);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (銷售年月 != "") { strWhere += " AND TG003 LIKE @銷售年月 "; }
            if (業務員代號 != "") { strWhere += " AND TG006 = @業務員代號 "; }
            if (客戶簡稱 != "") { strWhere += " AND MA002 = @客戶簡稱 "; } else { strWhere += " AND MA002 <> '凱特西' "; }

            db.StrSQL = "SELECT '博威' [公司別], TG003 [日期], '1' [類別], TG006 [業務員代號], MV002 [業務員姓名], TG004 [客戶代號], MA002 [客戶簡稱], TH004 [品號], TH005 [品名], TH006 [規格], TH017 [批號], (TH008 + TH024) [數量], TH009 [單位], ((TH008 + TH024) * ISNULL(MD004,1)) [數量M2], TG011 [幣別], TH012 [單價], TG012 [匯率], TH035 [原幣金額], TH037 本幣金額 " +
                        "FROM COPTG " +
                        "LEFT OUTER JOIN COPMA ON MA001=TG004 " +
                        "LEFT OUTER JOIN COPTH ON TH001=TG001 AND TH002=TG002 " +
                        "LEFT OUTER JOIN CMSMC ON MC001=TH007 AND MC004=1 " +
                        "LEFT OUTER JOIN INVMD ON MD001=TH004 AND MD002=TH009 " +
                        "LEFT OUTER JOIN CMSMV ON MV001=TG006 " +
                        "WHERE TG023='Y'" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得實際銷退資料</summary>
        public static DataTable GetRealitySaleReturnData(string 銷退年月, string 業務員代號, string 客戶簡稱)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("銷退年月", 銷退年月 + "%");
            param.Add("業務員代號", 業務員代號);
            param.Add("客戶簡稱", 客戶簡稱);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (銷退年月 != "") { strWhere += " AND TI003 LIKE @銷退年月 "; }
            if (業務員代號 != "") { strWhere += " AND TI006 = @業務員代號 "; }
            if (客戶簡稱 != "") { strWhere += " AND MA002 = @客戶簡稱 "; } else { strWhere += " AND MA002 <> '凱特西' "; }

            db.StrSQL = "SELECT '博威' [公司別], TI003 [日期], '2' [類別], TI006 [業務員代號], MV002 [業務員姓名], TI004 [客戶代號], MA002 [客戶簡稱], TJ004 [品號], TJ005 [品名], TJ006 [規格], TJ014 [批號], (0 - TJ007) [數量], TJ008 [單位], (0 - (TJ007 * ISNULL(MD004,1))) [數量M2], TI008 [幣別], TI009 [匯率], TJ011 [單價], (0 - TJ031) [原幣金額], (0 - TJ033) 本幣金額 " +
                        "FROM COPTI " +
                        "LEFT OUTER JOIN COPMA ON MA001=TI004 " +
                        "LEFT OUTER JOIN COPTJ ON TJ001=TI001 AND TJ002=TI002 " +
                        "LEFT OUTER JOIN INVMD ON MD001=TJ004 AND MD002=TJ008 " +
                        "LEFT OUTER JOIN CMSMV ON MV001=TI006 " +
                        "WHERE TI019='Y'" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }
    }
}