﻿using System;
using System.Data;
using System.Linq;

namespace UHR
{
    public class DAL_PUBLIC
    {
        public DAL_PUBLIC()
        {

        }

        /// <summary>取得EHR的員工資料</summary>
        public static DataTable GetHR_UserData(string _empid, string _dep, string _cname, string _sort, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.HRConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("DEP_CODE", _dep);
            param.Add("EMPID", "%" + _empid + "%");
            param.Add("CName", "%" + _cname + "%");

            db.SqlParams = param;

            //條件
            string strWhere = "";
            if (_empid != "") { strWhere += " AND EMPID LIKE @EMPID "; }
            if (_dep != "") { strWhere += " AND DEP_CODE = @DEP_CODE "; }
            if (_cname != "") { strWhere += " AND HECNAME LIKE @CName "; }

            //SQL
            string strSQL = "SELECT * FROM HRUSER h " +
                            "WHERE QUITDATE IS NULL " + strWhere;

            DataTable dtResult = db.ExecuteDataTable(strSQL, _sort, _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>取得EHR的部門資料</summary>
        public static DataTable GetHR_DEP(string PARENT_DEPT_CODE, string DEPT_CODE, string ACC_NO, string DEP_DISABLE)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.HRConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("PARENT_DEPT_CODE", PARENT_DEPT_CODE);
            param.Add("DEPT_CODE", DEPT_CODE);
            param.Add("ACC_NO", ACC_NO);
            param.Add("DEP_DISABLE", DEP_DISABLE);
            db.SqlParams = param;

            //條件
            string strWhere = "";
            if (PARENT_DEPT_CODE != "") { strWhere += " AND PARENT_DEPT_CODE = @PARENT_DEPT_CODE "; }
            if (DEPT_CODE != "") { strWhere += " AND DEPT_CODE = @DEPT_CODE "; }
            if (ACC_NO != "") { strWhere += " AND ACC_NO = @ACC_NO "; }
            if (DEP_DISABLE != "") { strWhere += " AND DEP_DISABLE = @DEP_DISABLE "; }

            //SQL
            db.StrSQL = "SELECT * " +
                        "FROM HRUSER_DEPT_BAS h " +
                        "WHERE 1=1 " + strWhere +
                        "ORDER BY DEPT_CODE";

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得全文檢索結果</summary>
        public static DataTable GetPublicSearch(string _keyword)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Keyword", "%" + _keyword + "%");
            db.SqlParams = param;

            //SQL
            db.StrSQL = "SELECT TOP 100 * FROM ADMMZ " +
                        "WHERE Keyword LIKE @Keyword";

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>排程全文檢索</summary>
        public static void SetPublicSearch()
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //SQL
            db.StrSQL = "TRUNCATE TABLE ADMMZ; ";

            db.StrSQL += "INSERT ADMMZ(Type, Params, Display, Keyword) " +
                         "SELECT 'Tel' [Type], 'id=' + EMPID [Params], ISNULL(HECNAME,'') + ', 分機' + ISNULL(EXT,'') [Display], ISNULL(HECNAME,'') + ',' + ISNULL(NOTESID,'') + ',' + ISNULL(EXT,'') [Keyword] FROM " + Definition.HRDBNAME + "HRUSER WHERE QUITDATE IS NULL";

            db.ExecuteSQL();
        }

        /// <summary>取得教育訓練資料</summary>
        public static DataTable GetPUB02(string id, string enabled)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", id);
            param.Add("Enabled", enabled);
            db.SqlParams = param;

            //條件
            string strWhere = "";
            if (id != "") { strWhere += " AND ID=@ID "; }
            if (enabled != "") { strWhere += " AND Enabled=@Enabled "; }

            //SQL
            db.StrSQL = "SELECT * FROM PUBMA WHERE 1=1 " + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得FIN03</summary>
        public static DataTable GetFIN03()
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //SQL
            db.StrSQL = "SELECT * FROM RPTMA";
            return db.ExecuteDataTable();
        }

        /// <summary>寫入FIN03</summary>
        public static void SetFIN03(DataTable dt)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //先清除FIN03
            db.StrSQL = "TRUNCATE TABLE RPTMA; ";
            db.ExecuteSQL();

            //批次更新
            string strSQL = "SELECT * FROM RPTMA WHERE 1=0";
            db.Update(dt, strSQL);
        }

        /// <summary>寫入FIN03的歷史資料</summary>
        public static void SetFIN03_HistoryData(DataView dv)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //刪除重覆的年月資料
            var dtMonth = dv.ToTable(true, "年份", "月份");
            foreach (DataRow row in dtMonth.Rows)
            {
                db.StrSQL = "DELETE FROM RPTMB WHERE 年份='" + row["年份"].ToString() + "' AND 月份='" + row["月份"].ToString() + "'";
                db.ExecuteSQL();
            }

            //批次更新
            string strSQL = "SELECT * FROM RPTMB WHERE 1=0";
            db.Update(dv.ToTable(), strSQL);
        }
    }
}