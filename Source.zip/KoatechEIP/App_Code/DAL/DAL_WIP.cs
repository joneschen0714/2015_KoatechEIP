﻿using System;
using System.Data;
using System.Data.SqlClient;
using UHR.Util;

namespace UHR
{
    public class DAL_WIP
    {
        public DAL_WIP()
        {

        }

        /// <summary>取得報價單的單頭列表</summary>
        public static DataTable GetMOCWH(string _sort, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            db.SqlParams = param;

            //條件
            string strWhere = "";

            //SQL
            string strSQL = "SELECT * " +
                            "FROM MOCWH h " +
                            "WHERE 1=1 " + strWhere;

            DataTable dtResult = db.ExecuteDataTable(strSQL, _sort, _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>庫齡報表</summary>
        public static DataTable GetFIN01(string date, string invType, string invType1, string invClass, string PN1, string PN2, string day1, string day2, string day21, string day3, string day31, string day4, string day41, string day5, string day51, string day6)
        {
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("資料日期", date);
            param.Add("庫存性質", invType);
            param.Add("庫存倉別", invType1);
            param.Add("品號起", PN1);
            param.Add("品號迄", PN2);
            param.Add("Day1", day1);
            param.Add("Day2", day2);
            param.Add("Day21", day21);
            param.Add("Day3", day3);
            param.Add("Day31", day31);
            param.Add("Day4", day4);
            param.Add("Day41", day41);
            param.Add("Day5", day5);
            param.Add("Day51", day51);
            param.Add("Day6", day6);
            db.SqlParams = param;

            string strWhere = "";
            if (invType != "") { strWhere += " AND MC004=@庫存性質 "; }
            if (invType1 != "") { strWhere += " AND LA009=@庫存倉別 "; }
            if (invClass != "") { strWhere += " AND MB005 IN (" + invClass + ") "; }
            if (PN1 != "") { strWhere += " AND LA001 >= @品號起 "; }
            if (PN2 != "") { strWhere += " AND LA001 <= @品號迄 "; }

            string sql1 = "SELECT LTRIM(RTRIM(LA001)) LA001, MB002, MB003, MB004, LTRIM(RTRIM(LA009)) LA009, MC002, LA004, (LA011*LA005) LA011, (LA013*LA005) LA013, LTRIM(RTRIM(LA016)) LA016, MA002,LA004 [NewDate], 0 [dayDiff] " +
                          "INTO #temp1 " +
                          "FROM INVLA " +
                          "LEFT JOIN INVMB ON (MB001 = LA001) " +
                          "LEFT JOIN INVMA ON (MB005 = MA002 and MA001='1') " +
                          "INNER JOIN CMSMC ON (MC001 = LA009) " +
                          "WHERE (LA009 <> 'C02') AND (LA004 <= @資料日期) " + strWhere +
                          "ORDER BY LA005 DESC, LA001, LA009, LA016, LA007 ";

            string sql2 = "UPDATE a SET a.NewDate=b.LA004 " +
                          "FROM #temp1 a " +
                          "INNER JOIN (SELECT LA001, LA016, MIN(LA004) LA004 FROM #temp1 WHERE LEFT(MA002,1) IN ('4','5') AND LA016 <> '' GROUP BY LA001, LA016) b ON b.LA001=a.LA001 AND b.LA016=a.LA016 ";

            string sql3 = "UPDATE #temp1 SET NewDate='20'+SUBSTRING(LA016,4,6) WHERE LEFT(MA002,1) IN ('4','5') AND LEFT(LA016,1)='H' " +
                          "UPDATE #temp1 SET NewDate='20'+dbo.GetCode2Date(SUBSTRING(LA016,3,1))+dbo.GetCode2Date(SUBSTRING(LA016,4,1))+SUBSTRING(LA016,5,2) WHERE LEFT(MA002,1) IN ('4','5') AND SUBSTRING(LA016,7,1)='-' ";

            string sql4 = "UPDATE a SET a.NewDate=b.LA004 " +
                          "FROM #temp1 a " +
                          "INNER JOIN (SELECT LA001,LA009, MAX(LA004) LA004 FROM #temp1 WHERE (LEFT(LA001,2)='6E' OR LEFT(LA001,1)='3') GROUP BY LA001,LA009) b ON b.LA001=a.LA001 AND b.LA009=a.LA009 ";

            string sql5 = "UPDATE a SET a.NewDate=b.LA004 " +
                          "FROM #temp1 a " +
                          "INNER JOIN (SELECT LA001,LA016, MIN(LA004) LA004 FROM #temp1 WHERE LEFT(LA001,1) IN ('1','2','A','R') AND LA004 <= @資料日期 GROUP BY LA001,LA016) b ON b.LA001=a.LA001 AND b.LA016=a.LA016 ";

            string sql6 = "UPDATE #temp1 SET NewDate=LA004 WHERE isDate(NewDate)=0 OR LEN(NewDate)<>8 " +
                          "UPDATE #temp1 SET dayDiff=DATEDIFF(day, Convert(Datetime,NewDate,112),Convert(Datetime,@資料日期,112)) " +
                          "UPDATE #temp1 SET LA016='' WHERE LEFT(LA001,2)='6E' OR LEFT(LA001,1)='3' ";

            string sql7 = "SELECT LA001,MB002,MB003,MB004,LA009,MC002,LA016, " +
                            "SUM([1_QTY]) [1_QTY], " +
                            "SUM([1_AMT]) [1_AMT], " +
                            "SUM([2_QTY]) [2_QTY], " +
                            "SUM([2_AMT]) [2_AMT], " +
                            "SUM([3_QTY]) [3_QTY], " +
                            "SUM([3_AMT]) [3_AMT], " +
                            "SUM([4_QTY]) [4_QTY], " +
                            "SUM([4_AMT]) [4_AMT], " +
                            "SUM([5_QTY]) [5_QTY], " +
                            "SUM([5_AMT]) [5_AMT], " +
                            "SUM([6_QTY]) [6_QTY], " +
                            "SUM([6_AMT]) [6_AMT], " +
                            "SUM(LA011) [數量總計], " +
                            "SUM(LA013) [金額總計] " +
                          "INTO #temp2 " +
                          "FROM( " +
                            "SELECT *, " +
                                "CASE WHEN [dayDiff] <= @Day1 THEN [LA011] ELSE 0 END [1_QTY], " +
                                "CASE WHEN [dayDiff] <= @Day1 THEN [LA013] ELSE 0 END [1_AMT], " +
                                "CASE WHEN [dayDiff] BETWEEN @Day2 AND @Day21 THEN [LA011] ELSE 0 END [2_QTY], " +
                                "CASE WHEN [dayDiff] BETWEEN @Day2 AND @Day21 THEN [LA013] ELSE 0 END [2_AMT], " +
                                "CASE WHEN [dayDiff] BETWEEN @Day3 AND @Day31 THEN [LA011] ELSE 0 END [3_QTY], " +
                                "CASE WHEN [dayDiff] BETWEEN @Day3 AND @Day31 THEN [LA013] ELSE 0 END [3_AMT], " +
                                "CASE WHEN [dayDiff] BETWEEN @Day4 AND @Day41 THEN [LA011] ELSE 0 END [4_QTY], " +
                                "CASE WHEN [dayDiff] BETWEEN @Day4 AND @Day41 THEN [LA013] ELSE 0 END [4_AMT], " +
                                "CASE WHEN [dayDiff] BETWEEN @Day5 AND @Day51 THEN [LA011] ELSE 0 END [5_QTY], " +
                                "CASE WHEN [dayDiff] BETWEEN @Day5 AND @Day51 THEN [LA013] ELSE 0 END [5_AMT], " +
                                "CASE WHEN [dayDiff] >= @Day6 THEN [LA011] ELSE 0 END [6_QTY], " +
                                "CASE WHEN [dayDiff] >= @Day6 THEN [LA013] ELSE 0 END [6_AMT] " +
                            "FROM #temp1 " +
                          ") r " +
                          "GROUP BY LA001,MB002,MB003,MB004,LA009,MC002,LA016 " +
                          "ORDER BY MC002,LA001 ";

            string sql8 = "DELETE FROM #temp2 WHERE [數量總計]=0 AND [金額總計]=0 " +
                          "SELECT LA001, LA009, SUM([數量總計]) [數量總計], SUM([金額總計]) [金額總計] INTO #temp3 FROM #temp2 GROUP BY LA001,MB002,MB003,MB004,LA009,MC002 ";

            string sql9 = "DELETE a FROM #temp2 a " +
                          "INNER JOIN #temp3 b ON b.LA001=a.LA001 AND b.LA009=a.LA009 AND b.[數量總計]=0 AND b.[金額總計]<10 ";

            string sql10 = "DELETE a FROM #temp2 a " +
                           "INNER JOIN (SELECT LA001, LA009 FROM #temp2 WHERE [數量總計]=0 GROUP BY LA001,LA009 HAVING SUM([金額總計]) BETWEEN -2 AND 2) b ON b.LA001=a.LA001 AND b.LA009=a.LA009 " +
                           "WHERE a.[數量總計]=0 ";

            string sql11 = "SELECT * FROM #temp2 ORDER BY LA001,LA009,LA016";

            db.StrSQL = sql1 + sql2 + sql3 + sql4 + sql5 + sql6 + sql7 + sql8 + sql9 + sql10 + sql11;
            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>製令用料表</summary>
        public static DataTable GetPD07(string FormType, string FormNum, string Date1, string Date2, string Line, string SProduct)
        {
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("TA001", FormType);
            param.Add("TA002", FormNum + "%");
            param.Add("Date1", Date1);
            param.Add("Date2", Date2);
            param.Add("TA021", Line);
            param.Add("TB003", SProduct);
            db.SqlParams = param;

            string strWhere = "";
            if (FormType != "") { strWhere += " AND TA001 = @TA001 "; }
            if (FormNum != "") { strWhere += " AND TA002 LIKE @TA002 "; }
            if (SProduct != "") { strWhere += " AND TB003 = @TB003 "; }
            if (Date1 != "") { strWhere += " AND TA003 >= @Date1 "; }
            if (Date2 != "") { strWhere += " AND TA003 <= @Date2 "; }

            db.StrSQL = "SELECT TA001, TA002, TA003, TA006, TA034, TA035, TA021, TA045, TA046, TA048, TA015, TA017, " +
                               "TB003, TB012, TB013, TB004, TB005, TB007, TB019, TB020, TB021 " +
                        "FROM MOCTA " +
                        "LEFT OUTER JOIN MOCTB ON TB001=TA001 AND TB002=TA002 " +
                        "WHERE (TA001 = TB001) AND (TA002 = TB002) AND (TA011 IN ('Y','y')) AND (TA021 = @TA021)" + strWhere +
                        "ORDER BY TA003 DESC";

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>線別人工製費清單</summary>
        public static DataTable GetFIN02(string Line, string Date1, string Date2)
        {
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Date1", Date1);
            param.Add("Date2", Date2);
            db.SqlParams = param;

            string strWhere = "", strWhere1 = "";
            if (Line != "") { strWhere += " AND MC001 IN (" + Line + ") "; }
            if (Date1 != "" && Date2 != "")
            {
                strWhere += " AND MC002 BETWEEN @Date1 AND @Date2 ";
                strWhere1 = " AND LEFT(TF003,6) BETWEEN @Date1 AND @Date2 ";
            }

            string sql1 = "SELECT TF011, SUM(TG013) TG013, SUM(TG027) TG027 INTO #temp1 " +
                          "FROM MOCTG " +
                          "INNER JOIN MOCTF ON (TF001 = TG001 and TF002 = TG002) " +
                          "INNER JOIN CMSMC ON (MC001 = TG010 and MC004 = '1') " +
                          "WHERE TF006 = 'Y' AND TG001 <> '5810' " + strWhere1 +
                          "GROUP BY TF011 ";

            string sql2 = "SELECT *, [人工m2] + [製費m2] [單位M2], [人工m] + [製費m] [單位M] FROM( " +
                                "SELECT MC001, MC002, MC003, MC004, MC005, MD002, TG013, TG027, " +
                                    "CASE WHEN MC005 > 0 THEN MC003/MC005 ELSE 0 END [單位人工], " +
                                    "CASE LEFT(MD008,1) " +
                                        "WHEN '1' THEN CASE WHEN MC005 <> 0 THEN MC004 / MC005 END " +
                                        "WHEN '2' THEN CASE WHEN MC006 <> 0 THEN MC004 / MC006 END " +
                                        "WHEN '3' THEN CASE WHEN MC003 <> 0 THEN MC004 / MC003 END " +
                                    "END [單位製費], " +
                                    "MC003 / TG013 [人工m2], " +
                                    "MC004 / TG013 [製費m2], " +
                                    "MC003 / TG027 [人工m], " +
                                    "MC004 / TG027 [製費m] " +
                                "FROM CSTMC " +
                                "LEFT JOIN CMSMD ON (MD001=MC001) " +
                                "LEFT JOIN CMSMF ON (MF001='NTD') " +
                                "LEFT JOIN #temp1 ON MC001=TF011 " +
                                "WHERE 1=1 " + strWhere +
                          ") r " +
                          "ORDER BY MC001, MC002";

            db.StrSQL = sql1 + sql2;
            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>線別資料檔(WIP)</summary>
        public static DataTable GetMOCWB(string Code)
        {
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Code", Code);
            db.SqlParams = param;

            string strWhere = "";
            if (Code != "") { strWhere += " AND WB001=@Code "; }

            db.StrSQL = "SELECT WB001, WB002 FROM MOCWB WHERE 1=1" + strWhere + " ORDER BY WB001";
            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>製程項目資料檔(WIP)</summary>
        public static DataTable GetMOCWA(string _line)
        {
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Line", _line);
            db.SqlParams = param;

            string strWhere = "";
            if (_line != "") { strWhere += " AND WA003=@Line "; }

            db.StrSQL = "SELECT WA001, WA002, WA003 FROM MOCWA WHERE 1=1" + strWhere + " ORDER BY WA003, WA001";
            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>生產管制表</summary>
        public static DataTable GetPD02(string _year, string _month, string _line, string _process, string _level)
        {
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Year", _year);
            param.Add("Month", _month);
            param.Add("Line", _line);
            param.Add("Process", _process);
            param.Add("Level", _level);
            db.SqlParams = param;

            string strWhere = "";
            if (_year != "") { strWhere += " AND SUBSTRING(WH006,1,4)=@Year "; }
            if (_month != "") { strWhere += " AND SUBSTRING(WH006,5,2)=@Month "; }
            if (_line != "") { strWhere += " AND WH026=@Line "; }
            if (_process != "") { strWhere += " AND WH027=@Process "; }
            if (_level != "") { strWhere += " AND WM011=@Level "; }
            //if (FormNum != "") { strWhere += " AND TA002 LIKE @TA002 "; }

            db.StrSQL = "SELECT WH008 [生產日期], RTRIM(WH007) [製令單別], RTRIM(WH006) [製令單號], WH003 [品號], WH004 [品名], WH002 [批號], WM011 [品質判定], WH009 [生產時間], WH011 [完工時間], WH019 [投料數], WH020 [實際產出數], WH021 [有效產出數], WH023 [異常數], WH022 [良率] " +
                        "FROM MOCWH " +
                        "INNER JOIN MOCWM ON WM016 = WH001 " +
                        "WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>生產管制表-子報表鑽取</summary>
        public static DataTable GetPD02_Report2(string _formType, string _formNum, string _lot)
        {
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("FormType", _formType);
            param.Add("FormNum", _formNum);
            param.Add("Lot", _lot);
            db.SqlParams = param;

            string strWhere = "";
            if (_formType != "") { strWhere += " AND WH007=@FormType "; }
            if (_formNum != "") { strWhere += " AND WH006=@FormNum "; }
            if (_lot != "") { strWhere += " AND WH002=@Lot "; }

            db.StrSQL = "SELECT RTRIM(WH007) [製令單別], RTRIM(WH006) [製令單號], WH003 [品號], WH004 [品名], WH002 [批號], WI004 [缺陷代號], WI005 [缺陷名稱], WI006 [數量] " +
                        "FROM MOCWH " +
                        "INNER JOIN MOCWI ON WI001=WH001 AND WI002=WH002 " +
                        "WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>生產良率</summary>
        public static DataTable GetYieldRate(string 日期, string 生產線別, string 品號)
        {
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("@日期", 日期 + "%");
            db.SqlParams = param;

            string strWhere = "";
            if (日期 != "") { strWhere += " AND WH008 LIKE @日期 "; }

            db.StrSQL = "SELECT WH002 [批號], WH003 [品號], WH004 [品名], WH008 [生產日期], WH010 [完工日期], WH019 [投料數], WH021 [有效產出數], WH023 [異常合計], WH026 [生產線別], WH027 [製程別] " +
                        "FROM MOCWH " +
                        "WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>缺陷紀錄</summary>
        public static DataTable GetDefectData(string 日期)
        {
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("@日期", 日期 + "%");
            db.SqlParams = param;

            string strWhere = "";
            if (日期 != "") { strWhere += " AND WH008 LIKE @日期 "; }

            db.StrSQL = "SELECT WH008 [生產日期], WI001 [登錄單號], WI002 [批號], WI004 [缺陷代號], WI005 [缺陷名稱], WI006 [數量] " +
                        "FROM MOCWI " +
                        "INNER JOIN MOCWH ON WH001=WI001 " +
                        "WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }
    }
}