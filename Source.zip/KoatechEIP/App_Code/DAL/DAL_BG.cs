﻿using System;
using System.Data;
using System.Linq;
using System.Data.SqlClient;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UHR.Authority;
using UHR.Util;

namespace UHR
{
    public class DAL_BG
    {
        public DAL_BG()
        {

        }

        /// <summary>寫入費用性預算(管理者用)</summary>
        public static bool SetBudgetDataForAdmin(DataTable dt, ref string msg)
        {
            bool bResult = false;

            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //設定Transaction
            SqlCommand cmd = db.SqlCommand;
            SqlTransaction trans = db.SetTransaction(cmd);

            try
            {
                #region 匯入預算資料
                foreach (DataRow row in dt.Rows)
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("版本", row["版本"]));
                    cmd.Parameters.Add(new SqlParameter("部門代碼", row["部門代碼"]));
                    cmd.Parameters.Add(new SqlParameter("年度", row["年度"]));
                    cmd.Parameters.Add(new SqlParameter("月份", DBNull.Value));
                    cmd.Parameters.Add(new SqlParameter("科目代碼", row["科目代碼"]));
                    cmd.Parameters.Add(new SqlParameter("金額", DBNull.Value));
                    cmd.Parameters.Add(new SqlParameter("建立者", UserInfo.SessionState.Account));

                    //刪除欲覆蓋的資料,並傳回確認碼
                    cmd.CommandText = @"DELETE FROM BUDMA WHERE 版本=@版本 AND 部門代碼=@部門代碼 AND 科目代碼=@科目代碼;
                                        SELECT TOP 1 確認碼 FROM BUDMA WHERE 版本=@版本 AND 部門代碼=@部門代碼";
                    string strStatus = Convert.ToString(cmd.ExecuteScalar());
                    cmd.Parameters.Add(new SqlParameter("確認碼", strStatus == "" ? "N" : strStatus));

                    //讀取12個月
                    for (int i = 1; i <= 12; i++)
                    {
                        cmd.Parameters["月份"].Value = i.ToString().PadLeft(2, '0');
                        cmd.Parameters["金額"].Value = Convert.ToString(row[i + "月"]).Trim() == "" ? 0 : Convert.ToDecimal(row[i + "月"]);

                        cmd.CommandText = "INSERT BUDMA(版本, 部門代碼, 年度, 月份, 科目代碼, 金額, 確認碼, 建立者, 建立時間) VALUES(@版本, @部門代碼, @年度, @月份, @科目代碼, @金額, @確認碼, @建立者, GetDate())";
                        cmd.ExecuteNonQuery();
                    }
                }
                #endregion

                trans.Commit();
                bResult = true;
            }
            catch (Exception e)
            {
                trans.Rollback();
                msg = e.Message;
                bResult = false;
            }

            db.CloseDatabaseState("N");
            trans.Dispose();
            cmd.Dispose();

            return bResult;
        }

        /// <summary>寫入費用性預算</summary>
        public static bool SetBudgetData(DataTable dt, ref string msg)
        {
            bool bResult = false;

            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //設定Transaction
            SqlCommand cmd = db.SqlCommand;
            SqlTransaction trans = db.SetTransaction(cmd);

            try
            {
                #region 刪除舊資料
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("版本", dt.Rows[0]["版本"]));
                cmd.Parameters.Add(new SqlParameter("部門代碼", dt.Rows[0]["部門代碼"]));

                cmd.CommandText = "DELETE FROM BUDMA WHERE 版本=@版本 AND 部門代碼=@部門代碼";
                cmd.ExecuteNonQuery();
                #endregion

                #region 匯入預算資料
                foreach (DataRow row in dt.Rows)
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("版本", row["版本"]));
                    cmd.Parameters.Add(new SqlParameter("部門代碼", row["部門代碼"]));
                    cmd.Parameters.Add(new SqlParameter("年度", row["年度"]));
                    cmd.Parameters.Add(new SqlParameter("月份", DBNull.Value));
                    cmd.Parameters.Add(new SqlParameter("科目代碼", row["科目代碼"]));
                    cmd.Parameters.Add(new SqlParameter("金額", DBNull.Value));
                    cmd.Parameters.Add(new SqlParameter("建立者", UserInfo.SessionState.Account));

                    //讀取12個月
                    for (int i = 1; i <= 12; i++)
                    {
                        cmd.Parameters["月份"].Value = i.ToString().PadLeft(2, '0');
                        cmd.Parameters["金額"].Value = Convert.ToString(row[i + "月"]).Trim() == "" ? 0 : Convert.ToDecimal(row[i + "月"]);

                        cmd.CommandText = "INSERT BUDMA(版本, 部門代碼, 年度, 月份, 科目代碼, 金額, 確認碼, 建立者, 建立時間) VALUES(@版本, @部門代碼, @年度, @月份, @科目代碼, @金額, 'N', @建立者, GetDate())";
                        cmd.ExecuteNonQuery();
                    }
                }
                #endregion

                trans.Commit();
                bResult = true;
            }
            catch (Exception e)
            {
                trans.Rollback();
                msg = e.Message;
                bResult = false;
            }

            db.CloseDatabaseState("N");
            trans.Dispose();
            cmd.Dispose();

            return bResult;
        }

        /// <summary>取得費用性預算</summary>
        public static DataTable GetBudgetData(string 版本, string 預算部門, string 會計科目, string 年度, string 起始月份, string 結束月份, string 確認碼, string 部門權限)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("版本", 版本);
            param.Add("預算部門", 預算部門 + "%");
            param.Add("會計科目", 會計科目 + "%");
            param.Add("年度", 年度);
            param.Add("起始月份", 起始月份);
            param.Add("結束月份", 結束月份);
            param.Add("確認碼", 確認碼);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (版本 != "") { strWhere += " AND b.版本 = @版本 "; }
            if (預算部門 != "") { strWhere += " AND b.部門代碼 LIKE @預算部門 "; }
            if (部門權限 != "") { strWhere += " AND b.部門代碼 IN (" + 部門權限 + ") "; }
            if (會計科目 != "") { strWhere += " AND b.科目代碼 LIKE @會計科目 "; }
            if (年度 != "") { strWhere += " AND b.年度 = @年度 "; }
            if (起始月份 != "") { strWhere += " AND b.月份 >= @起始月份 "; }
            if (起始月份 != "") { strWhere += " AND b.月份 <= @結束月份 "; }
            if (確認碼 != "") { strWhere += " AND b.確認碼 = @確認碼 "; }

            db.StrSQL = "SELECT b.*, a.MA003 [科目名稱], a.MA007 [報表借貸別], a.MA008 [科目類別], e.ME002 [部門名稱] " +
                        "FROM BUDMA b " +
                        "LEFT OUTER JOIN " + Definition.ERPDBNAME + "ACTMA a ON a.MA001=b.科目代碼 " +
                        "LEFT OUTER JOIN " + Definition.ERPDBNAME + "CMSME e ON e.ME001=b.部門代碼 " +
                        "WHERE 1=1 " + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>預算上傳ERP</summary>
        public static bool SendToERP(string 站別, string 版本, ref string msg)
        {
            bool bResult = false;

            //物件初始化
            DataBase.DataBase db = null;
            if (站別 == "正式")
                db = new DataBase.DataBase(Definition.ERPConnStr);
            else if (站別 == "測試")
                db = new DataBase.DataBase(Definition.ERPTestConnStr);

            //設定Transaction
            SqlCommand cmd = db.SqlCommand;
            SqlTransaction trans = db.SetTransaction(cmd);

            try
            {
                #region 建立預算編號
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("版本", 版本));
                cmd.Parameters.Add("CREATE_DATE", DateTime.Now.ToString("yyyyMMdd"));

                cmd.CommandText = @"IF NOT EXISTS(SELECT * FROM ACTMI WHERE MI001=@版本) BEGIN
                                        INSERT INTO ACTMI(FLAG, MI001, MI002, MI003, MI004) VALUES(1, @版本, @版本, '', 'Y');
                                    END";
                cmd.ExecuteNonQuery();
                #endregion

                #region 建立單頭
                cmd.CommandText = @"DELETE FROM ACTMJ WHERE MJ001=@版本;
                                    INSERT INTO ACTMJ(COMPANY, CREATOR, USR_GROUP, CREATE_DATE, MODIFIER, MODI_DATE, FLAG, MJ001, MJ002, MJ003, MJ004, MJ005, MJ006, MJ007, MJ008, MJ009, MJ010, MJ016, MJ022)
                                    SELECT 'PROWE', 'DS', '', @CREATE_DATE, '', '', 1, 版本, 年度, 科目代碼, '2', 部門代碼, MA007, SUM(金額), '', 'Y', 'N', SUM(金額), 'N' FROM (
	                                    SELECT  版本, 
                                                年度, 
                                                科目代碼, 
                                                部門代碼, 
                                                MA007, 
                                                金額 
                                        FROM {EIPDBNAME}BUDMA 
	                                    LEFT OUTER JOIN ACTMA ON MA001=科目代碼
	                                    UNION ALL
	                                    SELECT	e.預算版本, 
			                                    LEFT(e.預算年月, 4) [年度],
			                                    CASE e.[銷貨類別] WHEN '內銷' THEN '4111' WHEN '外銷' THEN '4112' WHEN '加工' THEN '4661' END [科目代碼],
			                                    e.預算部門,
			                                    '-1',
			                                    (e.金額 * a.匯率)
	                                    FROM {EIPDBNAME}BUDME e
	                                    LEFT OUTER JOIN {EIPDBNAME}BASMA a ON a.類別='BUD' AND (a.年月=e.預算年月 OR a.年月='******') AND a.幣別=e.幣別
                                    ) r
                                    WHERE r.版本=@版本
                                    GROUP BY 版本, 年度, 科目代碼, 部門代碼, MA007";



                cmd.CommandText = cmd.CommandText.Replace("{EIPDBNAME}", Definition.EIPDBNAME);
                cmd.ExecuteNonQuery();
                #endregion

                #region 建立單身
                cmd.CommandText = @"DELETE FROM ACTMK WHERE MK001=@版本;
                                    INSERT INTO ACTMK(COMPANY, CREATOR, USR_GROUP, CREATE_DATE, MODIFIER, MODI_DATE, FLAG, MK001, MK002, MK003, MK004, MK005, MK006, MK008, MK012, MK013, MK014)
                                    SELECT 'PROWE', 'DS', '', @CREATE_DATE, '', '', 1, 版本, 年度, 科目代碼, 部門代碼, 月份, SUM(金額), '', SUM(金額), '0000', '0000' FROM (
	                                    SELECT 版本, 年度, 科目代碼, 部門代碼, 月份, 金額 FROM {EIPDBNAME}BUDMA
	                                    UNION ALL
	                                    SELECT	預算版本, 
			                                    LEFT(預算年月, 4) [年度],
			                                    CASE [銷貨類別] WHEN '內銷' THEN '4111' WHEN '外銷' THEN '4112' WHEN '加工' THEN '4661' END [科目代碼],
			                                    預算部門,
			                                    RIGHT(預算年月, 2) [月份],
			                                    (金額 * 匯率)
	                                    FROM {EIPDBNAME}BUDME e
	                                    LEFT OUTER JOIN {EIPDBNAME}BASMA a ON a.類別='BUD' AND (a.年月=e.預算年月 OR a.年月='******') AND a.幣別=e.幣別
                                    ) r
                                    WHERE 版本=@版本
                                    GROUP BY 版本, 年度, 科目代碼, 部門代碼, 月份";

                cmd.CommandText = cmd.CommandText.Replace("{EIPDBNAME}", Definition.EIPDBNAME);
                cmd.ExecuteNonQuery();
                #endregion

                trans.Commit();
                bResult = true;
            }
            catch (Exception e)
            {
                trans.Rollback();
                msg = e.Message;
                bResult = false;
            }

            db.CloseDatabaseState("N");
            trans.Dispose();
            cmd.Dispose();

            return bResult;
        }

        /// <summary>更新版本的確認碼</summary>
        public static bool SetVersionStatus(string 版本, string 部門代碼, string 確認碼, ref string msg)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("版本", 版本);
            param.Add("部門代碼", 部門代碼);
            param.Add("確認碼", 確認碼);
            db.SqlParams = param;

            db.StrSQL = "UPDATE BUDMA SET 確認碼=@確認碼 WHERE 版本=@版本 AND 部門代碼=@部門代碼";

            int i = db.ExecuteSQL();
            return i > 0;
        }

        /// <summary>取得版本清單</summary>
        public static DataTable GetVersionList(string 版本, string 部門代碼, string 確認碼)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("版本", 版本);
            param.Add("部門代碼", 部門代碼);
            param.Add("確認碼", 確認碼);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (版本 != "") { strWhere += " AND 版本 = @版本 "; }
            if (部門代碼 != "") { strWhere += " AND 部門代碼 = @部門代碼 "; }
            if (確認碼 != "") { strWhere += " AND 確認碼 = @確認碼 "; }

            db.StrSQL = "SELECT 版本, 年度, 部門代碼, ME002 [部門名稱], SUM(金額) [合計], 確認碼 " +
                        "FROM BUDMA " +
                        "LEFT OUTER JOIN " + Definition.ERPDBNAME + "CMSME ON ME001=部門代碼 " +
                        "WHERE 1=1" + strWhere +
                        "GROUP BY 版本, 年度, 部門代碼, ME002, 確認碼 " +
                        "ORDER BY 版本, 部門代碼";

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>複製預算版本</summary>
        public static bool CopyVersion(string 原版本, string 新版本, ref string msg)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("原版本", 原版本);
            param.Add("新版本", 新版本);
            param.Add("建立者", UserInfo.SessionState.Account);
            db.SqlParams = param;

            db.StrSQL = @"INSERT INTO BUDMC SELECT @新版本, 說明, 鎖定碼 FROM BUDMC WHERE 預算版本=@原版本;
                          INSERT INTO BUDMA SELECT @新版本, 部門代碼, 年度, 月份, 科目代碼, 金額, 確認碼, @建立者, getdate() FROM BUDMA WHERE 版本=@原版本;
                          INSERT INTO BUDME SELECT 公司別, @新版本, 預算部門, 預算年月, 業務員代號, 客戶簡稱, 付款條件, 銷貨類別, 品號, 品名, 幣別, 單價, 數量, 單位, 金額, 狀態碼 FROM BUDME WHERE 預算版本=@原版本;";

            int i = db.ExecuteSQL();
            return i > 0;
        }

        /// <summary>寫入營收預算資料</summary>
        public static bool SetSaleBudgetData(DataTable dt, ref string msg)
        {
            bool bResult = false;

            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //設定Transaction
            SqlCommand cmd = db.SqlCommand;
            SqlTransaction trans = db.SetTransaction(cmd);

            try
            {
                #region 刪除舊資料
                DataTable dtYM = dt.DefaultView.ToTable(true, "預算版本", "業務員代號");
                foreach (DataRow row in dtYM.Rows)
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("預算版本", row["預算版本"]));
                    cmd.Parameters.Add(new SqlParameter("業務員代號", row["業務員代號"]));

                    cmd.CommandText = "DELETE FROM BUDME WHERE 預算版本=@預算版本 AND 業務員代號=@業務員代號";
                    cmd.ExecuteNonQuery();
                }
                #endregion

                #region 寫入營收預算資料
                foreach (DataRow row in dt.Rows)
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("公司別", row["公司別"]));
                    cmd.Parameters.Add(new SqlParameter("預算版本", row["預算版本"]));
                    cmd.Parameters.Add(new SqlParameter("預算部門", row["預算部門"]));
                    cmd.Parameters.Add(new SqlParameter("預算年月", row["年月"]));
                    cmd.Parameters.Add(new SqlParameter("業務員代號", row["業務員代號"]));
                    cmd.Parameters.Add(new SqlParameter("客戶簡稱", row["客戶簡稱"]));
                    cmd.Parameters.Add(new SqlParameter("付款條件", row["付款條件"]));
                    cmd.Parameters.Add(new SqlParameter("銷貨類別", row["銷貨類別"]));
                    cmd.Parameters.Add(new SqlParameter("品號", row["品號"]));
                    cmd.Parameters.Add(new SqlParameter("品名", row["品名"]));
                    cmd.Parameters.Add(new SqlParameter("幣別", row["幣別"]));
                    cmd.Parameters.Add(new SqlParameter("單價", row["單價"]));
                    cmd.Parameters.Add(new SqlParameter("單位", row["單位"]));
                    cmd.Parameters.Add(new SqlParameter("數量", row["數量"]));
                    cmd.Parameters.Add(new SqlParameter("金額", Convert.ToDecimal(row["數量"]) * Convert.ToDecimal(row["單價"])));
                    cmd.Parameters.Add(new SqlParameter("狀態碼", "N"));

                    cmd.CommandText = "INSERT BUDME(公司別, 預算版本, 預算部門, 預算年月, 業務員代號, 客戶簡稱, 付款條件, 銷貨類別, 品號, 品名, 幣別, 單價, 單位, 數量, 金額, 狀態碼) " +
                                      "VALUES(@公司別, @預算版本, @預算部門, @預算年月, @業務員代號, @客戶簡稱, @付款條件, @銷貨類別, @品號, @品名, @幣別, @單價, @單位, @數量, @金額, @狀態碼)";
                    cmd.ExecuteNonQuery();
                }
                #endregion

                trans.Commit();
                bResult = true;
            }
            catch (Exception e)
            {
                trans.Rollback();
                msg = e.Message;
                bResult = false;
            }

            db.CloseDatabaseState("N");
            trans.Dispose();
            cmd.Dispose();

            return bResult;
        }

        /// <summary>取得營收預算資料</summary>
        public static DataTable GetSaleBudgetData(string 公司別, string 預算版本, string 預算部門, string 業務員代號, string 預算年月, string 品名, string 業務員清單, string 狀態碼)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("預算版本", 預算版本);
            param.Add("預算部門", 預算部門);
            param.Add("業務員代號", 業務員代號);
            param.Add("預算年月", 預算年月 + "%");
            param.Add("品名", 品名 + "%");
            param.Add("狀態碼", 狀態碼);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (公司別 != "") { strWhere += " AND e.公司別 = @公司別 "; }
            if (預算版本 != "") { strWhere += " AND e.預算版本 = @預算版本 "; }
            if (預算部門 != "") { strWhere += " AND e.預算部門 = @預算部門 "; }
            if (業務員代號 != "") { strWhere += " AND e.業務員代號 = @業務員代號 "; }
            if (預算年月 != "") { strWhere += " AND e.預算年月 LIKE @預算年月 "; }
            if (品名 != "") { strWhere += " AND e.品名 LIKE @品名 "; }
            if (狀態碼 != "") { strWhere += " AND e.狀態碼 = @狀態碼 "; }
            if (業務員清單 != "") { strWhere += " AND e.業務員代號 IN (" + 業務員清單 + ") "; }

            db.StrSQL = "SELECT e.公司別, e.預算版本, e.預算部門, e.業務員代號, g.姓名 [業務員姓名], e.預算年月, e.客戶簡稱, e.付款條件, e.銷貨類別, a.MA003 [商品分類], e.品號, e.品名, b.MB003 [規格], e.幣別, (e.單價 * f.匯率) [本幣單價], (e.數量 * ISNULL(d.MD004,1)) [數量M2], (e.金額 * f.匯率) [本幣金額], e.狀態碼 " +
                        "FROM BUDME e " +
                        "LEFT OUTER JOIN RFCMG g ON g.人員代號=e.業務員代號 " +
                        "LEFT OUTER JOIN BASMA f ON f.類別='BUD' AND (f.年月=e.預算年月 OR f.年月='******') AND f.幣別=e.幣別 " +
                        "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMB b ON b.MB001=e.品號 " +
                        "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMD d ON d.MD001=b.MB001 AND d.MD002=e.單位 " +
                        "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMA a ON a.MA001='3' AND a.MA002=b.MB006 " +
                        "WHERE 1=1 " + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>更新營收預算的狀態碼</summary>
        public static bool SetSaleBudgetStatus(string 業務員代號, string 預算版本, string 狀態碼)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("業務員代號", 業務員代號);
            param.Add("預算版本", 預算版本);
            param.Add("狀態碼", 狀態碼);
            db.SqlParams = param;

            db.StrSQL = "UPDATE BUDME SET 狀態碼=@狀態碼 WHERE 業務員代號=@業務員代號 AND 預算版本=@預算版本";

            int i = db.ExecuteSQL();
            return i > 0;
        }

        /// <summary>取得預算版本清單</summary>
        public static DataTable GetBudgetVersion(string 預算版本, string 鎖定碼)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("預算版本", 預算版本);
            param.Add("鎖定碼", 鎖定碼);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (預算版本 != "") { strWhere += " AND 預算版本 = @預算版本 "; }
            if (鎖定碼 != "") { strWhere += " AND 鎖定碼 = @鎖定碼 "; }

            db.StrSQL = "SELECT * " +
                        "FROM BUDMC " +
                        "WHERE 1=1" + strWhere +
                        "ORDER BY 預算版本";

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>更改預算版本的鎖定碼</summary>
        public static bool SetBudgetVersionLock(string 預算版本, string 鎖定碼)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("預算版本", 預算版本);
            param.Add("鎖定碼", 鎖定碼);
            db.SqlParams = param;

            db.StrSQL = "UPDATE BUDMC SET 鎖定碼=@鎖定碼 WHERE 預算版本=@預算版本";

            int i = db.ExecuteSQL();
            return i > 0;
        }

        /// <summary>取得人員的預算部門清單</summary>
        public static string GetAcctDept(string 人員代號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("人員代號", 人員代號);
            db.SqlParams = param;

            db.StrSQL = "SELECT 預算部門清單 FROM BUDMD WHERE 人員代號=@人員代號";

            string strResult = db.ExecuteScalar();
            strResult = string.IsNullOrEmpty(strResult) ? "" : strResult;
            return strResult;
        }

        /// <summary>單筆更新預算的數字</summary>
        public static bool UpdateBudgetValue(string 預算版本, string 預算部門, string 科目代碼, string 月份, string 金額)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("預算版本", 預算版本);
            param.Add("預算部門", 預算部門);
            param.Add("科目代碼", 科目代碼);
            param.Add("月份", 月份);
            param.Add("金額", 金額);
            db.SqlParams = param;

            db.StrSQL = "UPDATE BUDMA SET 金額=@金額 WHERE 版本=@預算版本 AND 部門代碼=@預算部門 AND 科目代碼=@科目代碼 AND 月份=@月份";

            int i = db.ExecuteSQL();
            return i > 0;
        }
    }
}