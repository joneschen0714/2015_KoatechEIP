﻿using System;
using System.Data;
using System.Data.SqlClient;
using UHR.Authority;

namespace UHR
{
    public class DAL
    {
        public DAL()
        {

        }

        /// <summary>取得使用者相關資料</summary>
        public static DataTable GetUserInfo(string _id, string _account, string _email)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", _id);
            param.Add("Email", _email);
            param.Add("Account", _account);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (_id != "") { strWhere += " AND ID=@ID "; }
            if (_email != "") { strWhere += " AND Email=@Email "; }
            if (_account != "") { strWhere += " AND LOWER(Account)=@Account "; }

            db.StrSQL = "SELECT * FROM ADMMA WHERE 1=1" + strWhere;
            return db.ExecuteDataTable();
        }

        /// <summary>取得使用者清單資料</summary>
        public static DataTable GetUserList(string _account, string _name, string _sort, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Account", "%" + _account + "%");
            param.Add("Name", "%" + _name + "%");
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (_account != "") { strWhere += " AND a.Account LIKE @Account "; }
            if (_name != "") { strWhere += " AND (a.FirstName + a.LastName) LIKE @Name "; }

            string strSQL = "SELECT a.ID, a.Email, a.Account, a.FirstName + a.LastName [Name], a.IsSuper, a.IsLock FROM ADMMA a " +
                            "WHERE 1=1 " + strWhere;

            DataTable dtResult = db.ExecuteDataTable(strSQL, _sort, _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>取得使用者群組相關資料</summary>
        public static DataRow GetGroupInfo(string _groupnum)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("GroupNumber", _groupnum);
            db.SqlParams = param;

            db.StrSQL = "SELECT * FROM AdminGroup WHERE GroupNumber=@GroupNumber";

            DataRow row = null;
            DataTable dtResult = db.ExecuteDataTable();
            if (dtResult.Rows.Count > 0) { row = dtResult.Rows[0]; }

            return row;
        }

        /// <summary>取得使用者權限資料</summary>
        public static DataTable GetUserAuthority(object _account, object _menuno, object _flow, object _admin, object _enabled)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Account", _account);
            param.Add("MenuNo", _menuno);
            param.Add("Flow", _flow);
            param.Add("Admin", _admin);
            param.Add("Enabled", _enabled);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (_account != "") { strWhere += " AND Account=@Account "; }
            if (_menuno != "") { strWhere += " AND MenuNo=@MenuNo "; }
            if (_flow != "") { strWhere += " AND Flow=@Flow "; }
            if (_admin != "") { strWhere += " AND Admin=@Admin "; }
            if (_enabled != "") { strWhere += " AND Enabled=@Enabled "; }

            db.StrSQL = "SELECT * FROM ADMMB WHERE 1=1" + strWhere;
            return db.ExecuteDataTable();
        }

        /// <summary>取得使用者群組清單資料</summary>
        public static DataTable GetGroupList(string _sort, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            string strSQL = "SELECT * FROM AdminGroup";

            DataTable dtResult = db.ExecuteDataTable(strSQL, _sort, _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>取得選單相關資料</summary>
        public static DataTable GetMenuList(string MenuNo, string ParentNo, string Type, string Enabled)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MenuNo", MenuNo);
            param.Add("ParentNo", ParentNo);
            param.Add("Type", Type);
            param.Add("Enabled", Enabled);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(MenuNo)) { strWhere += " AND MenuNo=@MenuNo "; }
            if (!string.IsNullOrEmpty(ParentNo)) { strWhere += " AND ParentNo=@ParentNo "; }
            if (!string.IsNullOrEmpty(Type)) { strWhere += " AND Type=@Type "; }
            if (!string.IsNullOrEmpty(Enabled)) { strWhere += " AND Enabled=@Enabled "; }

            db.StrSQL = "SELECT * FROM ADMMC WHERE 1=1 " + strWhere + " ORDER BY OrderID";
            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>變更密碼</summary>
        public static bool ChangePassword(int _ID, string _oPwd, string _Pwd, ref string _Msg)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", _ID);
            param.Add("OldPassword", _oPwd);
            param.Add("NewPassword", _Pwd);
            db.SqlParams = param;

            db.StrSQL = "UPDATE ADMMA SET Password=@NewPassword WHERE ID=@ID AND Password=@OldPassword";

            int iResult = db.ExecuteSQL();

            if (iResult <= 0)
            {
                _Msg = "找不到使用者或者原密碼錯誤!";
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>取得系統參數</summary>
        public static DataTable GetSystemConfig(string Key, string Value)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Key", Key);
            param.Add("Value", Value);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (Key != "") { strWhere += " AND ParaKey = @Key "; }
            if (Value != "") { strWhere += " AND ParaValue = @Value "; }

            db.StrSQL = "SELECT * FROM ADMMD WHERE 1=1 " + strWhere;
            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得待辦事項</summary>
        public static DataTable GetWorkList(string type, string account, string _params)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Type", type);
            param.Add("Account", account);
            param.Add("Params", _params);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (account != "") { strWhere += " AND Account=@Account "; }
            if (type != "") { strWhere += " AND Type=@Type "; }
            if (_params != "") { strWhere += " AND Params=@Params "; }

            db.StrSQL = "SELECT * FROM ADMMH WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>設定待辦事項</summary>
        public static void SetWorkList(string _type, string _account, string _params, string _subject)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Type", _type);
            param.Add("Account", _account);
            param.Add("Params", _params);
            param.Add("Subject", _subject);
            db.SqlParams = param;

            db.StrSQL = "INSERT INTO ADMMH(Type, Account, Params, Subject) VALUES(@Type, @Account, @Params, @Subject)";
            db.ExecuteSQL();
        }

        /// <summary>刪除待辦事項</summary>
        public static void DelWorkList(string _type, string _account, string _params)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Type", _type);
            param.Add("Account", _account);
            param.Add("Params", _params);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (_type != "") { strWhere += " AND Type = @Type "; }
            if (_account != "") { strWhere += " AND Account = @Account "; }
            if (_params != "") { strWhere += " AND Params = @Params "; }

            db.StrSQL = "DELETE FROM ADMMH WHERE 1=1" + strWhere;
            db.ExecuteSQL();
        }

        /// <summary>取得部門階層資料</summary>
        public static DataTable GetDeptList(string DepCode)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("DepCode", DepCode + "%");
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (DepCode != "") { strWhere += " AND Dep_Code LIKE @DepCode "; }

            db.StrSQL = "SELECT * FROM ADMMF " +
                        "WHERE Enabled='Y'" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得幣別匯率</summary>
        public static DataTable GetCurrencyRate(string Type, string YM, string Currency, string _sort, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Type", Type);
            param.Add("YM", YM);
            param.Add("Currency", Currency);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (Type != "") { strWhere += " AND 類別 = @Type "; }
            if (YM != "") { strWhere += " AND 年月 = @YM "; }
            if (Currency != "") { strWhere += " AND 幣別 = @Currency "; }

            string strSQL = "SELECT * FROM BASMA WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable(strSQL, _sort, _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>寫入幣別匯率</summary>
        public static bool SetCurrencyRate(DataTable dt, ref string msg)
        {
            bool bResult = false;

            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //設定Transaction
            SqlCommand cmd = db.SqlCommand;
            SqlTransaction trans = db.SetTransaction(cmd);

            try
            {
                foreach (DataRow row in dt.Rows)
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("類別", row["類別"]));
                    cmd.Parameters.Add(new SqlParameter("年月", row["年月"]));
                    cmd.Parameters.Add(new SqlParameter("幣別", row["幣別"]));
                    cmd.Parameters.Add(new SqlParameter("匯率", row["匯率"]));
                    cmd.Parameters.Add(new SqlParameter("建立者", UserInfo.SessionState.Account));

                    cmd.CommandText = @"DELETE FROM BASMA WHERE 類別=@類別 AND 年月=@年月 AND 幣別=@幣別;
                                        INSERT BASMA(類別, 年月, 幣別, 匯率, 建立者, 建立時間) VALUES(@類別, @年月, @幣別, @匯率, @建立者, GetDate())";
                    cmd.ExecuteNonQuery();
                }

                trans.Commit();
                bResult = true;
            }
            catch (Exception e)
            {
                trans.Rollback();
                msg = e.Message;
                bResult = false;
            }

            db.CloseDatabaseState("N");
            trans.Dispose();
            cmd.Dispose();

            return bResult;
        }
    }
}