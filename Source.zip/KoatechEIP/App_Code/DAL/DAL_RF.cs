﻿using System;
using System.Data;
using System.Linq;
using System.Data.SqlClient;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace UHR
{
    public class DAL_RF
    {
        public DAL_RF()
        {

        }

        /// <summary>取得銷售預測資料</summary>
        public static DataTable GetForecastData(string ID, string 公司別, string 預測年月, string 銷售分類, string 業務員代號, string 客戶簡稱, string 品名, string 業務人員清單)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", ID);
            param.Add("公司別", 公司別);
            param.Add("預測年月", 預測年月 + "%");
            param.Add("銷售分類", 銷售分類);
            param.Add("業務員代號", 業務員代號);
            param.Add("客戶簡稱", 客戶簡稱);
            param.Add("品名", 品名);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (ID != "") { strWhere += " AND r.ID = @ID "; }
            if (公司別 != "") { strWhere += " AND r.公司別 = @公司別 "; }
            if (預測年月 != "") { strWhere += " AND r.預測年月 LIKE @預測年月 "; }
            if (銷售分類 != "") { strWhere += " AND a.MA003 = @銷售分類 "; }
            if (業務員代號 != "") { strWhere += " AND r.業務員代號 = @業務員代號 "; }
            if (客戶簡稱 != "") { strWhere += " AND r.客戶簡稱 = @客戶簡稱 "; }
            if (品名 != "") { strWhere += " AND b.MB002 = @品名 "; }
            if (業務人員清單 != "") { strWhere += " AND r.業務員代號 IN (" + 業務人員清單 + ") "; }

            db.StrSQL = "SELECT r.ID, r.公司別, r.預測年月, r.業務員代號, g.姓名 [業務員姓名], r.客戶簡稱, a.MA003 [銷售分類], r.品號, RTRIM(b.MB002) [品名], RTRIM(b.MB003) [規格], r.幣別, r.單價, r.數量, r.單位, (r.數量 * ISNULL(d.MD004,1)) [數量M2], r.金額, (r.金額 * f.匯率) [本幣金額], r.說明, r.狀態碼 " +
                        "FROM RFCMA r " +
                        "LEFT OUTER JOIN RFCMG g ON g.人員代號=r.業務員代號 " +
                        "LEFT OUTER JOIN BASMA f ON f.類別='RFC' AND (f.年月=r.預測年月 OR f.年月='******') AND f.幣別=r.幣別 " +
                        "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMB b ON b.MB001=r.品號 " +
                        "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMD d ON d.MD001=b.MB001 AND d.MD002=r.單位 " +
                        "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMA a ON a.MA001='2' AND a.MA002=b.MB006 " +
                        "WHERE 1=1 " + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得銷售預測版本資料</summary>
        public static DataTable GetForecastHistoryData(string 公司別, string 預測年月, string 銷售分類, string 業務員代號, string 客戶簡稱, string 品名, string 版本, string 業務人員清單)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("預測年月", 預測年月 + "%");
            param.Add("銷售分類", 銷售分類);
            param.Add("業務員代號", 業務員代號);
            param.Add("客戶簡稱", 客戶簡稱);
            param.Add("品名", 品名);
            param.Add("版本", 版本);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (公司別 != "") { strWhere += " AND r.公司別 = @公司別 "; }
            if (預測年月 != "") { strWhere += " AND r.預測年月 LIKE @預測年月 "; }
            if (銷售分類 != "") { strWhere += " AND a.MA003 = @銷售分類 "; }
            if (業務員代號 != "") { strWhere += " AND r.業務員代號 = @業務員代號 "; }
            if (客戶簡稱 != "") { strWhere += " AND r.客戶簡稱 = @客戶簡稱 "; }
            if (品名 != "") { strWhere += " AND b.MB002 = @品名 "; }
            if (版本 != "") { strWhere += " AND r.版本 = @版本 "; }
            if (業務人員清單 != "") { strWhere += " AND r.業務員代號 IN (" + 業務人員清單 + ") "; }

            db.StrSQL = "SELECT r.公司別, r.預測年月, r.業務員代號, g.姓名 [業務員姓名], r.客戶簡稱, a.MA003 [銷售分類], r.品號, RTRIM(b.MB002) [品名], RTRIM(b.MB003) [規格], r.幣別, r.單價, r.數量, r.單位, (r.數量 * ISNULL(d.MD004,1)) [數量M2], r.金額, (r.金額 * f.匯率) [本幣金額], r.說明, r.版本 " +
                        "FROM RFCMC r " +
                        "LEFT OUTER JOIN RFCMG g ON g.人員代號=r.業務員代號 " +
                        "LEFT OUTER JOIN BASMA f ON f.類別='RFC' AND (f.年月=r.預測年月 OR f.年月='******') AND f.幣別=r.幣別 " +
                        "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMB b ON b.MB001=r.品號 " +
                        "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMD d ON d.MD001=b.MB001 AND d.MD002=r.單位 " +
                        "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMA a ON a.MA001='2' AND a.MA002=b.MB006 " +
                        "WHERE 1=1 " + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>寫入銷售預測資料</summary>
        public static bool SetForecastData(DataTable dt, ref string msg)
        {
            bool bResult = false;

            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //設定Transaction
            SqlCommand cmd = db.SqlCommand;
            SqlTransaction trans = db.SetTransaction(cmd);

            try
            {
                #region 刪除舊資料
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("預測年月", dt.Rows[0]["預測年月"]));
                cmd.Parameters.Add(new SqlParameter("業務員代號", dt.Rows[0]["業務員代號"]));
                cmd.CommandText = "DELETE FROM RFCMA WHERE 預測年月=@預測年月 AND 業務員代號=@業務員代號";
                cmd.ExecuteNonQuery();
                #endregion

                #region 匯入預測資料
                foreach (DataRow row in dt.Rows)
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("公司別", row["公司別"]));
                    cmd.Parameters.Add(new SqlParameter("預測年月", row["預測年月"]));
                    cmd.Parameters.Add(new SqlParameter("業務員代號", row["業務員代號"]));
                    cmd.Parameters.Add(new SqlParameter("客戶簡稱", row["客戶簡稱"]));
                    cmd.Parameters.Add(new SqlParameter("品號", row["品號"]));
                    cmd.Parameters.Add(new SqlParameter("幣別", row["幣別"]));
                    cmd.Parameters.Add(new SqlParameter("單價", row["單價"]));
                    cmd.Parameters.Add(new SqlParameter("數量", row["數量"]));
                    cmd.Parameters.Add(new SqlParameter("金額", Convert.ToInt32(row["數量"]) * Convert.ToDecimal(row["單價"])));
                    cmd.Parameters.Add(new SqlParameter("說明", row["說明"].ToString()));

                    cmd.CommandText = "INSERT RFCMA(公司別, 預測年月, 業務員代號, 客戶簡稱, 品號, 幣別, 單價, 數量, 單位, 金額, 說明) " +
                                      "SELECT @公司別, @預測年月, @業務員代號, @客戶簡稱, @品號, @幣別, @單價, @數量, CASE WHEN MB156='' THEN MB090 ELSE MB156 END [單位], @金額, @說明 " +
                                      "FROM " + Definition.ERPDBNAME + "INVMB " +
                                      "WHERE MB001=@品號";
                    cmd.ExecuteNonQuery();
                }
                #endregion

                trans.Commit();
                bResult = true;
            }
            catch (Exception e)
            {
                trans.Rollback();
                msg = e.Message;
                bResult = false;
            }

            db.CloseDatabaseState("N");
            trans.Dispose();
            cmd.Dispose();

            return bResult;
        }

        /// <summary>建立銷售預測版本</summary>
        public static bool SetRF_Version(string 預測年月, string 版本)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("預測年月", 預測年月);
            param.Add("版本", 版本);
            db.SqlParams = param;

            db.StrSQL = "INSERT RFCMC(公司別, 預測年月, 業務員代號, 客戶簡稱, 品號, 幣別, 單價, 數量, 單位, 金額, 說明, 版本) " +
                        "SELECT 公司別, 預測年月, 業務員代號, 客戶簡稱, 品號, 幣別, 單價, 數量, 單位, 金額, 說明, @版本 " +
                        "FROM RFCMA " +
                        "WHERE 預測年月 = @預測年月";

            int iResult = db.ExecuteSQL();
            return iResult > 0;
        }

        /// <summary>審核銷售預測版本</summary>
        public static bool AuditRF_Version(string 預測年月, string 業務員代號, string 狀態碼, ref string msg)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("預測年月", 預測年月);
            param.Add("業務員代號", 業務員代號);
            param.Add("狀態碼", 狀態碼);
            db.SqlParams = param;

            db.StrSQL = "UPDATE RFCMA SET 狀態碼=@狀態碼 WHERE 業務員代號=@業務員代號 AND 預測年月=@預測年月";

            int iResult = db.ExecuteSQL();
            return iResult > 0;
        }

        /// <summary>取得實際銷售資料</summary>
        public static DataTable GetRealityData(string 公司別, string 年月, string 銷售分類, string 業務員代號, string 客戶簡稱, string 品名, string 業務人員清單)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("年月", 年月 + "%");
            param.Add("銷售分類", 銷售分類);
            param.Add("業務員代號", 業務員代號);
            param.Add("客戶簡稱", 客戶簡稱);
            param.Add("品名", 品名);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (公司別 != "") { strWhere += " AND r.公司別 = @公司別 "; }
            if (年月 != "") { strWhere += " AND r.日期 LIKE @年月 "; }
            if (銷售分類 != "") { strWhere += " AND a.MA003 = @銷售分類 "; }
            if (業務員代號 != "") { strWhere += " AND r.業務員代號 = @業務員代號 "; }
            if (客戶簡稱 != "") { strWhere += " AND r.客戶簡稱 = @客戶簡稱 "; }
            if (品名 != "") { strWhere += " AND r.品名 = @品名 "; }
            if (業務人員清單 != "") { strWhere += " AND r.業務員代號 IN (" + 業務人員清單 + ")"; }

            db.StrSQL = "SELECT r.*, a.MA003 [銷售分類] FROM RFCME r " +
                        "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMB b ON b.MB001=r.品號 " +
                        "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMA a ON a.MA001='2' AND a.MA002=MB006 " +
                        "WHERE 1=1 " + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>寫入實際銷售資料</summary>
        public static bool SetRealityData(string 年月, DataTable dt, ref string msg)
        {
            bool bResult = false;

            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //設定Transaction
            SqlCommand cmd = db.SqlCommand;
            SqlTransaction trans = db.SetTransaction(cmd);

            try
            {
                #region 刪除舊資料
                DataTable dtCompany = dt.DefaultView.ToTable(true, "公司別");
                foreach (DataRow row in dtCompany.Rows)
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("年月", 年月 + "%"));
                    cmd.Parameters.Add(new SqlParameter("公司別", row["公司別"]));

                    cmd.CommandText = "DELETE FROM RFCME WHERE 公司別=@公司別 AND 日期 LIKE @年月";
                    cmd.ExecuteNonQuery();
                }
                #endregion

                #region 寫入實際資料
                foreach (DataRow row in dt.Rows)
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("公司別", row["公司別"]));
                    cmd.Parameters.Add(new SqlParameter("日期", row["日期"]));
                    cmd.Parameters.Add(new SqlParameter("類別", row["類別"]));
                    cmd.Parameters.Add(new SqlParameter("業務員代號", row["業務員代號"]));
                    cmd.Parameters.Add(new SqlParameter("業務員姓名", row["業務員姓名"]));
                    cmd.Parameters.Add(new SqlParameter("客戶代號", row["客戶代號"]));
                    cmd.Parameters.Add(new SqlParameter("客戶簡稱", row["客戶簡稱"]));
                    cmd.Parameters.Add(new SqlParameter("品號", row["品號"]));
                    cmd.Parameters.Add(new SqlParameter("品名", row["品名"]));
                    cmd.Parameters.Add(new SqlParameter("規格", row["規格"]));
                    cmd.Parameters.Add(new SqlParameter("批號", row["批號"]));
                    cmd.Parameters.Add(new SqlParameter("數量", row["數量"]));
                    cmd.Parameters.Add(new SqlParameter("單位", row["單位"]));
                    cmd.Parameters.Add(new SqlParameter("數量M2", row["數量M2"]));
                    cmd.Parameters.Add(new SqlParameter("幣別", row["幣別"]));
                    cmd.Parameters.Add(new SqlParameter("單價", row["單價"]));
                    cmd.Parameters.Add(new SqlParameter("匯率", row["匯率"]));
                    cmd.Parameters.Add(new SqlParameter("原幣金額", row["原幣金額"]));
                    cmd.Parameters.Add(new SqlParameter("本幣金額", row["本幣金額"]));

                    cmd.CommandText = "INSERT RFCME(公司別, 日期, 類別, 業務員代號, 業務員姓名, 客戶代號, 客戶簡稱, 品號, 品名, 規格, 批號, 數量, 單位, 數量M2, 幣別, 單價, 匯率, 原幣金額, 本幣金額) " +
                                      "VALUES(@公司別, @日期, @類別, @業務員代號, @業務員姓名, @客戶代號, @客戶簡稱, @品號, @品名, @規格, @批號, @數量, @單位, @數量M2, @幣別, @單價, @匯率, @原幣金額, @本幣金額)";
                    cmd.ExecuteNonQuery();
                }
                #endregion

                trans.Commit();
                bResult = true;
            }
            catch (Exception e)
            {
                trans.Rollback();
                msg = e.Message;
                bResult = false;
            }

            db.CloseDatabaseState("N");
            trans.Dispose();
            cmd.Dispose();

            return bResult;
        }

        /// <summary>取得組織階層</summary>
        public static DataTable GetRF_Group(string 人員代號, string 職稱, string 審核)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("助理代號", "%" + 人員代號 + "%");
            param.Add("人員代號", 人員代號);
            param.Add("職稱", 職稱);
            param.Add("審核", 審核);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (人員代號 != "") { strWhere += " AND (助理 LIKE @助理代號 OR 人員代號=@人員代號 OR 層級 LIKE (SELECT 層級+'%' FROM RFCMG WHERE 人員代號=@人員代號)) "; }
            if (職稱 != "") { strWhere += " AND 職稱 = @職稱 "; }
            if (審核 != "") { strWhere += " AND 審核 = @審核 "; }

            db.StrSQL = "SELECT * FROM ADMMA " +
                        "INNER JOIN RFCMG ON Account=人員代號 " +
                        "WHERE IsLock=0" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得上級組織階層</summary>
        public static DataTable GetGroupManage(string 人員代號, string 審核)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("人員代號", 人員代號);
            param.Add("審核", 審核);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (審核 != "") { strWhere += " AND 審核 = @審核 "; }

            db.StrSQL = "SELECT * FROM ADMMA " +
                        "INNER JOIN RFCMG ON Account=人員代號 " +
                        "WHERE IsLock=0 AND 層級=(SELECT LEFT(層級, LEN(層級)-1) FROM RFCMG WHERE 人員代號=@人員代號)" + strWhere;

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>批次更銷售預測資料</summary>
        public static bool UpdateRFItem(List<dynamic> list, ref string msg)
        {
            bool bResult = false;

            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //設定Transaction
            SqlCommand cmd = db.SqlCommand;
            SqlTransaction trans = db.SetTransaction(cmd);

            try
            {
                //逐筆更新
                foreach (dynamic item in list)
                {
                    //增加SQL參數
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("ID", (String)item.ID));
                    cmd.Parameters.Add(new SqlParameter("Qty", (Int32)item.Qty));
                    cmd.Parameters.Add(new SqlParameter("Desc", (String)item.Desc));

                    //執行更新
                    cmd.CommandText = "UPDATE RFCMA SET 數量=@Qty, 金額=單價 * @Qty, 說明=@Desc WHERE ID=@ID";
                    cmd.ExecuteNonQuery();
                }

                trans.Commit();
                bResult = true;
            }
            catch (Exception e)
            {
                trans.Rollback();
                msg = e.Message;
                bResult = false;
            }

            db.CloseDatabaseState("N");
            trans.Dispose();
            cmd.Dispose();

            return bResult;
        }

        /// <summary>取得歷年銷售趨勢圖表</summary>
        public static DataTable GetSAL01(int iYear, string Company, string BU, string Class, string Product, string Custom, string Sales, string AuthCode)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("iYear", iYear);
            param.Add("Company", Company);
            param.Add("Class", Class);
            param.Add("Custom", "%" + Custom + "%");
            param.Add("Sales", Sales);
            param.Add("AuthCode", AuthCode + "%");
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (Company != "") { strWhere += " AND e.公司別 = @Company "; }
            if (BU != "") { strWhere += " AND b.MB006 IN (" + BU + ") "; }
            if (Custom != "") { strWhere += " AND e.客戶簡稱 LIKE @Custom "; }
            if (Class != "") { strWhere += " AND b.MB008 = @Class "; }
            if (Product != "") { strWhere += " AND e.品名 IN (" + Product + ") "; }
            if (Sales != "") { strWhere += " AND e.業務員代號 = @Sales "; }
            if (AuthCode != "") { strWhere += " AND g.層級 LIKE @AuthCode "; }

            db.StrSQL = "SELECT LEFT(日期,4) [年度], SUBSTRING(日期,5,2) [月份], SUM(數量M2) [數量M2], SUM(本幣金額) [本幣金額] " +
                        "FROM RFCME e " +
                        "LEFT OUTER JOIN RFCMG g ON g.人員代號 = e.業務員代號 " +
                        "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMB b ON b.MB001=e.品號 " +
                        "WHERE LEFT(日期,4) >= @iYear " + strWhere +
                        "GROUP BY LEFT(日期,4), SUBSTRING(日期,5,2) " +
                        "ORDER BY LEFT(日期,4), SUBSTRING(日期,5,2) ";

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得堆疊銷售趨勢圖表</summary>
        public static DataTable GetSAL02(string StockType, string Year, string Company, string BU, string Class, string Product, string Custom, string Sales, string AuthCode)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Year", Year);
            param.Add("Company", Company);
            param.Add("Class", Class);
            param.Add("Custom", "%" + Custom + "%");
            param.Add("Sales", Sales);
            param.Add("AuthCode", AuthCode + "%");
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (Company != "") { strWhere += " AND e.公司別 = @Company "; }
            if (BU != "") { strWhere += " AND b.MB006 IN (" + BU + ") "; }
            if (Custom != "") { strWhere += " AND e.客戶簡稱 LIKE @Custom "; }
            if (Class != "") { strWhere += " AND b.MB008 = @Class "; }
            if (Product != "") { strWhere += " AND e.品名 IN (" + Product + ") "; }
            if (Sales != "") { strWhere += " AND e.業務員代號 = @Sales "; }
            if (AuthCode != "") { strWhere += " AND g.層級 LIKE @AuthCode "; }

            //判斷堆疊方式
            if (StockType == "ProductClass")
            {
                db.StrSQL = "SELECT ISNULL(a.MA003, '無分類') [資料名稱], SUBSTRING(日期,5,2) [月份], SUM(數量M2) [數量M2], SUM(本幣金額) [本幣金額] " +
                            "FROM RFCME e " +
                            "LEFT OUTER JOIN RFCMG g ON g.人員代號 = e.業務員代號 " +
                            "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMB b ON b.MB001=e.品號 " +
                            "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMA a ON a.MA001='4' AND a.MA002=b.MB008 " +
                            "WHERE LEFT(日期,4) = @Year " + strWhere +
                            "GROUP BY a.MA003, SUBSTRING(日期,5,2) " +
                            "ORDER BY a.MA003, SUBSTRING(日期,5,2) ";
            }
            else if (StockType == "Sales")
            {
                db.StrSQL = "SELECT e.業務員姓名 [資料名稱], SUBSTRING(日期,5,2) [月份], SUM(數量M2) [數量M2], SUM(本幣金額) [本幣金額] " +
                            "FROM RFCME e " +
                            "LEFT OUTER JOIN RFCMG g ON g.人員代號 = e.業務員代號 " +
                            "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMB b ON b.MB001=e.品號 " +
                            "WHERE LEFT(日期,4) = @Year " + strWhere +
                            "GROUP BY e.業務員姓名, SUBSTRING(日期,5,2) " +
                            "ORDER BY e.業務員姓名, SUBSTRING(日期,5,2) ";
            }
            else if (StockType == "Custom")
            {
                db.StrSQL = "SELECT e.客戶簡稱 [資料名稱], SUBSTRING(日期,5,2) [月份], SUM(數量M2) [數量M2], SUM(本幣金額) [本幣金額] " +
                            "FROM RFCME e " +
                            "LEFT OUTER JOIN RFCMG g ON g.人員代號 = e.業務員代號 " +
                            "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMB b ON b.MB001=e.品號 " +
                            "WHERE LEFT(日期,4) = @Year " + strWhere +
                            "GROUP BY e.客戶簡稱, SUBSTRING(日期,5,2) " +
                            "ORDER BY e.客戶簡稱, SUBSTRING(日期,5,2) ";
            }

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得圓餅銷售統計圖表</summary>
        public static DataTable GetSAL03(string StockType, string sYM, string eYM, string Company, string BU, string Class, string Product, string Custom, string Sales, string AuthCode)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("sYM", sYM);
            param.Add("eYM", eYM);
            param.Add("Company", Company);
            param.Add("Class", Class);
            param.Add("Custom", "%" + Custom + "%");
            param.Add("Sales", Sales);
            param.Add("AuthCode", AuthCode + "%");
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (sYM != "") { strWhere += " AND LEFT(e.日期, 6) >= @sYM "; }
            if (eYM != "") { strWhere += " AND LEFT(e.日期, 6) <= @eYM "; }
            if (Company != "") { strWhere += " AND e.公司別 = @Company "; }
            if (BU != "") { strWhere += " AND b.MB006 IN (" + BU + ") "; }
            if (Custom != "") { strWhere += " AND e.客戶簡稱 LIKE @Custom "; }
            if (Class != "") { strWhere += " AND b.MB008 = @Class "; }
            if (Product != "") { strWhere += " AND e.品名 IN (" + Product + ") "; }
            if (Sales != "") { strWhere += " AND e.業務員代號 = @Sales "; }
            if (AuthCode != "") { strWhere += " AND g.層級 LIKE @AuthCode "; }

            //判斷堆疊方式
            if (StockType == "ProductClass")
            {
                db.StrSQL = "SELECT ISNULL(a.MA003, '無分類') [資料名稱], SUM(數量M2) [數量M2], SUM(本幣金額) [本幣金額] " +
                            "FROM RFCME e " +
                            "LEFT OUTER JOIN RFCMG g ON g.人員代號 = e.業務員代號 " +
                            "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMB b ON b.MB001=e.品號 " +
                            "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMA a ON a.MA001='4' AND a.MA002=b.MB008 " +
                            "WHERE 1=1 " + strWhere +
                            "GROUP BY a.MA003 " +
                            "ORDER BY a.MA003";
            }
            else if (StockType == "Sales")
            {
                db.StrSQL = "SELECT e.業務員姓名 [資料名稱], SUM(數量M2) [數量M2], SUM(本幣金額) [本幣金額] " +
                            "FROM RFCME e " +
                            "LEFT OUTER JOIN RFCMG g ON g.人員代號 = e.業務員代號 " +
                            "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMB b ON b.MB001=e.品號 " +
                            "WHERE 1=1 " + strWhere +
                            "GROUP BY e.業務員姓名 " +
                            "ORDER BY e.業務員姓名";
            }
            else if (StockType == "Custom")
            {
                db.StrSQL = "SELECT e.客戶簡稱 [資料名稱], SUM(數量M2) [數量M2], SUM(本幣金額) [本幣金額] " +
                            "FROM RFCME e " +
                            "LEFT OUTER JOIN RFCMG g ON g.人員代號 = e.業務員代號 " +
                            "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMB b ON b.MB001=e.品號 " +
                            "WHERE 1=1 " + strWhere +
                            "GROUP BY e.客戶簡稱 " +
                            "ORDER BY e.客戶簡稱";
            }

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得每日銷售進度表</summary>
        public static DataTable GetSAL04(string YM, string Company, string BU, string Sales, string Custom, string Product, string AuthCode)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("YM", YM);
            param.Add("Company", Company);
            param.Add("Sales", Sales);
            param.Add("Custom", "%" + Custom + "%");
            param.Add("AuthCode", AuthCode + "%");
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (YM != "") { strWhere += " AND 年月 = @YM "; }
            if (Company != "") { strWhere += " AND 公司別 = @Company "; }
            if (BU != "") { strWhere += " AND 銷售分類 IN (" + BU + ") "; }
            if (Sales != "") { strWhere += " AND 業務員姓名 = @Sales "; }
            if (Custom != "") { strWhere += " AND 客戶簡稱 LIKE @Custom "; }
            if (Product != "") { strWhere += " AND 品名 IN (" + Product + ") "; }
            if (AuthCode != "") { strWhere += " AND 層級 LIKE @AuthCode "; }

            db.StrSQL = "SELECT 銷售分類, 客戶簡稱, 業務員姓名, 品名, SUM(實際銷量) [實際銷量], SUM(實際營收) [實際營收], SUM(預估銷量) [預估銷量], SUM(預估營收) [預估營收] " +
                        "FROM ( " +
                            "SELECT e.公司別, LEFT(日期,6) [年月], ISNULL(a.MA003, '其他') [銷售分類], e.客戶簡稱, e.業務員姓名, g.層級, b.MB002 [品名], e.數量M2 [實際銷量], e.本幣金額 [實際營收], 0 [預估銷量], 0 [預估營收] " +
                            "FROM RFCME e " +
                            "LEFT OUTER JOIN RFCMG g ON g.人員代號=e.業務員代號 " +
                            "LEFT OUTER JOIN {ERPDBNAME}INVMB b ON b.MB001=e.品號 " +
                            "LEFT OUTER JOIN {ERPDBNAME}INVMA a ON a.MA001='2' AND a.MA002=b.MB006 " +
                            "UNION ALL " +
                            "SELECT r.公司別, r.預測年月 [年月], ISNULL(a.MA003, '其他') [銷售分類], r.客戶簡稱, g.姓名 [業務員姓名], g.層級, RTRIM(b.MB002) [品名], 0 [實際銷量], 0 [實際營收], (r.數量 * ISNULL(d.MD004,1)) [預估銷量], (r.金額 * f.匯率) [預估營收] " +
                            "FROM RFCMA r " +
                            "LEFT OUTER JOIN RFCMG g ON g.人員代號=r.業務員代號 " +
                            "LEFT OUTER JOIN BASMA f ON f.類別='RFC' AND (f.年月=r.預測年月 OR f.年月='******') AND f.幣別=r.幣別 " +
                            "LEFT OUTER JOIN {ERPDBNAME}INVMB b ON b.MB001=r.品號 " +
                            "LEFT OUTER JOIN {ERPDBNAME}INVMD d ON d.MD001=b.MB001 AND d.MD002=r.單位 " +
                            "LEFT OUTER JOIN {ERPDBNAME}INVMA a ON a.MA001='2' AND a.MA002=b.MB006 " +
                            "WHERE r.數量 <> 0 " +
                        ") r " +
                        "WHERE 1=1" + strWhere +
                        "GROUP BY 銷售分類, 客戶簡稱, 業務員姓名, 品名";

            db.StrSQL = db.StrSQL.Replace("{ERPDBNAME}", Definition.ERPDBNAME);

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得ASP趨勢比較圖</summary>
        public static DataTable GetSAL05(string ChartType, string sYM, string eYM, string Company, string BU, string Class, string ProductName, string ProductNum, string Custom, string Sales, string IncludeNegative, string AuthCode)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("sYM", sYM);
            param.Add("eYM", eYM);
            param.Add("Company", Company);
            param.Add("Class", Class);
            param.Add("Custom", "%" + Custom + "%");
            param.Add("ProductNum", ProductNum);
            param.Add("Sales", Sales);
            param.Add("AuthCode", AuthCode + "%");
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (sYM != "") { strWhere += " AND LEFT(e.日期, 6) >= @sYM "; }
            if (eYM != "") { strWhere += " AND LEFT(e.日期, 6) <= @eYM "; }
            if (Company != "") { strWhere += " AND e.公司別 = @Company "; }
            if (BU != "") { strWhere += " AND b.MB006 IN (" + BU + ") "; }
            if (Custom != "") { strWhere += " AND e.客戶簡稱 LIKE @Custom "; }
            if (Class != "") { strWhere += " AND b.MB008 = @Class "; }
            if (ProductName != "") { strWhere += " AND e.品名 IN (" + ProductName + ") "; }
            if (ProductNum != "") { strWhere += " AND e.品號 = @ProductNum "; }
            if (Sales != "") { strWhere += " AND e.業務員代號 = @Sales "; }
            if (IncludeNegative == "N") { strWhere += " AND e.類別 = 1 "; }
            if (AuthCode != "") { strWhere += " AND g.層級 LIKE @AuthCode "; }

            //判斷堆疊方式
            if (ChartType == "ProductClass")
            {
                db.StrSQL = "SELECT ISNULL(a.MA003, '') [資料名稱], SUBSTRING(e.日期,1,6) [年月], (SUM(本幣金額) / SUM(數量M2)) [ASP] " +
                            "FROM RFCME e " +
                            "LEFT OUTER JOIN RFCMG g ON g.人員代號 = e.業務員代號 " +
                            "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMB b ON b.MB001=e.品號 " +
                            "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMA a ON a.MA001='4' AND a.MA002=b.MB008 " +
                            "WHERE 1=1 " + strWhere +
                            "GROUP BY a.MA003, SUBSTRING(e.日期,1,6) " +
                            "ORDER BY a.MA003";
            }
            else if (ChartType == "Sales")
            {
                db.StrSQL = "SELECT e.業務員姓名 [資料名稱], SUBSTRING(e.日期,1,6) [年月], (SUM(本幣金額) / SUM(數量M2)) [ASP] " +
                            "FROM RFCME e " +
                            "LEFT OUTER JOIN RFCMG g ON g.人員代號 = e.業務員代號 " +
                            "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMB b ON b.MB001=e.品號 " +
                            "WHERE 1=1 " + strWhere +
                            "GROUP BY e.業務員姓名, SUBSTRING(e.日期,1,6) " +
                            "ORDER BY e.業務員姓名";
            }
            else if (ChartType == "Custom")
            {
                db.StrSQL = "SELECT e.客戶簡稱 [資料名稱], SUBSTRING(e.日期,1,6) [年月], (SUM(本幣金額) / SUM(數量M2)) [ASP] " +
                            "FROM RFCME e " +
                            "LEFT OUTER JOIN RFCMG g ON g.人員代號 = e.業務員代號 " +
                            "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMB b ON b.MB001=e.品號 " +
                            "WHERE 1=1 " + strWhere +
                            "GROUP BY e.客戶簡稱, SUBSTRING(e.日期,1,6) " +
                            "ORDER BY e.客戶簡稱";
            }
            else if (ChartType == "Product")
            {
                db.StrSQL = "SELECT RTRIM(b.MB002) [資料名稱], SUBSTRING(e.日期,1,6) [年月], (SUM(本幣金額) / SUM(數量M2)) [ASP] " +
                            "FROM RFCME e " +
                            "LEFT OUTER JOIN RFCMG g ON g.人員代號 = e.業務員代號 " +
                            "LEFT OUTER JOIN " + Definition.ERPDBNAME + "INVMB b ON b.MB001=e.品號 " +
                            "WHERE 1=1 " + strWhere +
                            "GROUP BY RTRIM(b.MB002), SUBSTRING(e.日期,1,6) " +
                            "ORDER BY RTRIM(b.MB002)";
            }

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        public static DataTable GetAvgSaleData(string Company, string Custom, string ProductNum, string Currency, string YM)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            DateTime date;
            UHR.Util.Tool.ParseDateTime(YM + "01", out date);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Company", Company);
            param.Add("Custom", Custom);
            param.Add("Currency", Currency);
            param.Add("Product", ProductNum);
            param.Add("StartDate", date.AddMonths(-3).ToString("yyyyMMdd"));
            param.Add("EndDate", date.AddDays(-1).ToString("yyyyMMdd"));
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (Company != "") { strWhere += " AND 公司別 = @Company "; }
            if (Custom != "") { strWhere += " AND 客戶簡稱 = @Custom "; }
            if (ProductNum != "") { strWhere += " AND 品號 = @Product "; }
            if (Currency != "") { strWhere += " AND 幣別 = @Currency "; }

            db.StrSQL = "SELECT LEFT(日期, 6) [年月], AVG(單價) [單價], SUM(數量) [數量] " +
                        "FROM RFCME " +
                        "WHERE (日期 BETWEEN @StartDate AND @EndDate) AND 類別=1" + strWhere +
                        "GROUP BY LEFT(日期, 6) ";

            DataTable dt = db.ExecuteDataTable();
            return dt;
        }
    }
}