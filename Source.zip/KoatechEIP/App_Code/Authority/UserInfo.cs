﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web;

namespace UHR.Authority
{
    public class UserInfo
    {
        //私有變數
        private int _id = 0;
        private string _email = "";
        private string _account = "";
        private string _password = "";
        private string _type = "";
        private string _firstname = "";
        private string _lastname = "";
        private string _dep = "";
        private bool _issuper = false;
        private List<MenuAuthority> _mal = null;

        public UserInfo(DataRow _row)
        {
            _id = Convert.ToInt32(_row["ID"]);
            _email = Convert.ToString(_row["Email"]);
            _account = Convert.ToString(_row["Account"]);
            _password = Convert.ToString(_row["Password"]);
            _type = Convert.ToString(_row["Type"]);
            _firstname = Convert.ToString(_row["FirstName"]);
            _lastname = Convert.ToString(_row["LastName"]);
            _dep = Convert.ToString(_row["Dep"]);
            _issuper = (_row["IsSuper"].ToString() == "1");

            //取得選單權限
            _mal = new List<MenuAuthority>();
            DataTable dtAuth = BLL.GetUserAuthority(_account, "", "", "", true);
            foreach (DataRow row in dtAuth.Rows)
            {
                _mal.Add(new MenuAuthority(row));
            }
        }

        //屬性
        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }
        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }
        public string Account
        {
            get { return _account; }
            set { _account = value; }
        }
        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }
        public string Type
        {
            get { return _type; }
            set { _type = value; }
        }
        public string FirstName
        {
            get { return _firstname; }
            set { _firstname = value; }
        }
        public string LastName
        {
            get { return _lastname; }
            set { _lastname = value; }
        }
        public string Dep
        {
            get { return _dep; }
            set { _dep = value; }
        }
        public bool IsSuper
        {
            get { return _issuper; }
            set { _issuper = value; }
        }
        public List<MenuAuthority> MenuAuthorityList
        {
            get { return _mal; }
        }

        //公有函式
        public static UserInfo SessionState
        {
            get { return (UserInfo)HttpContext.Current.Session["UserInfo"]; }
            set { HttpContext.Current.Session.Add("UserInfo", value); }
        }
        public static bool Exists
        {
            get { return (HttpContext.Current.Session["UserInfo"] != null); }
        }
        public static void Remove()
        {
            if (Exists)
            {
                HttpContext.Current.Session.Remove("UserInfo");
            }
        }
    }
}