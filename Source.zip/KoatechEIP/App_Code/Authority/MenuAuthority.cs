﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UHR.Authority
{
    public class MenuAuthority
    {
        public string MenuNo = "";
        public bool Add = true;
        public bool Edit = true;
        public bool Del = true;
        public bool Query = true;
        public bool Audit = true;
        public bool Print = true;
        public bool Export = true;
        public bool Import = true;
        public bool Flow = false;
        public bool Admin = true;

        public MenuAuthority() { }

        public MenuAuthority(DataRow _row)
        {
            MenuNo = Convert.ToString(_row["MenuNo"]);
            Add = Convert.ToString(_row["Add"]) == "Y";
            Edit = Convert.ToString(_row["Edit"]) == "Y";
            Del = Convert.ToString(_row["Del"]) == "Y";
            Query = Convert.ToString(_row["Query"]) == "Y";
            Audit = Convert.ToString(_row["Audit"]) == "Y";
            Print = Convert.ToString(_row["Print"]) == "Y";
            Export = Convert.ToString(_row["Export"]) == "Y";
            Import = Convert.ToString(_row["Import"]) == "Y";
            Flow = Convert.ToString(_row["Flow"]) == "Y";
            Admin = Convert.ToString(_row["Admin"]) == "Y";
        }
    }
}