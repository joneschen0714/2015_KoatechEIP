﻿using System;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;
using UHR.Util;

public class PortalIM : Hub, IDisposable
{
    //初始化線上人員物件
    public static OnlineUserList onlineUserList = new OnlineUserList();
    public static List<RoomUser> roomUserList = new List<RoomUser>();

    //發送訊息
    public void SendMessage(string _type, string _targetID, string _msg, string _myID)
    {
        var time = DateTime.Now.ToString("HH:mm");
        var my = onlineUserList[_myID];
        string Msg = string.Format("<div><span class='triangle-left'>{0}</span><span class='time'>{1}</span></div>", _msg, time);

        if (_type == "Person")
        {
            Clients.Client(onlineUserList[_targetID].ConnectionID).GetMessage(_myID, Msg);
        }
    }

    //登錄事件
    public void Connected(string _id, string _name)
    {
        //SignalR連線ID
        var connID = Context.ConnectionId;

        //檢查是否有帶入ID
        if (string.IsNullOrEmpty(_id))
        {
            Clients.Caller.LoginError("1");
            return;
        }

        //檢查是否已有重覆使用者
        if (onlineUserList[_id] == null)
        {
            var now = DateTime.Now.ToString("HH:mm"); //登錄時間

            //加入線上人員名單
            onlineUserList.Add(connID, _id, _name, now);

            //取得線上人員名單N
            var json = JsonConvert.SerializeObject(onlineUserList);
            Clients.Caller.GetOnlineUserList(connID, json);

            //所有人增加此人員名單
            Clients.Others.AddOnlineUser(connID, _id, _name, now);
        }
        else
        {
            Clients.Caller.LoginError("2");
        }
    }

    //斷線事件
    public override System.Threading.Tasks.Task OnDisconnected()
    {
        //取得使用者資訊
        var user = onlineUserList.Find(x => x.ConnectionID == Context.ConnectionId);
        var name = user.Name;
        var id = user.ID;

        //移除線上人員
        onlineUserList.Remove(Context.ConnectionId);

        //呼叫Client移除特定使用者
        Clients.All.RemoveOnlineUser(id, name, DateTime.Now.ToString("HH:mm"));

        return base.OnDisconnected();
    }

    //重新連線事件
    public override System.Threading.Tasks.Task OnReconnected()
    {
        return base.OnReconnected();
    }
}

/// <summary>使用者資訊集合</summary>
public class OnlineUserList : List<OnlineUser>
{
    //取得使用者資訊
    public OnlineUser this[string ID]
    {
        get { return this.Find(x => x.ID == ID); }
    }

    //函式-新增使用者
    public void Add(string _connID, string _id, string _name, string _time)
    {
        OnlineUser user = new OnlineUser();
        user.ConnectionID = _connID;
        user.ID = _id;
        user.Name = _name;
        user.LoginTime = _time;

        base.Add(user);
    }

    //函式-移除使用者
    public void Remove(string _connID)
    {
        OnlineUser user = base.Find(x => x.ConnectionID == _connID);
        base.Remove(user);
    }
}

/// <summary>使用者資訊</summary>
public class OnlineUser
{
    public string ConnectionID;
    public string ID;
    public string Name;
    public string LoginTime;
}

public class RoomUser
{
    public string Room;
    public string ConnectionID;

    public RoomUser(string _room, string _connID)
    {
        Room = _room;
        ConnectionID = _connID;
    }
}