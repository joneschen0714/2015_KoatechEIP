using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Data.SqlClient;
using UHR.Authority;
using UHR.Util;
using Newtonsoft.Json;

namespace UHR.BasePage
{
    public class BasePage : System.Web.UI.Page
    {
        public string MENU_NO = "";
        public MenuAuthority PageAuthority = null;

        public BasePage()
        {

        }

        protected override void OnPreInit(EventArgs e)
        {
            if (!IsPostBack)
            {
                CheckUserLogin();

                SetPageAuthority();

                if (BasePage.CheckUserAuthority(MENU_NO))
                {
                    Definition.SelectMenuNo = MENU_NO;
                }
                else
                {
                    Response.Redirect("~/Error.aspx");
                }
            }
            else
            {
                SetPageAuthority();
            }
        }

        //����ϥΪ̬O�_�n�J
        protected void CheckUserLogin()
        {
            if (!UserInfo.Exists)
            {
                //�O���n�J��n��V�����}
                Definition.RedirectURL = Request.Url.ToString();

                //�ɦV�n�J��
                Response.Redirect("~/Login.aspx");
            }
        }

        //�]�w�����ӳ��v��
        private void SetPageAuthority()
        {
            UserInfo fi = UserInfo.SessionState;

            //�Y�����޲z�̡A�h�]�w�n�J�̥����������v��
            if (fi.IsSuper)
            {
                PageAuthority = new MenuAuthority();
            }
            else
            {
                PageAuthority = fi.MenuAuthorityList.Find(delegate(MenuAuthority ma) { return ma.MenuNo == MENU_NO; });
            }
        }

        //�ˬd�v��
        public static bool CheckUserAuthority(string PopCode)
        {
            bool flag = false;
            Authority.UserInfo ui = Authority.UserInfo.SessionState;

            if (ui.IsSuper)
            {
                flag = true;
            }
            else
            {
                //���o�������
                DataRow row = Definition.MainMenu.Rows.Find(PopCode);
                if (row != null)
                {
                    //�P�_�����O�_�����}
                    bool bPublic = Convert.ToBoolean(row["isPublic"]);
                    if (bPublic)
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = ui.MenuAuthorityList.Exists(delegate(MenuAuthority ma) { return ma.MenuNo == PopCode; });
                    }
                }
            }

            return flag;
        }

        public static string GetMessage(string type, string text)
        {
            string result = "", css = "", title = "";

            switch (type)
            {
                case "error":
                    title = "Error!";
                    css = " alert-danger";
                    break;
                case "warning":
                    title = "Warning!";
                    css = " alert-warning";
                    break;
                case "success":
                    title = "Success!";
                    css = " alert-success";
                    break;
                case "info":
                    title = "Info!";
                    css = " alert-info";
                    break;
            }

            result = "<div class='alert" + css + "'>" +
                        "<button type='button' class='close' data-dismiss='alert'><i class='ace-icon fa fa-times'></i></button>" +
                        "<strong>" + title + "</strong> " + text +
                     "</div>";

            return result;
        }

        //�۰ʶ�Ȧܱ��
        public void FillControlData(Control ctrlContainer, DataRow row)
        {
            foreach (Control ctrl in ctrlContainer.Controls)
            {
                string strID = ctrl.ID;
                if (strID != null)
                {
                    string tag = ctrl.ID.Substring(0, 5);
                    if (tag == "data_")
                    {
                        string strCtrl = ctrl.ID.Substring(5, 3);
                        string strFieldName = ctrl.ID.Substring(9);
                        switch (strCtrl)
                        {
                            case "lbl":
                                Label lblCtrl = (Label)ctrl;
                                lblCtrl.Text = Convert.ToString(row[strFieldName]);
                                break;
                            case "txt":
                                TextBox txtCtrl = (TextBox)ctrl;
                                txtCtrl.Text = Convert.ToString(row[strFieldName]);
                                break;
                            case "ddl":
                                DropDownList ddlCtrl = (DropDownList)ctrl;
                                ddlCtrl.SelectedValue = Convert.ToString(row[strFieldName]).Trim();
                                break;
                        }
                    }
                }
            }
        }

        //����Ȧ^�sDataTable
        public void UpdateContentData(Control ctrlContainer, DataRow row)
        {
            foreach (Control ctrl in ctrlContainer.Controls)
            {
                string strID = ctrl.ID;
                if (strID != null)
                {
                    string tag = ctrl.ID.Substring(0, 5);
                    if (tag == "data_")
                    {
                        string strCtrl = ctrl.ID.Substring(5, 3);
                        string strFieldName = ctrl.ID.Substring(9);
                        switch (strCtrl)
                        {
                            case "lbl":
                                Label lblCtrl = (Label)ctrl;
                                row[strFieldName] = lblCtrl.Text.Trim();
                                break;
                            case "txt":
                                TextBox txtCtrl = (TextBox)ctrl;
                                row[strFieldName] = txtCtrl.Text.Trim();
                                break;
                            case "ddl":
                                DropDownList ddlCtrl = (DropDownList)ctrl;
                                row[strFieldName] = ddlCtrl.SelectedValue;
                                break;
                        }
                    }
                }
            }
        }

        //���ͭ���Token
        public string CreateToken()
        {
            string tokenKey = this.Session.SessionID + DateTime.Now.Ticks.ToString();
            System.Security.Cryptography.MD5CryptoServiceProvider md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
            byte[] b = md5.ComputeHash(System.Text.Encoding.UTF8.GetBytes(tokenKey));
            Definition.PageToken = BitConverter.ToString(b).Replace("-", string.Empty);
            return Definition.PageToken;
        }

        //�������Token
        public bool VeriftyToken(string clientToken)
        {
            if (string.IsNullOrEmpty(clientToken)) return false;

            string serverToken = Definition.PageToken;
            if (clientToken.Equals(serverToken))
                return true;
            else
                return false;
        }
    }
}