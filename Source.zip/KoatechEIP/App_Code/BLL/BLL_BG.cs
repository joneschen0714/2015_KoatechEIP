﻿using System;
using System.Data;
using UHR.Util;

namespace UHR
{
    public class BLL_BG
    {
        public BLL_BG()
        {

        }

        /// <summary>寫入費用性預算(管理者用)</summary>
        public static bool SetBudgetDataForAdmin(DataTable dt, ref string msg)
        {
            //去除所有值的前後空白
            UHR.Util.Tool.TrimAllValue(dt);

            #region 刪除虛擬科目
            foreach (DataRow row in dt.Select("科目代碼 = ''"))
            {
                row.Delete();
            }
            dt.AcceptChanges();
            #endregion

            //取出唯一值
            dt.DefaultView.RowFilter = "";
            DataTable dtVersion = dt.DefaultView.ToTable(true, "版本");
            DataTable dtAcct = dt.DefaultView.ToTable(true, "科目代碼");
            DataTable dtDept = dt.DefaultView.ToTable(true, "部門代碼");

            #region 檢查預算部門
            foreach (DataRow row in dtDept.Rows)
            {
                string strDept = Convert.ToString(row["部門代碼"]);
                if (strDept != "")
                {
                    DataTable dtResult = BLL_ERP.GetCMSME(strDept);

                    if (dtResult.Rows.Count == 0)
                        msg += string.Format("<br/> 無{0}的預算部門，請確認!", strDept);
                }
                else
                {
                    msg += string.Format("<br/> 部門代碼不可空白!");
                }
            }
            #endregion

            #region 檢查預算版本
            if (dtVersion.Rows.Count == 1)
            {
                string strVersion = dtVersion.Rows[0]["版本"].ToString();
                int iLock = BLL_BG.GetBudgetVersion(strVersion, "").Rows.Count;
                if (iLock == 0)
                {
                    msg = string.Format("預算版本 {0} 不存在!", strVersion);
                    return false;
                }
            }
            else
            {
                msg = string.Format("預算版本可能多於1個!");
                return false;
            }
            #endregion

            #region 檢查會計科目
            foreach (DataRow row in dtAcct.Rows)
            {
                //檢查科目代碼
                string strAcctCode = row["科目代碼"].ToString();
                DataTable dtAcctCode = BLL_ERP.GetACTMA("", strAcctCode, "");
                if (dtAcctCode.Rows.Count == 0)
                {
                    msg += "<br/>科目代碼 " + strAcctCode + "不存在!";
                }
                else
                {
                    //檢查科目類別
                    int iAcctType = Convert.ToInt32(dtAcctCode.Rows[0]["MA008"]);
                    if (iAcctType == 1 || iAcctType == 4)
                    {
                        msg += "<br/>科目代碼 " + strAcctCode + "為統制或分類帳戶!";
                    }
                }
            }
            #endregion

            if (msg == "")
            {
                return DAL_BG.SetBudgetDataForAdmin(dt, ref msg);
            }
            else
            {
                return false;
            }
        }

        /// <summary>寫入費用性預算</summary>
        public static bool SetBudgetData(DataTable dt, ref string msg)
        {
            //去除所有值的前後空白
            UHR.Util.Tool.TrimAllValue(dt);

            #region 刪除虛擬科目
            foreach (DataRow row in dt.Select("科目代碼 = ''"))
            {
                row.Delete();
            }
            dt.AcceptChanges();
            #endregion

            //檢查唯一值
            dt.DefaultView.RowFilter = "";
            DataTable dtCheck = dt.DefaultView.ToTable(true, "版本", "部門代碼", "年度");
            if (dtCheck.Rows.Count == 1)
            {
                //變數
                DataRow rowCheck = dtCheck.Rows[0];
                string strVersion = rowCheck["版本"].ToString();
                string strDept = rowCheck["部門代碼"].ToString();

                #region 檢查預算部門
                if (strDept != "")
                {
                    DataTable dtResult = BLL_ERP.GetCMSME(strDept);

                    if (dtResult.Rows.Count == 0)
                        msg += string.Format("<br/> 無{0}的預算部門，請確認!", strDept);
                }
                else
                {
                    msg += string.Format("<br/> 部門代碼不可空白!");
                }
                #endregion

                #region 檢查版本鎖定碼
                int iLock = BLL_BG.GetBudgetVersion(strVersion, "N").Rows.Count;
                if (iLock == 0)
                {
                    msg = string.Format("預算版本 {0} 不存在或已被鎖定，不可修改!", strVersion);
                    return false;
                }
                #endregion

                #region 檢查確認碼
                int iCheck = BLL_BG.GetVersionList(strVersion, strDept, "Y").Rows.Count;
                if (iCheck > 0)
                {
                    msg = string.Format("部門代碼：{0},{1} 的版本已確認，不可修改!", strDept, strVersion);
                    return false;
                }
                #endregion

                #region 逐筆檢查細項
                foreach (DataRow row in dt.Rows)
                {
                    //檢查科目代碼
                    string strAcctCode = row["科目代碼"].ToString();
                    DataTable dtAcctCode = BLL_ERP.GetACTMA("", strAcctCode, "");
                    if (dtAcctCode.Rows.Count == 0)
                    {
                        msg += "<br/>科目代碼 " + strAcctCode + "不存在!";
                    }
                    else
                    {
                        //檢查科目類別
                        int iAcctType = Convert.ToInt32(dtAcctCode.Rows[0]["MA008"]);
                        if (iAcctType == 1 || iAcctType == 4)
                        {
                            msg += "<br/>科目代碼 " + strAcctCode + "為統制或分類帳戶!";
                        }
                    }
                }
                #endregion
            }
            else if (dtCheck.Rows.Count != 1)
            {
                msg = "版本、部門代碼或年度可能多於一個，請檢查資料正確性!";
            }

            if (msg == "")
            {
                return DAL_BG.SetBudgetData(dt, ref msg);
            }
            else
            {
                return false;
            }
        }

        /// <summary>取得費用性預算</summary>
        public static DataTable GetBudgetData(string 版本, string 預算部門, string 會計科目, string 年度, string 起始月份, string 結束月份, string 確認碼, string 部門權限)
        {
            if (部門權限 != "")
            {
                //加上陣列前後指定字元
                部門權限 = Tool.SetSplitSingleMark(部門權限, "'", ',');
            }

            return DAL_BG.GetBudgetData(版本, 預算部門, 會計科目, 年度, 起始月份, 結束月份, 確認碼, 部門權限);
        }

        /// <summary>預算上傳ERP</summary>
        public static bool SendToERP(string 站別, string 版本, ref string msg)
        {
            //判斷是否有未確認的資料
            DataTable dt = GetBudgetData(版本, "", "", "", "", "", "N", "");
            DataTable dtSales = GetSaleBudgetData("", 版本, "", "", "", "", "", "N");

            if (dt.Rows.Count == 0 && dtSales.Rows.Count == 0)
            {
                return DAL_BG.SendToERP(站別, 版本, ref msg);
            }
            else
            {
                msg = "版本：" + 版本 + "有未確認的資料!";
                return false;
            }
        }

        /// <summary>更新版本的確認碼</summary>
        public static bool SetVersionStatus(string 版本, string 部門代碼, string 確認碼, ref string msg)
        {
            if (部門代碼 != "")
            {
                return DAL_BG.SetVersionStatus(版本, 部門代碼, 確認碼, ref msg);
            }
            else
            {
                msg = "無預算部門!";
                return false;
            }
        }

        /// <summary>取得版本清單</summary>
        public static DataTable GetVersionList(string 版本, string 部門代碼, string 確認碼)
        {
            return DAL_BG.GetVersionList(版本, 部門代碼, 確認碼);
        }

        /// <summary>複製預算版本</summary>
        public static bool CopyVersion(string 原版本, string 新版本, ref string msg)
        {
            if (新版本.Length != 6)
            {
                msg = "版本必須為6碼英數字!";
                return false;
            }

            if (原版本 == 新版本)
            {
                msg = "新舊版本不可一樣!";
                return false;
            }

            return DAL_BG.CopyVersion(原版本, 新版本, ref msg);
        }

        /// <summary>寫入營收預算資料</summary>
        public static bool SetSaleBudgetData(DataTable dt, ref string msg)
        {
            //去除所有值的前後空白
            UHR.Util.Tool.TrimAllValue(dt);

            if (dt.Rows.Count > 0)
            {
                DataTable dtCompany = dt.DefaultView.ToTable(true, "公司別");
                DataTable dtVersion = dt.DefaultView.ToTable(true, "預算版本");
                DataTable dtDept = dt.DefaultView.ToTable(true, "預算部門");
                DataTable dtYM = dt.DefaultView.ToTable(true, "年月");
                DataTable dtSales = dt.DefaultView.ToTable(true, "業務員代號");
                DataTable dtCurrency = dt.DefaultView.ToTable(true, "幣別");
                DataTable dtProduct = dt.DefaultView.ToTable(true, "品號", "單位");
                DataTable dtType = dt.DefaultView.ToTable(true, "銷貨類別");

                #region 檢查預算版本鎖定碼
                if (dtVersion.Rows.Count == 1)
                {
                    string strVersion = dtVersion.Rows[0]["預算版本"].ToString().Trim();
                    if (strVersion != "")
                    {
                        int iLock = BLL_BG.GetBudgetVersion(strVersion, "N").Rows.Count;
                        if (iLock == 0)
                        {
                            msg += string.Format("預算版本 {0} 不存在或已被鎖定，不可修改!", strVersion);
                            return false;
                        }
                    }
                    else
                    {
                        msg += string.Format("預算版本不可空白!");
                        return false;
                    }
                }
                else
                {
                    msg += string.Format("預算版本只能指定一版!");
                    return false;
                }
                #endregion

                #region 檢查公司別
                foreach (DataRow row in dtCompany.Rows)
                {
                    string strCompany = Convert.ToString(row["公司別"]).Trim();
                    if (strCompany != "")
                    {
                        DataTable dtResult = BLL.GetSystemConfig("Company", strCompany);

                        if (dtResult.Rows.Count == 0)
                            msg += string.Format("<br/> 無{0}的公司別，請確認!", strCompany);
                    }
                    else
                    {
                        msg += string.Format("<br/> 公司別不可空白!", strCompany);
                    }
                }
                #endregion

                #region 檢查預算部門
                foreach (DataRow row in dtDept.Rows)
                {
                    string strDept = Convert.ToString(row["預算部門"]).Trim();
                    if (strDept != "")
                    {
                        DataTable dtResult = BLL_ERP.GetCMSME(strDept);

                        if (dtResult.Rows.Count == 0)
                            msg += string.Format("<br/> 無{0}的預算部門，請確認!", strDept);
                    }
                    else
                    {
                        msg += string.Format("<br/> 預算部門不可空白!");
                    }
                }
                #endregion

                #region 檢查業務員代號
                if (dtSales.Rows.Count == 1)
                {
                    DataRow row = dtSales.Rows[0];
                    string strSales = Convert.ToString(row["業務員代號"]);
                    DataTable dtResult = DAL_RF.GetRF_Group(strSales, "", "");

                    if (dtResult.Rows.Count == 0)
                    {
                        msg += string.Format("<br/> 業務員代號錯誤!");
                    }
                }
                else
                {
                    msg += string.Format("<br/> 業務員代號不可多於一個!");
                }
                #endregion

                #region 檢查預算年月
                foreach (DataRow row in dtYM.Rows)
                {
                    string strYM = Convert.ToString(row["年月"]).Trim();

                    DateTime dResult;
                    bool bResult = UHR.Util.Tool.ParseDateTime(strYM + "01", out dResult);
                    if (!bResult)
                    {
                        msg += string.Format("<br/> 預算年月格式錯誤!");
                    }
                }
                #endregion

                #region 檢查幣別
                foreach (DataRow row in dtCurrency.Rows)
                {
                    string strCurrency = Convert.ToString(row["幣別"]).Trim();

                    DataTable dtResult = BLL_ERP.GetCMSMF(strCurrency);
                    if (dtResult.Rows.Count == 0)
                    {
                        msg += string.Format("<br/> 無{0}的幣別資料!", strCurrency);
                    }
                }
                #endregion

                #region 檢查品號是否存在ERP
                foreach (DataRow row in dtProduct.Rows)
                {
                    string strProduct = Convert.ToString(row["品號"]);
                    string strUnit = Convert.ToString(row["單位"]);

                    if (strProduct != "" && strUnit != "")
                    {
                        DataTable dtUnit = BLL_ERP.GetINVMD(strProduct, strUnit);

                        if (dtUnit.Rows.Count == 0)
                        {
                            msg += string.Format("<br/> 品號{0}或單位{1}可能不存在ERP!", row["品號"], row["單位"]);
                        }
                    }
                    else
                    {
                        msg += string.Format("<br/> 品號或單位不可空白!");
                    }
                }
                #endregion

                #region 檢查銷貨類別
                foreach (DataRow row in dtType.Rows)
                {
                    string strType = Convert.ToString(row["銷貨類別"]).Trim();
                    switch (strType)
                    {
                        case "內銷":
                        case "外銷":
                        case "加工":
                            break;
                        default:
                            msg += string.Format("<br/> 無{0}的銷貨類別!", strType);
                            break;
                    }
                }
                #endregion

                #region 逐筆檢查數量及單價
                int index = 2;
                foreach (DataRow row in dt.Rows)
                {
                    decimal dd, ii;

                    bool b1 = decimal.TryParse(row["單價"].ToString(), out dd);
                    bool b2 = decimal.TryParse(row["數量"].ToString(), out ii);

                    if (b1 == false || b2 == false)
                    {
                        msg += string.Format("<br/> 第{0}個資料列的單價或數量格式錯誤!", index);
                    }

                    index++;
                }
                #endregion

                #region 檢查狀態碼
                if (msg == "")
                {
                    DataRow row = dt.Rows[0];
                    string version = Convert.ToString(row["預算版本"]).Trim();
                    string sales = Convert.ToString(row["業務員代號"]).Trim();

                    //取得現有預算資料
                    DataTable dtBudget = BLL_BG.GetSaleBudgetData("", version, "", sales, "", "", "", "Y");
                    if (dtBudget.Rows.Count > 0)
                    {
                        msg = "資料已確認，不可修改!";
                    }
                }
                #endregion
            }
            else
            {
                msg += "<br/> 無資料，請確認!";
            }

            if (msg == "")
            {
                return DAL_BG.SetSaleBudgetData(dt, ref msg);
            }
            else
            {
                return false;
            }
        }

        /// <summary>取得營收預算資料</summary>
        public static DataTable GetSaleBudgetData(string 公司別, string 預算版本, string 預算部門, string 業務員代號, string 預算年月, string 品名, string 業務員清單, string 狀態碼)
        {
            業務員清單 = 業務員清單.Trim(',');
            業務員清單 = UHR.Util.Tool.SetSplitSingleMark(業務員清單, "'", ',');

            return DAL_BG.GetSaleBudgetData(公司別, 預算版本, 預算部門, 業務員代號, 預算年月, 品名, 業務員清單, 狀態碼);
        }

        /// <summary>更新營收預算的狀態碼</summary>
        public static bool SetSaleBudgetStatus(string 業務員代號, string 預算版本, string 狀態碼)
        {
            return DAL_BG.SetSaleBudgetStatus(業務員代號, 預算版本, 狀態碼);
        }

        /// <summary>取得預算版本清單</summary>
        public static DataTable GetBudgetVersion(string 預算版本, string 鎖定碼)
        {
            return DAL_BG.GetBudgetVersion(預算版本, 鎖定碼);
        }

        /// <summary>更改預算版本的鎖定碼</summary>
        public static bool SetBudgetVersionLock(string 預算版本, string 鎖定碼)
        {
            return DAL_BG.SetBudgetVersionLock(預算版本, 鎖定碼);
        }

        /// <summary>取得人員的預算部門清單</summary>
        public static string GetAcctDept(string 人員代號)
        {
            return DAL_BG.GetAcctDept(人員代號);
        }

        /// <summary>單筆更新預算的數字</summary>
        public static bool UpdateBudgetValue(string 預算版本, string 預算部門, string 科目代碼, string 月份, string 金額)
        {
            return DAL_BG.UpdateBudgetValue(預算版本, 預算部門, 科目代碼, 月份, 金額);
        }
    }
}