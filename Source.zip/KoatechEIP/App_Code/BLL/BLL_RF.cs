﻿using System;
using System.Data;
using System.Linq;
using System.Collections.Generic;
using UHR.Util;

namespace UHR
{
    public class BLL_RF
    {
        public BLL_RF()
        {

        }

        /// <summary>取得銷售預測資料</summary>
        public static DataTable GetForecastData(string ID, string 公司別, string 預測年月, string 銷售分類, string 業務員代號, string 客戶簡稱, string 品名, string 業務人員清單)
        {
            業務人員清單 = 業務人員清單.Trim(',');
            業務人員清單 = UHR.Util.Tool.SetSplitSingleMark(業務人員清單, "'", ',');

            return DAL_RF.GetForecastData(ID, 公司別, 預測年月, 銷售分類, 業務員代號, 客戶簡稱, 品名, 業務人員清單);
        }

        /// <summary>取得銷售預測版本資料</summary>
        public static DataTable GetForecastHistoryData(string 公司別, string 預測年月, string 銷售分類, string 業務員代號, string 客戶簡稱, string 品名, string 版本, string 業務人員清單)
        {
            業務人員清單 = 業務人員清單.Trim(',');
            業務人員清單 = UHR.Util.Tool.SetSplitSingleMark(業務人員清單, "'", ',');

            return DAL_RF.GetForecastHistoryData(公司別, 預測年月, 銷售分類, 業務員代號, 客戶簡稱, 品名, 版本, 業務人員清單);
        }

        /// <summary>寫入銷售預測資料</summary>
        public static bool SetForecastData(DataTable dt, ref string msg)
        {
            //去除所有值的前後空白
            UHR.Util.Tool.TrimAllValue(dt);

            if (dt.Rows.Count > 0)
            {
                DataTable dtCompany = dt.DefaultView.ToTable(true, "公司別");
                DataTable dtYM = dt.DefaultView.ToTable(true, "預測年月");
                DataTable dtSales = dt.DefaultView.ToTable(true, "業務員代號");
                DataTable dtCurrency = dt.DefaultView.ToTable(true, "幣別");
                DataTable dtProduct = dt.DefaultView.ToTable(true, "品號");

                #region 檢查公司別
                foreach (DataRow row in dtCompany.Rows)
                {
                    string strCompany = Convert.ToString(row["公司別"]).Trim();
                    if (strCompany != "")
                    {
                        DataTable dtResult = BLL.GetSystemConfig("Company", strCompany);

                        if (dtResult.Rows.Count == 0)
                            msg += string.Format("<br/> 無{0}的公司別，請確認!", strCompany);
                    }
                    else
                    {
                        msg += string.Format("<br/> 公司別不可空白!", strCompany);
                    }
                }
                #endregion

                #region 檢查業務員代號
                if (dtSales.Rows.Count == 1)
                {
                    DataRow row = dtSales.Rows[0];
                    string strSales = Convert.ToString(row["業務員代號"]);
                    DataTable dtResult = DAL_RF.GetRF_Group(strSales, "", "");

                    if (dtResult.Rows.Count == 0)
                    {
                        msg += string.Format("<br/> 業務員代號錯誤!");
                    }
                }
                else
                {
                    msg += string.Format("<br/> 業務員代號不可多於一個!");
                }
                #endregion

                #region 檢查預測年月
                if (dtYM.Rows.Count == 1)
                {
                    DataRow row = dtYM.Rows[0];
                    string strYM = Convert.ToString(row["預測年月"]).Trim();

                    DateTime dResult;
                    bool bResult = UHR.Util.Tool.ParseDateTime(strYM + "01", out dResult);
                    if (!bResult)
                    {
                        msg += string.Format("<br/> 預測年月格式錯誤!");
                    }
                    //else
                    //{
                    //    int 匯入月 = int.Parse(strYM);
                    //    int 本月 = int.Parse(DateTime.Now.ToString("yyyyMM"));
                    //    if (本月 > 匯入月)
                    //    {
                    //        msg += string.Format("<br/> 不可修改過去資料!");
                    //    }
                    //}
                }
                else
                {
                    msg += string.Format("<br/> 預測年月不可多於一期!");
                }
                #endregion

                #region 檢查幣別
                foreach (DataRow row in dtCurrency.Rows)
                {
                    string strCurrency = Convert.ToString(row["幣別"]).Trim();

                    DataTable dtResult = BLL_ERP.GetCMSMF(strCurrency);
                    if (dtResult.Rows.Count == 0)
                    {
                        msg += string.Format("<br/> 無{0}的幣別資料!", strCurrency);
                    }
                }
                #endregion

                #region 檢查品號是否存在ERP
                foreach (DataRow row in dtProduct.Rows)
                {
                    string strProduct = Convert.ToString(row["品號"]).Trim();
                    if (strProduct != "")
                    {
                        DataTable dtProductList = BLL_ERP.GetINVMB(strProduct);
                        if (dtProductList.Rows.Count == 0)
                        {
                            msg += string.Format("<br/> {0} 的品號不存在ERP!", row["品號"]);
                        }
                        else
                        {
                            DataRow pRow = dtProductList.Rows[0];
                            string 銷售單位 = Convert.ToString(pRow["MB156"]).Trim();

                            if (銷售單位 == "")
                            {
                                msg += string.Format("<br/> {0} 的品號的銷售單位不可為空值!", row["品號"]);
                            }
                        }
                    }
                    else
                    {
                        msg += string.Format("<br/> 品號不可空白!");
                    }
                }
                #endregion

                #region 逐筆檢查數量及單價
                int index = 2;
                foreach (DataRow row in dt.Rows)
                {
                    decimal dd;
                    int ii;

                    string strUnitPrice = Convert.ToString(row["單價"]).Trim();
                    string strQty = Convert.ToString(row["數量"]).Trim();

                    bool b1 = decimal.TryParse(strUnitPrice, out dd);
                    bool b2 = false;
                    if (strQty == "")
                    {
                        b2 = true;
                        row["數量"] = 0;
                    }
                    else { b2 = int.TryParse(strQty, out ii); }

                    if (b1 == false || b2 == false)
                    {
                        msg += string.Format("<br/> 第{0}個資料列的單價或數量格式錯誤!", index);
                    }

                    index++;
                }
                #endregion

                #region 檢查客戶是否有重覆的品號
                //var r = from i in dt.AsEnumerable()
                //        group i by new { 客戶簡稱 = i["客戶簡稱"], 品號 = i["品號"] } into g
                //        select new { Key = g.Key, Count = g.Count() };

                //foreach (var item in r.Where(x => x.Count > 1))
                //{
                //    msg += string.Format("<br/> 客戶簡稱:{0} 有重覆的品號{1}!", item.Key.客戶簡稱, item.Key.品號);
                //}
                #endregion

                #region 檢查狀態碼
                if (msg == "")
                {
                    string strYM = Convert.ToString(dtYM.Rows[0]["預測年月"]).Trim();
                    string strSales = Convert.ToString(dtSales.Rows[0]["業務員代號"]).Trim();

                    DataTable dtResult = DAL_RF.GetForecastData("", "", strYM, "", strSales, "", "", "");
                    if (dtResult.Rows.Count > 0)
                    {
                        string strStatus = dtResult.Rows[0]["狀態碼"].ToString();
                        switch (strStatus)
                        {
                            case "Y":
                                msg = "資料已審核，不可修改!";
                                break;
                            case "S":
                                msg = "資料正在審核中，不可修改!";
                                break;
                        }
                    }
                }
                #endregion

            }
            else
            {
                msg += "<br/> 無資料，請確認!";
            }


            if (msg == "")
            {
                return DAL_RF.SetForecastData(dt, ref msg);
            }
            else
            {
                return false;
            }
        }

        /// <summary>建立銷售預測版本</summary>
        public static bool SetRF_Version(string 預測年月, string 版本)
        {
            return DAL_RF.SetRF_Version(預測年月, 版本);
        }

        /// <summary>審核銷售預測版本</summary>
        public static bool AuditRF_Version(string 預測年月, string 業務員代號, string 狀態碼, ref string msg)
        {
            #region 檢查狀態碼
            DataTable dtResult = DAL_RF.GetForecastData("", "", 預測年月, "", 業務員代號, "", "", "");
            if (dtResult.Rows.Count > 0)
            {
                string strStatus = dtResult.Rows[0]["狀態碼"].ToString();
                switch (狀態碼)
                {
                    case "Y":
                    case "V":
                        if (strStatus != "S")
                        {
                            msg = "狀態碼必須為審核中!";
                        }
                        break;
                    case "S":
                        if (strStatus != "N" && strStatus != "V")
                        {
                            msg = "狀態碼必須為未審核或退件!";
                        }
                        break;
                }
            }
            #endregion

            if (msg == "")
                return DAL_RF.AuditRF_Version(預測年月, 業務員代號, 狀態碼, ref msg);
            else
                return false;
        }

        /// <summary>取得實際銷售資料</summary>
        public static DataTable GetRealityData(string 公司別, string 年月, string 銷售分類, string 業務員代號, string 客戶簡稱, string 品名, string 業務人員清單)
        {
            業務人員清單 = 業務人員清單.Trim(',');
            業務人員清單 = UHR.Util.Tool.SetSplitSingleMark(業務人員清單, "'", ',');

            return DAL_RF.GetRealityData(公司別, 年月, 銷售分類, 業務員代號, 客戶簡稱, 品名, 業務人員清單);
        }

        /// <summary>寫入實際銷售資料</summary>
        public static bool SetRealityData(string 年月, DataTable dt, ref string msg)
        {
            //去除所有值的前後空白
            UHR.Util.Tool.TrimAllValue(dt);

            return DAL_RF.SetRealityData(年月, dt, ref msg);
        }

        /// <summary>取得組織階層</summary>
        public static DataTable GetRF_Group(string 人員代號, string 職稱, string 審核)
        {
            return DAL_RF.GetRF_Group(人員代號, 職稱, 審核);
        }

        /// <summary>取得上級組織階層</summary>
        public static DataTable GetGroupManage(string 人員代號, string 審核)
        {
            return DAL_RF.GetGroupManage(人員代號, 審核);
        }

        /// <summary>批次更銷售預測資料</summary>
        public static bool UpdateRFItem(List<dynamic> list, ref string msg)
        {
            if (list.Count > 0)
            {
                #region 檢查狀態碼
                dynamic item = list[0];
                string strID = (String)item.ID;

                DataTable dt = DAL_RF.GetForecastData(strID, "", "", "", "", "", "", "");
                DataRow row = dt.Rows[0];

                string strStatus = row["狀態碼"].ToString();
                switch (strStatus)
                {
                    case "Y":
                        msg = "資料已審核，不可修改!";
                        break;
                    case "S":
                        msg = "資料正在審核中，不可修改!";
                        break;
                }
                #endregion
            }
            else
            {
                msg = "無資料可更新!";
            }

            if (msg == "")
            {
                return DAL_RF.UpdateRFItem(list, ref msg);
            }
            else
            {
                return false;
            }
        }

        /// <summary>取得實際與預測合併的資料</summary>
        public static DataTable GetAllForecastData(string 公司別, string 年月, string 版本, string 銷售分類, string 業務員代號, string 客戶簡稱, string 品名, string 業務人員清單)
        {
            //資料來源
            DataTable dtSale = GetRealityData(公司別, 年月, 銷售分類, 業務員代號, 客戶簡稱, 品名, 業務人員清單);
            DataTable dt1 = null;
            if (版本 == "")
                dt1 = GetForecastData("", 公司別, 年月, 銷售分類, 業務員代號, 客戶簡稱, 品名, 業務人員清單);
            else
                dt1 = GetForecastHistoryData(公司別, 年月, 銷售分類, 業務員代號, 客戶簡稱, 品名, 版本, 業務人員清單);

            //過濾Forecast值為0的資料
            dt1.DefaultView.RowFilter = "本幣金額 <> 0";

            //增加虛擬欄位
            dtSale.Columns.Add("預測數量", Type.GetType("System.Decimal"));
            dtSale.Columns.Add("預測數量M2", Type.GetType("System.Decimal"));
            dtSale.Columns.Add("本幣預測金額", Type.GetType("System.Decimal"));

            //合併預測與實際的DataTable
            foreach (DataRowView row in dt1.DefaultView)
            {
                DataRow newRow = dtSale.NewRow();
                newRow["公司別"] = row["公司別"];
                newRow["日期"] = row["預測年月"];
                newRow["業務員代號"] = row["業務員代號"];
                newRow["業務員姓名"] = row["業務員姓名"];
                newRow["客戶簡稱"] = row["客戶簡稱"];
                newRow["銷售分類"] = row["銷售分類"];
                newRow["品號"] = row["品號"];
                newRow["品名"] = row["品名"];
                newRow["規格"] = row["規格"];
                newRow["單位"] = row["單位"];
                newRow["預測數量"] = row["數量"];
                newRow["預測數量M2"] = row["數量M2"];
                newRow["幣別"] = row["幣別"];
                newRow["本幣預測金額"] = row["本幣金額"];
                dtSale.Rows.Add(newRow);
            }

            return dtSale;
        }

        /// <summary>取得歷年銷售趨勢圖表</summary>
        public static DataTable GetSAL01(int iYear, string Company, string BU, string Class, string Product, string Custom, string Sales, string AuthCode)
        {
            if (BU != "null")
                BU = Tool.SetSplitSingleMark(BU, "'", ',');
            else
                BU = "";

            Product = Tool.SetSplitSingleMark(Product, "'", ',');

            return DAL_RF.GetSAL01(iYear, Company, BU, Class, Product, Custom, Sales, AuthCode);
        }

        /// <summary>取得堆疊銷售趨勢圖表</summary>
        public static DataTable GetSAL02(string StockType, string Year, string Company, string BU, string Class, string Product, string Custom, string Sales, string AuthCode)
        {
            if (BU != "null")
                BU = Tool.SetSplitSingleMark(BU, "'", ',');
            else
                BU = "";

            Product = Tool.SetSplitSingleMark(Product, "'", ',');

            return DAL_RF.GetSAL02(StockType, Year, Company, BU, Class, Product, Custom, Sales, AuthCode);
        }

        /// <summary>取得圓餅銷售統計圖表</summary>
        public static DataTable GetSAL03(string StockType, string sYM, string eYM, string Company, string BU, string Class, string Product, string Custom, string Sales, string AuthCode)
        {
            if (BU != "null")
                BU = Tool.SetSplitSingleMark(BU, "'", ',');
            else
                BU = "";

            Product = Tool.SetSplitSingleMark(Product, "'", ',');

            //取得資料來源
            DataTable dt = DAL_RF.GetSAL03(StockType, sYM, eYM, Company, BU, Class, Product, Custom, Sales, AuthCode);

            //計算總數值 (轉換百分比需要)
            decimal dTotalQty = (decimal)dt.Compute("SUM(數量M2)", "");
            decimal dTotalAmount = (decimal)dt.Compute("SUM(本幣金額)", "");

            //逐筆重新計算百分比
            foreach (DataRow row in dt.Rows)
            {
                row["數量M2"] = Convert.ToDecimal(row["數量M2"]) / dTotalQty * 100;
                row["本幣金額"] = Convert.ToDecimal(row["本幣金額"]) / dTotalAmount * 100;
            }

            return dt;
        }

        /// <summary>取得每日銷售進度表</summary>
        public static DataTable GetSAL04(string YM, string Company, string BU, string Sales, string Custom, string Product, string AuthCode)
        {
            BU = Tool.SetSplitSingleMark(BU, "'", ',');
            Product = Tool.SetSplitSingleMark(Product, "'", ',');

            DataTable dt = DAL_RF.GetSAL04(YM, Company, BU, Sales, Custom, Product, AuthCode);

            #region 建立欄位
            dt.Columns.Add("預估單價", Type.GetType("System.Decimal"));
            dt.Columns.Add("銷量達成率", Type.GetType("System.Decimal"));
            dt.Columns.Add("營收達成率", Type.GetType("System.Decimal"));
            dt.Columns.Add("實際單價", Type.GetType("System.Decimal"));
            dt.Columns.Add("警示值", Type.GetType("System.Decimal"));
            #endregion

            //本月總天數
            int iDayCount = new DateTime(DateTime.Now.AddMonths(1).Year, DateTime.Now.AddMonths(1).Month, 1).AddDays(-1).Day;
            int iNowDay = DateTime.Now.Day;

            #region 逐筆資料運算
            foreach (DataRow row in dt.Rows)
            {
                decimal 預估銷量 = Convert.ToDecimal(row["預估銷量"]);
                decimal 預估營收 = Convert.ToDecimal(row["預估營收"]);
                decimal 實際銷量 = Convert.ToDecimal(row["實際銷量"]);
                decimal 實際營收 = Convert.ToDecimal(row["實際營收"]);

                row["預估單價"] = 預估銷量 != 0 ? (預估營收 / 預估銷量) : 0;
                row["銷量達成率"] = 預估銷量 != 0 ? (實際銷量 / 預估銷量 * 100) : 0;
                row["營收達成率"] = 預估營收 != 0 ? (實際營收 / 預估營收 * 100) : 0;
                row["實際單價"] = 實際銷量 != 0 ? (實際營收 / 實際銷量) : 0;

                if (預估營收 != 0 && 實際營收 != 0)
                {
                    row["警示值"] = (((預估營收 / iDayCount) * iNowDay) - 實際營收) / 預估營收 * 100;
                }
                else
                {
                    row["警示值"] = 0;
                }
            }
            #endregion

            return dt;
        }

        /// <summary>取得ASP趨勢比較圖</summary>
        public static DataTable GetSAL05(string ChartType, string sYM, string eYM, string Company, string BU, string Class, string ProductName, string ProductNum, string Custom, string Sales, string IncludeNegative, string AuthCode)
        {
            if (BU != "null")
                BU = Tool.SetSplitSingleMark(BU, "'", ',');
            else
                BU = "";

            ProductName = Tool.SetSplitSingleMark(ProductName, "'", ',');

            return DAL_RF.GetSAL05(ChartType, sYM, eYM, Company, BU, Class, ProductName, ProductNum, Custom, Sales, IncludeNegative, AuthCode);
        }

        public static DataTable GetAvgSaleData(string Company, string Custom, string Product, string Currency, string YM)
        {
            return DAL_RF.GetAvgSaleData(Company, Custom, Product, Currency, YM);
        }
    }
}