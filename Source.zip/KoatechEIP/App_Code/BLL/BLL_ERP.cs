﻿using System;
using System.Data;

namespace UHR
{
    public class BLL_ERP
    {
        public BLL_ERP()
        {

        }

        /// <summary>取得供應商資料</summary>
        public static DataTable GetPURMA(string _code, string _name, string _type, string _sort, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_ERP.GetPURMA(_code, _name, _type, _sort, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得交易對象分類檔</summary>
        public static DataTable GetCMSMR(string _mr001, string _mr002)
        {
            return DAL_ERP.GetCMSMR(_mr001, _mr002);
        }

        /// <summary>取得庫別檔</summary>
        public static DataTable GetCMSMC(string MC004)
        {
            return DAL_ERP.GetCMSMC(MC004);
        }

        /// <summary>更新供應商資料</summary>
        public static void UpdatePURMA(DataTable dt)
        {
            DAL_ERP.UpdatePURMA(dt);
        }

        /// <summary>品號資料表</summary>
        public static DataTable GetPD01(string _product, string _pname)
        {
            return DAL_ERP.GetPD01(_product, _pname);
        }

        /// <summary>取得部門科目各期金額檔</summary>
        public static DataTable GetACTMD(string 科目編號, string 部門代號, string 會計年度, string 期別)
        {
            return DAL_ERP.GetACTMD(科目編號, 部門代號, 會計年度, 期別);
        }

        /// <summary>取得會計科目檔</summary>
        public static DataTable GetACTMA(string 前置科目編號, string 科目編號, string 科目類別)
        {
            return DAL_ERP.GetACTMA(前置科目編號, 科目編號, 科目類別);
        }

        /// <summary>取得員工基本資料</summary>
        public static DataTable GetCMSMV(string 工號)
        {
            return DAL_ERP.GetCMSMV(工號);
        }

        /// <summary>取得客戶基本資料</summary>
        public static DataTable GetCOPMA(string 業務員代號, string 客戶代號, string 客戶簡稱)
        {
            return DAL_ERP.GetCOPMA(業務員代號, 客戶代號, 客戶簡稱);
        }

        /// <summary>線別資料檔</summary>
        public static DataTable GetCMSMD(string Code)
        {
            return DAL_ERP.GetCMSMD(Code); ;
        }

        /// <summary>取得部門資料</summary>
        public static DataTable GetCMSME(string 部門代號)
        {
            return DAL_ERP.GetCMSME(部門代號);
        }

        /// <summary>取得品號基本資料</summary>
        public static DataTable GetINVMB(string 品號)
        {
            return DAL_ERP.GetINVMB(品號);
        }

        /// <summary>取得品號類別檔</summary>
        public static DataTable GetINVMA(string 分類方式, string 類別代號)
        {
            return DAL_ERP.GetINVMA(分類方式, 類別代號);
        }

        /// <summary>取得品號換算單位檔</summary>
        public static DataTable GetINVMD(string 品號, string 單位)
        {
            return DAL_ERP.GetINVMD(品號, 單位);
        }

        /// <summary>取得幣別匯率檔單頭</summary>
        public static DataTable GetCMSMF(string 幣別)
        {
            return DAL_ERP.GetCMSMF(幣別);
        }

        /// <summary>取得實際銷貨資料</summary>
        public static DataTable GetRealitySaleData(string 銷售年月, string 業務員代號, string 客戶簡稱)
        {
            return DAL_ERP.GetRealitySaleData(銷售年月, 業務員代號, 客戶簡稱);
        }

        /// <summary>取得實際銷退資料</summary>
        public static DataTable GetRealitySaleReturnData(string 銷退年月, string 業務員代號, string 客戶簡稱)
        {
            return DAL_ERP.GetRealitySaleReturnData(銷退年月, 業務員代號, 客戶簡稱);
        }
    }
}