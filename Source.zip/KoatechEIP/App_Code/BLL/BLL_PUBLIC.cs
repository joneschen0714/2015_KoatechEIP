﻿using System;
using System.Data;

namespace UHR
{
    public class BLL_PUBLIC
    {
        public BLL_PUBLIC()
        {

        }

        /// <summary>取得EHR的員工資料</summary>
        public static DataTable GetHR_UserData(string _empid, string _dep, string _cname, string _sort, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_PUBLIC.GetHR_UserData(_empid, _dep, _cname, _sort, _pageindex, _pagesize, out  _recordcount);
        }

        /// <summary>取得EHR的部門資料</summary>
        public static DataTable GetHR_DEP(string PARENT_DEPT_CODE, string DEPT_CODE, string ACC_NO, string DEP_DISABLE)
        {
            return DAL_PUBLIC.GetHR_DEP(PARENT_DEPT_CODE, DEPT_CODE, ACC_NO, DEP_DISABLE);
        }

        /// <summary>取得全文檢索結果</summary>
        public static DataTable GetPublicSearch(string _keyword)
        {
            return DAL_PUBLIC.GetPublicSearch(_keyword);
        }

        /// <summary>排程全文檢索</summary>
        public static void SetPublicSearch()
        {
            DAL_PUBLIC.SetPublicSearch();
        }

        /// <summary>取得教育訓練資料</summary>
        public static DataTable GetPUB02(string id, string enabled)
        {
            return DAL_PUBLIC.GetPUB02(id, enabled);
        }

        /// <summary>取得FIN03</summary>
        public static DataTable GetFIN03()
        {
            return DAL_PUBLIC.GetFIN03();
        }

        /// <summary>寫入FIN03</summary>
        public static void SetFIN03(DataTable dt)
        {
            foreach (DataRow row in dt.Rows)
            {
                if (row["歸屬部門"] == DBNull.Value)
                {
                    row["歸屬部門"] = "";
                }
            }

            DAL_PUBLIC.SetFIN03(dt);
        }

        /// <summary>寫入FIN03的歷史資料</summary>
        public static void SetFIN03_HistoryData(DataView dv)
        {
            DAL_PUBLIC.SetFIN03_HistoryData(dv);
        }
    }
}