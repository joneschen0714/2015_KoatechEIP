﻿using System;
using System.Data;

namespace UHR
{
    public class BLL
    {
        public BLL()
        {

        }

        /// <summary>取得使用者相關資料</summary>
        public static DataTable GetUserInfo(string _id, string _account, string _email)
        {
            _account = _account.ToLower();
            return DAL.GetUserInfo(_id, _account, _email);
        }

        /// <summary>取得使用者清單資料</summary>
        public static DataTable GetUserList(string _account, string _name, string _sort, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL.GetUserList(_account, _name, _sort, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得使用者群組相關資料</summary>
        public static DataRow GetGroupInfo(string _groupnum)
        {
            return DAL.GetGroupInfo(_groupnum);
        }

        /// <summary>取得使用者權限資料</summary>
        public static DataTable GetUserAuthority(object _account, object _menuno, object _flow, object _admin, object _enabled)
        {
            return DAL.GetUserAuthority(_account, _menuno, _flow, _admin, _enabled);
        }

        /// <summary>取得使用者群組清單資料</summary>
        public static DataTable GetGroupList(string _sort, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL.GetGroupList(_sort, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得選單相關資料</summary>
        public static DataTable GetMenuList(string MenuNo, string ParentNo, string Type, string Enabled)
        {
            return DAL.GetMenuList(MenuNo, ParentNo, Type, Enabled);
        }

        /// <summary>變更密碼</summary>
        public static bool ChangePassword(int _ID, string _Pwd0, string _Pwd1, string _Pwd2, ref string _Msg)
        {
            if (_Pwd1 == "" || _Pwd2 == "") { _Msg = "請確認密碼都有正確輸入!"; return false; }

            if (_Pwd0 == _Pwd1) { _Msg = "密碼不可與原密碼重覆!"; return false; }

            if (_Pwd1.Length < 6 || _Pwd2.Length < 6) { _Msg = "密碼至少6個字元!"; return false; }

            if (_Pwd1 != _Pwd2) { _Msg = "密碼不符，請重新輸入!"; return false; }

            return DAL.ChangePassword(_ID, _Pwd0, _Pwd2, ref _Msg);
        }

        /// <summary>取得系統參數</summary>
        public static DataTable GetSystemConfig(string Key, string Value)
        {
            return DAL.GetSystemConfig(Key, Value);
        }

        /// <summary>取得待辦事項</summary>
        public static DataTable GetWorkList(string type, string account, string _params)
        {
            return DAL.GetWorkList(type, account, _params);
        }

        /// <summary>設定待辦事項</summary>
        public static void SetWorkList(string _type, string _account, string _params, string _subject)
        {
            DAL.SetWorkList(_type, _account, _params, _subject);
        }

        /// <summary>刪除待辦事項</summary>
        public static void DelWorkList(string _type, string _account, string _params)
        {
            DAL.DelWorkList(_type, _account, _params);
        }

        /// <summary>取得部門階層資料</summary>
        public static DataTable GetDeptList(string DepCode)
        {
            return DAL.GetDeptList(DepCode);
        }

        /// <summary>取得幣別匯率</summary>
        public static DataTable GetCurrencyRate(string Type, string YM, string Currency, string _sort, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL.GetCurrencyRate(Type, YM, Currency, _sort, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>寫入幣別匯率</summary>
        public static bool SetCurrencyRate(DataTable dt, ref string msg)
        {
            //去除所有值的前後空白
            UHR.Util.Tool.TrimAllValue(dt);

            DataTable dtType = dt.DefaultView.ToTable(true, "類別");
            DataTable dtCurrency = dt.DefaultView.ToTable(true, "幣別");

            #region 檢查類別
            foreach (DataRow rowType in dtType.Rows)
            {
                string strType = Convert.ToString(rowType["類別"]).Trim();

                int iResult = BLL.GetSystemConfig("CurrencyType", strType).Rows.Count;
                if (iResult == 0)
                {
                    msg += string.Format("<br/>找不到 {0} 的類別!", strType);
                }
            }
            #endregion

            #region 檢查幣別
            foreach (DataRow rowCurrency in dtCurrency.Rows)
            {
                string strCurrency = Convert.ToString(rowCurrency["幣別"]).Trim();

                if (strCurrency == "NTD")
                {
                    msg += string.Format("<br/>NTD 的匯率固定為1，不可修改!");
                }
                else
                {
                    int iResult = BLL_ERP.GetCMSMF(strCurrency).Rows.Count;
                    if (iResult == 0)
                    {
                        msg += string.Format("<br/> {0} 的幣別不存在ERP中!", strCurrency);
                    }
                }
            }
            #endregion

            #region 檢查預測年月
            foreach (DataRow rowYM in dt.Rows)
            {
                string strYM = Convert.ToString(rowYM["年月"]).Trim();

                //驗証年月函式
                DateTime dResult;
                bool bResult = UHR.Util.Tool.ParseDateTime(strYM + "01", out dResult);
                if (!bResult)
                {
                    msg += string.Format("<br/> {0} 的年月格式錯誤!", strYM);
                }
            }
            #endregion

            if (msg == "")
            {
                return DAL.SetCurrencyRate(dt, ref msg);
            }
            else
            {
                return false;
            }
        }
    }
}