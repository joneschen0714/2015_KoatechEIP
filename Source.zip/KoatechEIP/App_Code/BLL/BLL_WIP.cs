﻿using System;
using System.Data;
using UHR.Util;
using System.Linq;

namespace UHR
{
    public class BLL_WIP
    {
        public BLL_WIP()
        {

        }

        /// <summary>取得報價單的單頭列表</summary>
        public static DataTable GetMOCWH(string _sort, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_WIP.GetMOCWH(_sort, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>庫齡報表</summary>
        public static DataTable GetFIN01(string date, string invType, string invType1, string invClass, string PN1, string PN2, string day1, string day2, string day21, string day3, string day31, string day4, string day41, string day5, string day51, string day6)
        {
            date = date.Replace("/", "");

            DataTable dt = DAL_WIP.GetFIN01(date, invType, invType1, invClass, PN1, PN2, day1, day2, day21, day3, day31, day4, day41, day5, day51, day6);

            dt.Columns["LA001"].ColumnName = "品號";
            dt.Columns["MB002"].ColumnName = "品名";
            dt.Columns["MB003"].ColumnName = "規格";
            dt.Columns["MB004"].ColumnName = "單位";
            dt.Columns["LA009"].ColumnName = "庫別";
            dt.Columns["MC002"].ColumnName = "庫別名稱";
            dt.Columns["LA016"].ColumnName = "批號";
            dt.Columns["1_QTY"].ColumnName = string.Format("{0}天以內數量", day1);
            dt.Columns["1_AMT"].ColumnName = string.Format("{0}天以內金額", day1);
            dt.Columns["2_QTY"].ColumnName = string.Format("{0}至{1}天數量", day2, day21);
            dt.Columns["2_AMT"].ColumnName = string.Format("{0}至{1}天金額", day2, day21);
            dt.Columns["3_QTY"].ColumnName = string.Format("{0}至{1}天數量", day3, day31);
            dt.Columns["3_AMT"].ColumnName = string.Format("{0}至{1}天金額", day3, day31);
            dt.Columns["4_QTY"].ColumnName = string.Format("{0}至{1}天數量", day4, day41);
            dt.Columns["4_AMT"].ColumnName = string.Format("{0}至{1}天金額", day4, day41);
            dt.Columns["5_QTY"].ColumnName = string.Format("{0}至{1}天數量", day5, day51);
            dt.Columns["5_AMT"].ColumnName = string.Format("{0}至{1}天金額", day5, day51);
            dt.Columns["6_QTY"].ColumnName = string.Format("{0}天以上數量", day6);
            dt.Columns["6_AMT"].ColumnName = string.Format("{0}天以上金額", day6);

            return dt;
        }

        /// <summary>製令用料表</summary>
        public static DataTable GetPD07(string FormType, string FormNum, string Date1, string Date2, string Line, string SProduct)
        {
            Date1 = Date1.Replace("/", "");
            Date2 = Date2.Replace("/", "");

            return DAL_WIP.GetPD07(FormType, FormNum, Date1, Date2, Line, SProduct);
        }

        /// <summary>線別人工製費清單</summary>
        public static DataTable GetFIN02(string Line, string Date1, string Date2)
        {
            Line = Tool.SetSplitSingleMark(Line, "'", ',');
            Date1 = Date1.Replace("/", "");
            Date2 = Date2.Replace("/", "");

            return DAL_WIP.GetFIN02(Line, Date1, Date2);
        }

        /// <summary>線別資料檔(WIP)</summary>
        public static DataTable GetMOCWB(string Code)
        {
            return DAL_WIP.GetMOCWB(Code); ;
        }

        /// <summary>製程項目資料檔(WIP)</summary>
        public static DataTable GetMOCWA(string _line)
        {
            return DAL_WIP.GetMOCWA(_line); ;
        }

        /// <summary>生產管制表</summary>
        public static DataTable GetPD02(string _year, string _month, string _line, string _process, string _level)
        {
            return DAL_WIP.GetPD02(_year, _month, _line, _process, _level); ;
        }

        /// <summary>生產管制表-子報表鑽取</summary>
        public static DataTable GetPD02_Report2(string _formType, string _formNum, string _lot)
        {
            return DAL_WIP.GetPD02_Report2(_formType, _formNum, _lot); ;
        }

        /// <summary>生產良率</summary>
        public static DataTable GetYieldRate(string 日期, string 生產線別, string 品號)
        {
            return DAL_WIP.GetYieldRate(日期, 生產線別, 品號);
        }

        /// <summary>缺陷紀錄</summary>
        public static DataTable GetDefectData(string 日期)
        {
            return DAL_WIP.GetDefectData(日期);
        }
    }
}