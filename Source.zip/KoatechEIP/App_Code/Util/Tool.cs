﻿using System;
using System.Data;
using System.Collections.Generic;
using System.IO;
using System.Configuration;
using System.Collections.Generic;
using System.Threading;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Data.OleDb;
using System.Data.Odbc;
using ICSharpCode.SharpZipLib.Zip;
using Newtonsoft.Json;

namespace UHR.Util
{
    public class Tool
    {
        public Tool()
        {

        }

        /// <summary>DataTable轉換為JSON字串格式</summary>
        public static string DataTableConvertJson(DataTable dt)
        {
            StringBuilder jsonBuilder = new StringBuilder();
            jsonBuilder.Append("{\"");
            jsonBuilder.Append(dt.TableName);
            jsonBuilder.Append("\":[");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                jsonBuilder.Append("{");
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    jsonBuilder.Append("\"");
                    jsonBuilder.Append(dt.Columns[j].ColumnName);
                    jsonBuilder.Append("\":\"");
                    jsonBuilder.Append(dt.Rows[i][j].ToString());
                    jsonBuilder.Append("\",");
                }
                jsonBuilder.Remove(jsonBuilder.Length - 1, 1);
                jsonBuilder.Append("},");
            }
            jsonBuilder.Remove(jsonBuilder.Length - 1, 1);
            jsonBuilder.Append("]");
            jsonBuilder.Append("}");
            return jsonBuilder.ToString();
        }

        /// <summary>檔案轉Byte[]</summary>
        public static byte[] ConvertFileToByte(string filepath)
        {
            FileStream fs = new FileStream(filepath, FileMode.Open, FileAccess.Read);
            byte[] buf = new byte[fs.Length];
            fs.Read(buf, 0, Convert.ToInt32(fs.Length));
            fs.Close();
            fs.Dispose();

            return buf;
        }

        /// <summary>分割字串，並在各個值前後加上指定字元</summary>
        public static string SetSplitSingleMark(string value, string SingleMark, char splitChar)
        {
            string newValue = "";
            if (value.Trim() != "")
            {
                foreach (string str in value.Split(splitChar))
                    newValue += SingleMark + str.Trim() + SingleMark + splitChar;
            }

            return newValue.Trim(splitChar);
        }

        /// <summary>取得HttpContext，並轉NULL為空值</summary>
        public static string CheckQueryString(string strName)
        {
            HttpContext context = HttpContext.Current;
            if (context.Request.QueryString[strName] == null)
                return "";
            else
                return context.Request.QueryString[strName].ToString();
        }

        /// <summary>取得HttpContext，並轉NULL為空值</summary>
        public static string GetStringUrlParam(string strUrl, string strParamName)
        {
            string strValue = "";
            foreach (string strItem in strUrl.Split('?', '&'))
            {
                string[] ItemData = strItem.Split('=');
                if (ItemData[0] == strParamName)
                {
                    strValue = ItemData[1];
                }
            }

            return strValue;
        }

        /// <summary>設定Url的某個參數</summary>
        public static string SetUrlParam(string Url, string ParamName, string ParamValue)
        {
            string[] _items = Url.Split('?');
            string strUrlMain = "", strUrlParams = "", strParamsValue = "";

            strUrlMain = _items[0];
            strUrlParams = (_items.Length == 2 ? _items[1] : "");

            if (!string.IsNullOrEmpty(strUrlParams))
            {
                foreach (string _param in strUrlParams.Split('&'))
                {
                    string[] ItemData = _param.Split('=');
                    string _name = ItemData[0];
                    string _value = ItemData[1];

                    if (_name != ParamName)
                    {
                        strParamsValue += string.Format("{0}={1}&", _name, _value);
                    }
                }
            }

            if (!string.IsNullOrEmpty(ParamValue))
                strParamsValue += string.Format("{0}={1}&", ParamName, ParamValue);

            if (!string.IsNullOrEmpty(strParamsValue))
                strUrlMain += "?" + strParamsValue.TrimEnd('&');

            return strUrlMain;
        }

        /// <summary>取得Xml節點的屬性值</summary>
        public static string GetXmlAttributeItem(XmlNode _node, string _AttrName)
        {
            string strResult = "";
            if (_node.Attributes[_AttrName] != null)
            {
                strResult = _node.Attributes[_AttrName].Value;
            }

            return strResult;
        }

        /// <summary>取得JavaScript for jQuery指令控制項</summary>
        public static Control GetJavaScriptContent(string _script)
        {
            string strScript = "<script type='text/javascript'>$(document).ready(function(){{ScriptContent}});</script>";
            strScript = strScript.Replace("{ScriptContent}", _script);

            LiteralControl liScript = new LiteralControl(strScript);
            return liScript;
        }

        /// <summary>空值轉換DBNULL函式</summary>
        public static object GetDBNullString(object _obj)
        {
            string str = Convert.ToString(_obj);

            if (string.IsNullOrEmpty(str))
                _obj = DBNull.Value;

            return _obj;
        }

        /// <summary>轉DataTable為CSV檔</summary>
        public static void DataTableToCSV(DataTable table, string strPath)
        {
            //宣告
            string strCol = "";
            string[] strValAry = new string[table.Rows.Count];
            StreamWriter writer = new StreamWriter(strPath, false, System.Text.Encoding.Default);

            //循序讀取欄位名稱
            foreach (DataColumn col in table.Columns)
            {
                strCol += (strCol == "" ? "" : ",") + "\"" + col.ColumnName.Trim() + "\""; //累加欄位名稱

                //循序讀取資料列
                int colIndex = 0;
                foreach (DataRow row in table.Rows)
                {
                    strValAry[colIndex] += (strValAry[colIndex] == null ? "" : ",") + "\"" + row[col.ColumnName].ToString().Trim() + "\""; //增加值至陣列
                    colIndex++;
                }
            }

            writer.WriteLine(strCol); //寫入欄位
            //循序寫入資料
            foreach (string strVal in strValAry)
                writer.WriteLine(strVal);

            //關閉物件
            writer.Close();
            writer.Dispose();
        }

        /// <summary>轉DataTable為Excel檔</summary>
        public static StringBuilder DataTableToExcel(DataTable table, List<int> textColumns)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<html><body>");
            sb.Append("<style type=text/css>td.text{mso-number-format:\\@;}</style>");
            sb.Append("<table>");

            sb.Append("<tr>");
            foreach (DataColumn col in table.Columns)
            {
                sb.Append("<td>" + col.ColumnName + "</td>");
            }
            sb.Append("</tr>");

            int count = table.Columns.Count;
            foreach (DataRow row in table.Rows)
            {
                sb.Append("<tr>");
                for (int i = 0; i < count; i++)
                {
                    if (textColumns.Contains(i))
                        sb.Append("<td class='text'>" + row[i] + "</td>");
                    else
                        sb.Append("<td>" + row[i] + "</td>");
                }
                sb.Append("</tr>");
            }

            sb.Append("</table>");
            sb.Append("</body></html>");

            return sb;
        }

        /// <summary>壓縮檔案</summary>
        public static void Zip(List<string> fileNames, string GzipFileName, int CompressionLevel, int SleepTimer)
        {
            ZipOutputStream s = new ZipOutputStream(File.Create(GzipFileName));
            try
            {
                s.SetLevel(CompressionLevel);   //0 - store only to 9 - means best compression
                foreach (string file in fileNames)
                {
                    FileInfo fi = new FileInfo(file);
                    FileStream fs = null;
                    try
                    {
                        fs = fi.Open(FileMode.Open, FileAccess.ReadWrite);
                    }
                    catch
                    {
                        continue;
                    }

                    //方法二，將文件分批讀入緩衝區
                    byte[] data = new byte[2048];
                    int size = 2048;
                    ZipEntry entry = new ZipEntry(Path.GetFileName(fi.Name));
                    entry.DateTime = (fi.CreationTime > fi.LastWriteTime ? fi.LastWriteTime : fi.CreationTime);
                    s.PutNextEntry(entry);
                    while (true)
                    {
                        size = fs.Read(data, 0, size);
                        if (size <= 0) break;
                        s.Write(data, 0, size);
                    }
                    fs.Close();
                    fi.Delete();
                    Thread.Sleep(SleepTimer);
                }
            }
            finally
            {
                s.Finish();
                s.Close();
            }
        }

        /// <summary>解壓縮檔案</summary>
        public static void UnZip(string zipfilePath, string targetpath)
        {
            ZipInputStream s = new ZipInputStream(File.OpenRead(zipfilePath));

            ZipEntry theEntry;
            while ((theEntry = s.GetNextEntry()) != null)
            {
                string directoryName = Path.GetDirectoryName(targetpath);
                string fileName = Path.GetFileName(theEntry.Name);

                //生成解壓目錄 
                Directory.CreateDirectory(directoryName);

                if (fileName != String.Empty)
                {
                    //解壓文件到指定的目錄 
                    FileStream streamWriter = File.Create(targetpath + theEntry.Name);

                    int size = 2048;
                    byte[] data = new byte[2048];
                    while (true)
                    {
                        size = s.Read(data, 0, data.Length);
                        if (size > 0) { streamWriter.Write(data, 0, size); }
                        else { break; }
                    }
                    streamWriter.Close();
                }
            }
            s.Close();
        }

        /// <summary>取得目前路徑下的實體目錄路徑</summary>
        public static string GetPhysicalPath
        {
            get
            {
                string path = HttpContext.Current.Request.PhysicalPath;
                int iLastIndex = path.LastIndexOf(@"\") + 1;
                return path.Substring(0, iLastIndex);
            }
        }

        /// <summary>取得上傳至指定的CSV內容 (OLEDB)</summary>
        public static DataTable GetUploadCsvTable(string strPath, string strFileName)
        {
            //建立OLEDB連線
            string strCon = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + strPath + ";Extended Properties=\"text;HDR=yes;FMT=Delimited\";";
            OleDbConnection objConn = new OleDbConnection(strCon);
            string strCom = " SELECT * FROM [" + strFileName + "]";
            objConn.Open();

            //資料來源轉成DataTable
            OleDbDataAdapter objCmd = new OleDbDataAdapter(strCom, objConn);
            DataTable dtResult = new DataTable();
            objCmd.Fill(dtResult);
            objConn.Close();

            return dtResult;
        }

        /// <summary>取得上傳至指定的CSV內容-相容64位元系統 (ODBC)</summary>
        public static DataTable GetDataSetFromCSV(string filePath, string fileName)
        {
            string strConn = @"Driver={Microsoft Text Driver (*.txt; *.csv)};Dbq=";
            strConn += filePath; //filePath, For example: C:\
            strConn += ";Extensions=asc,csv,tab,txt;";
            OdbcConnection objConn = new OdbcConnection(strConn);
            DataTable dtCSV = new DataTable();
            try
            {
                string strSql = "select * from " + fileName; //fileName, For example: 1.csv
                OdbcDataAdapter odbcCSVDataAdapter = new OdbcDataAdapter(strSql, objConn);
                odbcCSVDataAdapter.Fill(dtCSV);
                return dtCSV;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>取得累加數字的文字內容補0</summary>
        public static string GetPadLeftString(string value, int iNumber)
        {
            int iCount = value.Length;
            int iVal = int.Parse(value) + iNumber;
            return iVal.ToString().PadLeft(iCount, '0');
        }

        /// <summary>取得文字檔的內容</summary>
        public static string GetStreamText(string Path)
        {
            StreamReader sr = new StreamReader(Path, Encoding.Default);
            string strValue = sr.ReadToEnd();
            sr.Close();
            sr.Dispose();

            return strValue;
        }

        /// <summary>寫入文字檔的內容</summary>
        public static void WriteStreamText(string Path, string Text)
        {
            StreamWriter sw = new StreamWriter(Path, false, Encoding.Default);
            sw.Write(Text);
            sw.Close();
            sw.Dispose();
        }

        /// <summary>取得指定文字之後的字串</summary>
        public static string GetSubString(string Value, string SplitString, bool IsStartOf, bool IsTrim, string CapsLk)
        {
            if (!string.IsNullOrEmpty(SplitString))
            {
                int Index = IsStartOf ? Value.IndexOf(SplitString) : Value.LastIndexOf(SplitString);
                Value = Value.Substring(Index + 1);
            }

            if (IsTrim) { Value = Value.Trim(); }

            switch (CapsLk)
            {
                case "Lower":
                    Value = Value.ToLower();
                    break;
                case "Upper":
                    Value = Value.ToUpper();
                    break;
            }

            return Value;
        }

        /// <summary>回傳篩選後的DataTable資料集</summary>
        public static DataTable GetDataTableFilter(DataTable dt, string Filter, string Sort, bool Distinct, params string[] ColumnName)
        {
            if (!string.IsNullOrEmpty(Filter)) { dt.DefaultView.RowFilter = Filter; }
            if (!string.IsNullOrEmpty(Sort)) { dt.DefaultView.Sort = Sort; }

            return dt.DefaultView.ToTable(Distinct, ColumnName);
        }

        /// <summary>取得控制項輸出的HTML</summary>
        public static string GetHtmlText(Control control)
        {
            StringWriter sw = new System.IO.StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            control.RenderControl(hw);
            hw.Flush();

            return sw.ToString();
        }

        /// <summary>取得某字串出現的次數</summary>
        public static int GetTextContainCount(string Text, string ContainText)
        {
            MatchCollection mc;
            Regex r = new Regex(ContainText);

            mc = r.Matches(Text);
            return mc.Count;
        }

        /// <summary>判斷日期格式是否正確(yyyyMMdd)</summary>
        public static bool ParseDateTime(object date, out DateTime dResult)
        {
            bool bResult = false;
            var enUS = new System.Globalization.CultureInfo("zh-TW");
            var style = new System.Globalization.DateTimeStyles();

            bResult = DateTime.TryParseExact(date.ToString(), "yyyyMMdd", enUS, style, out dResult);
            return bResult;
        }

        /// <summary>取得日期為該年的第幾週</summary>
        public static int GetWeekOfYear(DateTime date)
        {
            var ci = new System.Globalization.CultureInfo("zh-TW");
            int iWeek = ci.Calendar.GetWeekOfYear(date, System.Globalization.CalendarWeekRule.FirstDay, DayOfWeek.Monday);
            return iWeek;
        }

        /// <summary>判斷是否為DBNull，若是就轉為替代值</summary>
        public static object GetDBNullToVal(object val, object val1)
        {
            if (Convert.IsDBNull(val))
            {
                return val1;
            }
            else
            {
                return val;
            }
        }

        /// <summary>去除所有值的前後空白</summary>
        public static void TrimAllValue(DataTable dt)
        {
            int iCol = dt.Columns.Count;
            foreach (DataRow row in dt.Rows)
            {
                for (int i = 0; i < iCol; i++)
                {
                    row[i] = row[i].ToString().Trim();
                }
            }
        }
    }
}