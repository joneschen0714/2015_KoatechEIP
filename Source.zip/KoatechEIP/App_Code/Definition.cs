﻿using System;
using System.Data;
using System.Configuration;
using System.Collections.Specialized;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace UHR
{
    public class Definition
    {
        public Definition()
        {

        }

        /// <summary>取得管理後台連線字串</summary>
        public static string AuthConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["AuthConnStr"].ConnectionString; }
        }

        /// <summary>取得ERP公司別連線字串</summary>
        public static string ERPConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["ERPConnStr"].ConnectionString; }
        }

        /// <summary>取得測試ERP公司別連線字串</summary>
        public static string ERPTestConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["ERPTestConnStr"].ConnectionString; }
        }

        /// <summary>取得HR資料的連線字串</summary>
        public static string HRConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["HRConnStr"].ConnectionString; }
        }

        /// <summary>取得HR資料的前置名稱</summary>
        public static string HRDBNAME
        {
            get { return ConfigurationManager.AppSettings["HRDBNAME"]; }
        }

        /// <summary>取得ERP資料庫的前置名稱</summary>
        public static string ERPDBNAME
        {
            get { return ConfigurationManager.AppSettings["ERPDBNAME"]; }
        }

        /// <summary>取得EIP資料庫的前置名稱</summary>
        public static string EIPDBNAME
        {
            get { return ConfigurationManager.AppSettings["EIPDBNAME"]; }
        }

        /// <summary>記錄頁面轉向的網址</summary>
        public static string RedirectURL
        {
            set
            {
                if (HttpContext.Current.Session["RedirectURL"] == null)
                    HttpContext.Current.Session.Add("RedirectURL", value);
                else
                    HttpContext.Current.Session["RedirectURL"] = value;
            }
            get
            {
                if (HttpContext.Current.Session["RedirectURL"] != null)
                    return HttpContext.Current.Session["RedirectURL"].ToString();

                return "";
            }
        }

        public static DataTable MainMenu
        {
            set
            {
                if (HttpContext.Current.Application["MainMenu"] == null)
                    HttpContext.Current.Application.Add("MainMenu", value);
                else
                    HttpContext.Current.Application["MainMenu"] = value;
            }
            get
            {
                if (HttpContext.Current.Application["MainMenu"] != null)
                    return (DataTable)HttpContext.Current.Application["MainMenu"];

                return null;
            }
        }

        public static string SelectMenuNo
        {
            set
            {
                if (HttpContext.Current.Session["SelectMenuNo"] == null)
                    HttpContext.Current.Session.Add("SelectMenuNo", value);
                else
                    HttpContext.Current.Session["SelectMenuNo"] = value;
            }
            get
            {
                if (HttpContext.Current.Session["SelectMenuNo"] != null)
                    return HttpContext.Current.Session["SelectMenuNo"].ToString();

                return "";
            }
        }

        public static string PageToken
        {
            set
            {
                if (HttpContext.Current.Session["PageToken"] == null)
                    HttpContext.Current.Session.Add("PageToken", value);
                else
                    HttpContext.Current.Session["PageToken"] = value;
            }
            get
            {
                if (HttpContext.Current.Session["PageToken"] != null)
                    return HttpContext.Current.Session["PageToken"].ToString();

                return "";
            }
        }

        public static string SessionRefreshTime
        {
            get { return ConfigurationManager.AppSettings["SessionRefreshTime"] + "000"; }
        }

        public static string AutoLoginCookie
        {
            get { return "KoatechEIPAutoLogin"; }
        }

        public static string MailServer
        {
            get { return ConfigurationManager.AppSettings["MailServer"]; }
        }

        public static string MailAccount
        {
            get { return ConfigurationManager.AppSettings["MailAccount"]; }
        }

        public static string MailPassword
        {
            get { return ConfigurationManager.AppSettings["MailPassword"]; }
        }
    }
}