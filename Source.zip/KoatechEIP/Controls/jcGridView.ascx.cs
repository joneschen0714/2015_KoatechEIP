﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class controls_jcGridView : System.Web.UI.UserControl
{
    //建立事件
    public event EventHandler GridDataBind;

    protected void Page_Init(object sender, EventArgs e)
    {
        //註冊事件
        gv.PreRender += new EventHandler(gv_PreRender);
        gv.Sorting += new GridViewSortEventHandler(gv_Sorting);
        gv.RowCreated += new GridViewRowEventHandler(gv_RowCreated);
    }

    protected void ddlpagesizeselect_SelectedIndexChanged(object sender, EventArgs e)
    {
        gv.PageSize = Convert.ToInt32(ddlpagesizeselect.Text); //設定顯示筆數
        GridDataBind(sender, e);
    }

    //文字方塊快速換頁事件
    protected void txtPageIndex_TextChanged(object sender, EventArgs e)
    {
        int iPageIndex;
        bool bResult = int.TryParse(txtPageIndex.Text, out iPageIndex);

        if (iPageIndex > PageCount) { iPageIndex = PageCount; }
        if (iPageIndex < 1) { iPageIndex = 1; }

        //判斷是否為頁數異動
        if (iPageIndex != PageIndex)
        {
            PageIndex = iPageIndex;
            GridDataBind(sender, e);
        }
    }

    //頁面切換鈕事件
    protected void PageChange_Click(object sender, ImageClickEventArgs e)
    {
        Control btnCtrl = (Control)sender;

        //切換頁數
        if (btnCtrl.ID == "FirstPage")
            PageIndex = 1;
        else if (btnCtrl.ID == "LastPage")
            PageIndex -= 1;
        else if (btnCtrl.ID == "NextPage")
            PageIndex += 1;
        else if (btnCtrl.ID == "FinalPage")
            PageIndex = PageCount;

        GridDataBind(sender, e);
    }

    //排序事件
    void gv_Sorting(object sender, GridViewSortEventArgs e)
    {
        SortingDirection = (SortingDirection == "DESC" ? "ASC" : "DESC"); //設定排序方向
        SortExpression = e.SortExpression; //排序欄位
        GridDataBind(sender, e);
    }

    //Grid Row建立事件
    protected void gv_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {
            if (SortExpression != "")
            {
                TableCell cellSortExpression = GetTableCell(e.Row, SortExpression, true);

                //設定排序圖示
                Literal liCtrl = new Literal();
                if (SortingDirection == "ASC") liCtrl.Text += " ▲";
                else liCtrl.Text += " ▼";

                cellSortExpression.Controls.Add(liCtrl);
            }
        }
    }

    //Grid載入後事件
    protected void gv_PreRender(object sender, EventArgs e)
    {
        gv.UseAccessibleHeader = true;

        if (gv.Rows.Count > 0)
        {
            gv.HeaderRow.TableSection = TableRowSection.TableHeader;
            gv.FooterRow.TableSection = TableRowSection.TableFooter;
        }

        lblpagecount.Text = PageCount.ToString(); //設定總頁數
        lblRowCount.Text = RowCount.ToString(); //設定總筆數

        ////若目前頁數大於總頁數
        //if (PageIndex > PageCount) { PageIndex = PageCount; }
        //if (PageIndex < 1) { PageIndex = 1; }

        txtPageIndex.Text = PageIndex.ToString(); //設定目前頁數

        //設定換頁按鈕
        FirstPage.Visible = (PageIndex != 1);
        LastPage.Visible = (PageIndex != 1);
        NextPage.Visible = (PageIndex != PageCount);
        FinalPage.Visible = (PageIndex != PageCount);
    }

    //增加欄位 多載1
    public void AddColumn(string HeaderText, string DataField, bool IsSort, Unit Width, HorizontalAlign HeaderAlign, HorizontalAlign ItemAlign)
    {
        //增加欄位
        BoundField bf = new BoundField();
        bf.HeaderText = HeaderText;
        bf.DataField = DataField;
        if (IsSort) bf.SortExpression = DataField;
        bf.ItemStyle.Width = Width;
        bf.ItemStyle.HorizontalAlign = ItemAlign;
        bf.HeaderStyle.HorizontalAlign = HeaderAlign;
        bf.Visible = true;
        bf.HtmlEncode = false;

        gv.Columns.Add(bf);
    }

    //增加欄位 多載2
    public void AddColumn(BoundField ColumnField)
    {
        //增加欄位
        gv.Columns.Add(ColumnField);
    }

    /// <summary>取得GridDataRow的TableCell</summary>
    public TableCell GetTableCell(GridViewRow gvRow, string HeaderText, bool isDataField)
    {
        foreach (TableCell cell in gvRow.Cells)
        {
            DataControlFieldCell fc = (DataControlFieldCell)cell;
            BoundField bf = (BoundField)fc.ContainingField;
            if (isDataField) //是否為資料欄位
            {
                if (bf.DataField == HeaderText) { return cell; }
            }
            else
            {
                if (fc.ContainingField.HeaderText == HeaderText) { return cell; }
            }
        }
        return null;
    }

    //屬性
    public GridView GridView
    {
        get { return gv; }
    }
    public int RowCount
    {
        set { ViewState.Add(ID + "_RowCount", value); }
        get { return Convert.ToInt32(ViewState[ID + "_RowCount"]); }
    }
    public int PageIndex
    {
        set { ViewState.Add(ID + "_PageIndex", value); }
        get
        {
            int iPageIndex = 1;
            if (ViewState[ID + "_PageIndex"] != null)
                iPageIndex = Convert.ToInt32(ViewState[ID + "_PageIndex"]);

            return iPageIndex;
        }
    }
    public int PageCount
    {
        get { return ((RowCount / gv.PageSize) + (RowCount % gv.PageSize > 0 ? 1 : 0)); }
    }
    public string SortingCondition
    {
        get { return string.Format("{0} {1}", SortExpression, SortingDirection); }
    }
    private string SortingDirection
    {
        set { ViewState.Add(ID + "_SortDirection", value); }
        get
        {
            if (ViewState[ID + "_SortDirection"] == null)
                SortingDirection = "DESC";

            return ViewState[ID + "_SortDirection"].ToString();
        }
    }
    public string SortExpression
    {
        set { ViewState.Add(ID + "_SortExpression", value); }
        get
        {
            if (ViewState[ID + "_SortExpression"] == null)
                SortExpression = "";

            return ViewState[ID + "_SortExpression"].ToString();
        }
    }
}