﻿using System;
using System.Data;
using System.Web;
using System.Web.UI;
using UHR;
using UHR.Authority;

public partial class Main : MasterPage
{
    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<link href='" + ResolveClientUrl("~/configuration/css/bootstrap.min.css") + "' rel='stylesheet' />"));
        Page.Header.Controls.Add(new LiteralControl("<link href='" + ResolveClientUrl("~/configuration/css/bootstrap-multiselect.css") + "' rel='stylesheet' />"));
        Page.Header.Controls.Add(new LiteralControl("<link href='" + ResolveClientUrl("~/configuration/css/font-awesome.min.css") + "' rel='stylesheet' />"));
        Page.Header.Controls.Add(new LiteralControl("<link href='" + ResolveClientUrl("~/configuration/css/fonts.css") + "' rel='stylesheet' />"));
        Page.Header.Controls.Add(new LiteralControl("<link href='" + ResolveClientUrl("~/configuration/css/ace.min.css") + "' rel='stylesheet' />"));
        Page.Header.Controls.Add(new LiteralControl("<link href='" + ResolveClientUrl("~/configuration/css/ace-skins.min.css") + "' rel='stylesheet' />"));
        Page.Header.Controls.Add(new LiteralControl("<link href='" + ResolveClientUrl("~/configuration/css/ace-rtl.min.css") + "' rel='stylesheet' />"));
        Page.Header.Controls.Add(new LiteralControl("<link href='" + ResolveClientUrl("~/configuration/css/swiper.min.css") + "' rel='stylesheet' />"));
        Page.Header.Controls.Add(new LiteralControl("<link href='" + ResolveClientUrl("~/configuration/css/swiper.min.css") + "' rel='stylesheet' />"));

        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/ace-extra.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/jquery-2.1.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/jquery.livequery.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/bootstrap.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/bootstrap-multiselect.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/fusioncharts.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/fusioncharts.charts.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/ace-elements.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/ace.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/swiper.jquery.min.js") + "'></script>"));

        string script = "<script>" +
                                "var rootPath = '" + ResolveClientUrl("~") + "'; " +
                                "function myTimer(){ $.ajax({ url: rootPath + 'configuration/Ajax/SessionPostBack.ashx' }); }" +
                                "setInterval('myTimer()', " + Definition.SessionRefreshTime + ");" +
                        "</script>";

        Page.Header.Controls.Add(new LiteralControl(script));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            liName.Text = UserInfo.SessionState.FirstName + UserInfo.SessionState.LastName;

            if (Definition.SelectMenuNo != "")
            {
                DataTable dtMainMenu = Definition.MainMenu;
                DataRow row = dtMainMenu.Select("MenuNo='" + Definition.SelectMenuNo + "'")[0];

                liTitle.Text = row["MenuName"].ToString();
                liSubTitle.Text = row["MenuDesc"].ToString();
            }
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        string strKeyword = txtSearch.Text.Trim();

        Response.Redirect("~/PublicSearch.aspx?keyword=" + strKeyword);
    }

    protected void linkLogout_Click(object sender, EventArgs e)
    {
        Session.Clear();

        //移除Cookie記錄
        HttpCookie cookie = Request.Cookies[Definition.AutoLoginCookie];
        if (cookie != null)
        {
            cookie = Response.Cookies[Definition.AutoLoginCookie];
            cookie.Expires = DateTime.Now.AddYears(-1);
        }

        Response.Redirect("~/login.aspx?type=logout");
    }
}