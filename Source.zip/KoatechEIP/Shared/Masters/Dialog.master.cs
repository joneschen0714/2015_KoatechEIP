﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Dialog : System.Web.UI.MasterPage
{
    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<link href='" + ResolveClientUrl("~/configuration/css/bootstrap.min.css") + "' rel='stylesheet' />"));
        Page.Header.Controls.Add(new LiteralControl("<link href='" + ResolveClientUrl("~/configuration/css/font-awesome.min.css") + "' rel='stylesheet' />"));
        Page.Header.Controls.Add(new LiteralControl("<link href='" + ResolveClientUrl("~/configuration/css/fonts.css") + "' rel='stylesheet' />"));
        Page.Header.Controls.Add(new LiteralControl("<link href='" + ResolveClientUrl("~/configuration/css/ace.min.css") + "' rel='stylesheet' />"));

        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/ace-extra.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/jquery-2.1.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/bootstrap.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/ace-elements.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script src='" + ResolveClientUrl("~/configuration/js/ace.min.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
}
