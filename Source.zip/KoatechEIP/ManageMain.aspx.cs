﻿using System;
using System.Web.UI;
using UHR.BasePage;

public partial class ManageMain : BasePage
{
    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M00";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
}