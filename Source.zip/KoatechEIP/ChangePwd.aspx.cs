﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;
using UHR.Authority;

public partial class ChangePwd : UHR.BasePage.BasePage
{
    private UserInfo ui = null;

    protected override void OnPreInit(EventArgs e)
    {
        base.MENU_NO = "M0001";
        base.OnPreInit(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        ui = UserInfo.SessionState;

        if (!IsPostBack)
        {
            lblEmail.Text = ui.Account;

            //if (ui.Type == "AD")
            //{
            //    liMsg.Text = GetMessage("info","您登入的為網域帳號，不可使用此功能!");
            //    divEdit.Visible = false;
            //}
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string pwd0 = txtoPwd.Text.Trim();
        string pwd1 = txtPwd.Text.Trim();
        string pwd2 = txtPwd2.Text.Trim();

        string strMsg = "";
        bool bResult = BLL.ChangePassword(ui.ID,pwd0, pwd1, pwd2, ref strMsg);

        if (!bResult)
        {
            liMsg.Text = GetMessage("error", strMsg);
        }
        else
        {
            liMsg.Text = GetMessage("success","密碼變更成功!");
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        txtoPwd.Text = "";
        txtPwd.Text = "";
        txtPwd2.Text = "";
    }
}