﻿using System;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Linq;
using UHR;
using UHR.Authority;
using UHR.Util;

public partial class Manage_Login : Page
{
    public string JSON, EMAIL, PWD;

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        string type = Tool.CheckQueryString("type");

        if (!IsPostBack)
        {
            if (type == "")
            {
                //是否登入
                if (UserInfo.Exists)
                {
                    Response.Redirect("ManageMain.aspx");
                }
                else
                {
                    //檢查是否有Cookie
                    HttpCookie cookie = Request.Cookies[Definition.AutoLoginCookie];
                    if (cookie != null)
                    {
                        txtAccount.Text = cookie["Account"];
                        txtPassword.Text = cookie["Password"];
                        cbAutoLogin.Checked = true;

                        login_Click(sender, e);
                    }
                }
            }
        }
    }

    protected void login_Click(object sender, EventArgs e)
    {
        string Account = txtAccount.Text.Trim();
        string PassWord = txtPassword.Text.Trim();

        if (Account == "" || PassWord.Trim() == "")
        {
            liMsg.Text = UHR.BasePage.BasePage.GetMessage("warning", "Account與Password不可空白");
            return;
        }

        DataTable dtUser = BLL.GetUserInfo("", Account, "");
        if (dtUser.Rows.Count > 0)
        {
            DataRow rowUser = dtUser.Rows[0];
            string strType = Convert.ToString(rowUser["Type"]);

            //驗証密碼
            int iCompare = string.Compare(PassWord, rowUser["Password"].ToString(), true);
            if (iCompare != 0)
            {
                liMsg.Text = UHR.BasePage.BasePage.GetMessage("error", "Password錯誤!");
                return;
            }

            //建立Cookie
            if (cbAutoLogin.Checked)
            {
                HttpCookie cookie = new HttpCookie(Definition.AutoLoginCookie);
                cookie.Values.Add("Account", Account);
                cookie.Values.Add("Password", PassWord);
                cookie.Expires = DateTime.Now.AddYears(1);
                Response.Cookies.Add(cookie);
            }

            //呼叫登入函式
            SetLoginInfo(dtUser.Rows[0]);
        }
        else
        {
            liMsg.Text = UHR.BasePage.BasePage.GetMessage("error", "無此帳號!");
            return;
        }
    }

    private void SetLoginInfo(DataRow _rowUser)
    {
        //是否鎖定
        string strIsLock = _rowUser["IsLock"].ToString();
        if (!"0".Equals(strIsLock))
        {
            liMsg.Text = UHR.BasePage.BasePage.GetMessage("error", "您的帳號已被鎖定!");
            return;
        }

        //設定UserInfo物件
        UserInfo ui = new UserInfo(_rowUser);
        UserInfo.SessionState = ui;

        //頁面轉向
        if (Definition.RedirectURL != "")
        {
            string url = Definition.RedirectURL;
            Definition.RedirectURL = "";
            Response.Redirect(url);
        }
        else
        {
            Response.Redirect("ManageMain.aspx");
        }
    }
}