﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR.Authority;

public partial class IM : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (UserInfo.Exists)
            {
                //設定使用者名稱
                var ui = UserInfo.SessionState;
                lblID.Text = ui.ID.ToString();
                lblName.Text = string.Format("{0}{1}", ui.FirstName, ui.LastName);
            }
        }
    }
}